import{L as t,_ as e,C as n,r as s,c as r,F as i,h as o,l as a,m as u,y as c,k as h,p as l,u as d,o as f,z as m,d as g,A as p,e as y,S as v,B as w,D as I,G as b}from"./firebase-core-CCkbINqO.js";var T,E,S="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{};
/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/(function(){var t;
/** @license
  
   Copyright The Closure Library Authors.
   SPDX-License-Identifier: Apache-2.0
  */function e(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.C=Array(this.blockSize),this.o=this.h=0,this.u()}function n(t,e,n){n||(n=0);const s=Array(16);if("string"==typeof e)for(var r=0;r<16;++r)s[r]=e.charCodeAt(n++)|e.charCodeAt(n++)<<8|e.charCodeAt(n++)<<16|e.charCodeAt(n++)<<24;else for(r=0;r<16;++r)s[r]=e[n++]|e[n++]<<8|e[n++]<<16|e[n++]<<24;e=t.g[0],n=t.g[1],r=t.g[2];let i,o=t.g[3];i=e+(o^n&(r^o))+s[0]+3614090360&4294967295,i=o+(r^(e=n+(i<<7&4294967295|i>>>25))&(n^r))+s[1]+3905402710&4294967295,o=e+(i<<12&4294967295|i>>>20),i=r+(n^o&(e^n))+s[2]+606105819&4294967295,i=n+(e^(r=o+(i<<17&4294967295|i>>>15))&(o^e))+s[3]+3250441966&4294967295,i=e+(o^(n=r+(i<<22&4294967295|i>>>10))&(r^o))+s[4]+4118548399&4294967295,i=o+(r^(e=n+(i<<7&4294967295|i>>>25))&(n^r))+s[5]+1200080426&4294967295,o=e+(i<<12&4294967295|i>>>20),i=r+(n^o&(e^n))+s[6]+2821735955&4294967295,i=n+(e^(r=o+(i<<17&4294967295|i>>>15))&(o^e))+s[7]+4249261313&4294967295,i=e+(o^(n=r+(i<<22&4294967295|i>>>10))&(r^o))+s[8]+1770035416&4294967295,i=o+(r^(e=n+(i<<7&4294967295|i>>>25))&(n^r))+s[9]+2336552879&4294967295,o=e+(i<<12&4294967295|i>>>20),i=r+(n^o&(e^n))+s[10]+4294925233&4294967295,i=n+(e^(r=o+(i<<17&4294967295|i>>>15))&(o^e))+s[11]+2304563134&4294967295,i=e+(o^(n=r+(i<<22&4294967295|i>>>10))&(r^o))+s[12]+1804603682&4294967295,i=o+(r^(e=n+(i<<7&4294967295|i>>>25))&(n^r))+s[13]+4254626195&4294967295,o=e+(i<<12&4294967295|i>>>20),i=r+(n^o&(e^n))+s[14]+2792965006&4294967295,i=n+(e^(r=o+(i<<17&4294967295|i>>>15))&(o^e))+s[15]+1236535329&4294967295,i=e+(r^o&((n=r+(i<<22&4294967295|i>>>10))^r))+s[1]+4129170786&4294967295,i=o+(n^r&((e=n+(i<<5&4294967295|i>>>27))^n))+s[6]+3225465664&4294967295,o=e+(i<<9&4294967295|i>>>23),i=r+(e^n&(o^e))+s[11]+643717713&4294967295,i=n+(o^e&((r=o+(i<<14&4294967295|i>>>18))^o))+s[0]+3921069994&4294967295,i=e+(r^o&((n=r+(i<<20&4294967295|i>>>12))^r))+s[5]+3593408605&4294967295,i=o+(n^r&((e=n+(i<<5&4294967295|i>>>27))^n))+s[10]+38016083&4294967295,o=e+(i<<9&4294967295|i>>>23),i=r+(e^n&(o^e))+s[15]+3634488961&4294967295,i=n+(o^e&((r=o+(i<<14&4294967295|i>>>18))^o))+s[4]+3889429448&4294967295,i=e+(r^o&((n=r+(i<<20&4294967295|i>>>12))^r))+s[9]+568446438&4294967295,i=o+(n^r&((e=n+(i<<5&4294967295|i>>>27))^n))+s[14]+3275163606&4294967295,o=e+(i<<9&4294967295|i>>>23),i=r+(e^n&(o^e))+s[3]+4107603335&4294967295,i=n+(o^e&((r=o+(i<<14&4294967295|i>>>18))^o))+s[8]+1163531501&4294967295,i=e+(r^o&((n=r+(i<<20&4294967295|i>>>12))^r))+s[13]+2850285829&4294967295,i=o+(n^r&((e=n+(i<<5&4294967295|i>>>27))^n))+s[2]+4243563512&4294967295,o=e+(i<<9&4294967295|i>>>23),i=r+(e^n&(o^e))+s[7]+1735328473&4294967295,i=n+(o^e&((r=o+(i<<14&4294967295|i>>>18))^o))+s[12]+2368359562&4294967295,i=e+((n=r+(i<<20&4294967295|i>>>12))^r^o)+s[5]+4294588738&4294967295,i=o+((e=n+(i<<4&4294967295|i>>>28))^n^r)+s[8]+2272392833&4294967295,o=e+(i<<11&4294967295|i>>>21),i=r+(o^e^n)+s[11]+1839030562&4294967295,i=n+((r=o+(i<<16&4294967295|i>>>16))^o^e)+s[14]+4259657740&4294967295,i=e+((n=r+(i<<23&4294967295|i>>>9))^r^o)+s[1]+2763975236&4294967295,i=o+((e=n+(i<<4&4294967295|i>>>28))^n^r)+s[4]+1272893353&4294967295,o=e+(i<<11&4294967295|i>>>21),i=r+(o^e^n)+s[7]+4139469664&4294967295,i=n+((r=o+(i<<16&4294967295|i>>>16))^o^e)+s[10]+3200236656&4294967295,i=e+((n=r+(i<<23&4294967295|i>>>9))^r^o)+s[13]+681279174&4294967295,i=o+((e=n+(i<<4&4294967295|i>>>28))^n^r)+s[0]+3936430074&4294967295,o=e+(i<<11&4294967295|i>>>21),i=r+(o^e^n)+s[3]+3572445317&4294967295,i=n+((r=o+(i<<16&4294967295|i>>>16))^o^e)+s[6]+76029189&4294967295,i=e+((n=r+(i<<23&4294967295|i>>>9))^r^o)+s[9]+3654602809&4294967295,i=o+((e=n+(i<<4&4294967295|i>>>28))^n^r)+s[12]+3873151461&4294967295,o=e+(i<<11&4294967295|i>>>21),i=r+(o^e^n)+s[15]+530742520&4294967295,i=n+((r=o+(i<<16&4294967295|i>>>16))^o^e)+s[2]+3299628645&4294967295,i=e+(r^((n=r+(i<<23&4294967295|i>>>9))|~o))+s[0]+4096336452&4294967295,i=o+(n^((e=n+(i<<6&4294967295|i>>>26))|~r))+s[7]+1126891415&4294967295,o=e+(i<<10&4294967295|i>>>22),i=r+(e^(o|~n))+s[14]+2878612391&4294967295,i=n+(o^((r=o+(i<<15&4294967295|i>>>17))|~e))+s[5]+4237533241&4294967295,i=e+(r^((n=r+(i<<21&4294967295|i>>>11))|~o))+s[12]+1700485571&4294967295,i=o+(n^((e=n+(i<<6&4294967295|i>>>26))|~r))+s[3]+2399980690&4294967295,o=e+(i<<10&4294967295|i>>>22),i=r+(e^(o|~n))+s[10]+4293915773&4294967295,i=n+(o^((r=o+(i<<15&4294967295|i>>>17))|~e))+s[1]+2240044497&4294967295,i=e+(r^((n=r+(i<<21&4294967295|i>>>11))|~o))+s[8]+1873313359&4294967295,i=o+(n^((e=n+(i<<6&4294967295|i>>>26))|~r))+s[15]+4264355552&4294967295,o=e+(i<<10&4294967295|i>>>22),i=r+(e^(o|~n))+s[6]+2734768916&4294967295,i=n+(o^((r=o+(i<<15&4294967295|i>>>17))|~e))+s[13]+1309151649&4294967295,i=e+(r^((n=r+(i<<21&4294967295|i>>>11))|~o))+s[4]+4149444226&4294967295,i=o+(n^((e=n+(i<<6&4294967295|i>>>26))|~r))+s[11]+3174756917&4294967295,o=e+(i<<10&4294967295|i>>>22),i=r+(e^(o|~n))+s[2]+718787259&4294967295,i=n+(o^((r=o+(i<<15&4294967295|i>>>17))|~e))+s[9]+3951481745&4294967295,t.g[0]=t.g[0]+e&4294967295,t.g[1]=t.g[1]+(r+(i<<21&4294967295|i>>>11))&4294967295,t.g[2]=t.g[2]+r&4294967295,t.g[3]=t.g[3]+o&4294967295}function s(t,e){this.h=e;const n=[];let s=!0;for(let r=t.length-1;r>=0;r--){const i=0|t[r];s&&i==e||(n[r]=i,s=!1)}this.g=n}!function(t,e){function n(){}n.prototype=e.prototype,t.F=e.prototype,t.prototype=new n,t.prototype.constructor=t,t.D=function(t,n,s){for(var r=Array(arguments.length-2),i=2;i<arguments.length;i++)r[i-2]=arguments[i];return e.prototype[n].apply(t,r)}}(e,function(){this.blockSize=-1}),e.prototype.u=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0},e.prototype.v=function(t,e){void 0===e&&(e=t.length);const s=e-this.blockSize,r=this.C;let i=this.h,o=0;for(;o<e;){if(0==i)for(;o<=s;)n(this,t,o),o+=this.blockSize;if("string"==typeof t){for(;o<e;)if(r[i++]=t.charCodeAt(o++),i==this.blockSize){n(this,r),i=0;break}}else for(;o<e;)if(r[i++]=t[o++],i==this.blockSize){n(this,r),i=0;break}}this.h=i,this.o+=e},e.prototype.A=function(){var t=Array((this.h<56?this.blockSize:2*this.blockSize)-this.h);t[0]=128;for(var e=1;e<t.length-8;++e)t[e]=0;e=8*this.o;for(var n=t.length-8;n<t.length;++n)t[n]=255&e,e/=256;for(this.v(t),t=Array(16),e=0,n=0;n<4;++n)for(let s=0;s<32;s+=8)t[e++]=this.g[n]>>>s&255;return t};var r={};function i(t){return-128<=t&&t<128?function(t,e){var n=r;return Object.prototype.hasOwnProperty.call(n,t)?n[t]:n[t]=e(t)}(t,function(t){return new s([0|t],t<0?-1:0)}):new s([0|t],t<0?-1:0)}function o(t){if(isNaN(t)||!isFinite(t))return a;if(t<0)return d(o(-t));const e=[];let n=1;for(let s=0;t>=n;s++)e[s]=t/n|0,n*=4294967296;return new s(e,0)}var a=i(0),u=i(1),c=i(16777216);function h(t){if(0!=t.h)return!1;for(let e=0;e<t.g.length;e++)if(0!=t.g[e])return!1;return!0}function l(t){return-1==t.h}function d(t){const e=t.g.length,n=[];for(let s=0;s<e;s++)n[s]=~t.g[s];return new s(n,~t.h).add(u)}function f(t,e){return t.add(d(e))}function m(t,e){for(;(65535&t[e])!=t[e];)t[e+1]+=t[e]>>>16,t[e]&=65535,e++}function g(t,e){this.g=t,this.h=e}function p(t,e){if(h(e))throw Error("division by zero");if(h(t))return new g(a,a);if(l(t))return e=p(d(t),e),new g(d(e.g),d(e.h));if(l(e))return e=p(t,d(e)),new g(d(e.g),e.h);if(t.g.length>30){if(l(t)||l(e))throw Error("slowDivide_ only works with positive integers.");for(var n=u,s=e;s.l(t)<=0;)n=y(n),s=y(s);var r=v(n,1),i=v(s,1);for(s=v(s,2),n=v(n,2);!h(s);){var c=i.add(s);c.l(t)<=0&&(r=r.add(n),i=c),s=v(s,1),n=v(n,1)}return e=f(t,r.j(e)),new g(r,e)}for(r=a;t.l(e)>=0;){for(n=Math.max(1,Math.floor(t.m()/e.m())),s=(s=Math.ceil(Math.log(n)/Math.LN2))<=48?1:Math.pow(2,s-48),c=(i=o(n)).j(e);l(c)||c.l(t)>0;)c=(i=o(n-=s)).j(e);h(i)&&(i=u),r=r.add(i),t=f(t,c)}return new g(r,t)}function y(t){const e=t.g.length+1,n=[];for(let s=0;s<e;s++)n[s]=t.i(s)<<1|t.i(s-1)>>>31;return new s(n,t.h)}function v(t,e){const n=e>>5;e%=32;const r=t.g.length-n,i=[];for(let s=0;s<r;s++)i[s]=e>0?t.i(s+n)>>>e|t.i(s+n+1)<<32-e:t.i(s+n);return new s(i,t.h)}(t=s.prototype).m=function(){if(l(this))return-d(this).m();let t=0,e=1;for(let n=0;n<this.g.length;n++){const s=this.i(n);t+=(s>=0?s:4294967296+s)*e,e*=4294967296}return t},t.toString=function(t){if((t=t||10)<2||36<t)throw Error("radix out of range: "+t);if(h(this))return"0";if(l(this))return"-"+d(this).toString(t);const e=o(Math.pow(t,6));var n=this;let s="";for(;;){const r=p(n,e).g;let i=(((n=f(n,r.j(e))).g.length>0?n.g[0]:n.h)>>>0).toString(t);if(h(n=r))return i+s;for(;i.length<6;)i="0"+i;s=i+s}},t.i=function(t){return t<0?0:t<this.g.length?this.g[t]:this.h},t.l=function(t){return l(t=f(this,t))?-1:h(t)?0:1},t.abs=function(){return l(this)?d(this):this},t.add=function(t){const e=Math.max(this.g.length,t.g.length),n=[];let r=0;for(let s=0;s<=e;s++){let e=r+(65535&this.i(s))+(65535&t.i(s)),i=(e>>>16)+(this.i(s)>>>16)+(t.i(s)>>>16);r=i>>>16,e&=65535,i&=65535,n[s]=i<<16|e}return new s(n,-2147483648&n[n.length-1]?-1:0)},t.j=function(t){if(h(this)||h(t))return a;if(l(this))return l(t)?d(this).j(d(t)):d(d(this).j(t));if(l(t))return d(this.j(d(t)));if(this.l(c)<0&&t.l(c)<0)return o(this.m()*t.m());const e=this.g.length+t.g.length,n=[];for(var r=0;r<2*e;r++)n[r]=0;for(r=0;r<this.g.length;r++)for(let e=0;e<t.g.length;e++){const s=this.i(r)>>>16,i=65535&this.i(r),o=t.i(e)>>>16,a=65535&t.i(e);n[2*r+2*e]+=i*a,m(n,2*r+2*e),n[2*r+2*e+1]+=s*a,m(n,2*r+2*e+1),n[2*r+2*e+1]+=i*o,m(n,2*r+2*e+1),n[2*r+2*e+2]+=s*o,m(n,2*r+2*e+2)}for(t=0;t<e;t++)n[t]=n[2*t+1]<<16|n[2*t];for(t=e;t<2*e;t++)n[t]=0;return new s(n,0)},t.B=function(t){return p(this,t).h},t.and=function(t){const e=Math.max(this.g.length,t.g.length),n=[];for(let s=0;s<e;s++)n[s]=this.i(s)&t.i(s);return new s(n,this.h&t.h)},t.or=function(t){const e=Math.max(this.g.length,t.g.length),n=[];for(let s=0;s<e;s++)n[s]=this.i(s)|t.i(s);return new s(n,this.h|t.h)},t.xor=function(t){const e=Math.max(this.g.length,t.g.length),n=[];for(let s=0;s<e;s++)n[s]=this.i(s)^t.i(s);return new s(n,this.h^t.h)},e.prototype.digest=e.prototype.A,e.prototype.reset=e.prototype.u,e.prototype.update=e.prototype.v,E=e,s.prototype.add=s.prototype.add,s.prototype.multiply=s.prototype.j,s.prototype.modulo=s.prototype.B,s.prototype.compare=s.prototype.l,s.prototype.toNumber=s.prototype.m,s.prototype.toString=s.prototype.toString,s.prototype.getBits=s.prototype.i,s.fromNumber=o,s.fromString=function t(e,n){if(0==e.length)throw Error("number format error: empty string");if((n=n||10)<2||36<n)throw Error("radix out of range: "+n);if("-"==e.charAt(0))return d(t(e.substring(1),n));if(e.indexOf("-")>=0)throw Error('number format error: interior "-" character');const s=o(Math.pow(n,8));let r=a;for(let a=0;a<e.length;a+=8){var i=Math.min(8,e.length-a);const t=parseInt(e.substring(a,a+i),n);i<8?(i=o(Math.pow(n,i)),r=r.j(i).add(o(t))):(r=r.j(s),r=r.add(o(t)))}return r},T=s}).apply(void 0!==S?S:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{});var _,x,C,A,D,N,k,R,M="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{};
/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/(function(){var t,e=Object.defineProperty;var n=function(t){t=["object"==typeof globalThis&&globalThis,t,"object"==typeof window&&window,"object"==typeof self&&self,"object"==typeof M&&M];for(var e=0;e<t.length;++e){var n=t[e];if(n&&n.Math==Math)return n}throw Error("Cannot find global object")}(this);function s(t,s){if(s)t:{var r=n;t=t.split(".");for(var i=0;i<t.length-1;i++){var o=t[i];if(!(o in r))break t;r=r[o]}(s=s(i=r[t=t[t.length-1]]))!=i&&null!=s&&e(r,t,{configurable:!0,writable:!0,value:s})}}s("Symbol.dispose",function(t){return t||Symbol("Symbol.dispose")}),s("Array.prototype.values",function(t){return t||function(){return this[Symbol.iterator]()}}),s("Object.entries",function(t){return t||function(t){var e,n=[];for(e in t)Object.prototype.hasOwnProperty.call(t,e)&&n.push([e,t[e]]);return n}});
/** @license
  
   Copyright The Closure Library Authors.
   SPDX-License-Identifier: Apache-2.0
  */
var r=r||{},i=this||self;function o(t){var e=typeof t;return"object"==e&&null!=t||"function"==e}function a(t,e,n){return t.call.apply(t.bind,arguments)}function u(t,e,n){return(u=a).apply(null,arguments)}function c(t,e){var n=Array.prototype.slice.call(arguments,1);return function(){var e=n.slice();return e.push.apply(e,arguments),t.apply(this,e)}}function h(t,e){function n(){}n.prototype=e.prototype,t.Z=e.prototype,t.prototype=new n,t.prototype.constructor=t,t.Ob=function(t,n,s){for(var r=Array(arguments.length-2),i=2;i<arguments.length;i++)r[i-2]=arguments[i];return e.prototype[n].apply(t,r)}}var l="undefined"!=typeof AsyncContext&&"function"==typeof AsyncContext.Snapshot?t=>t&&AsyncContext.Snapshot.wrap(t):t=>t;function d(t){const e=t.length;if(e>0){const n=Array(e);for(let s=0;s<e;s++)n[s]=t[s];return n}return[]}function f(t,e){for(let s=1;s<arguments.length;s++){const e=arguments[s];var n=typeof e;if("array"==(n="object"!=n?n:e?Array.isArray(e)?"array":n:"null")||"object"==n&&"number"==typeof e.length){n=t.length||0;const s=e.length||0;t.length=n+s;for(let r=0;r<s;r++)t[n+r]=e[r]}else t.push(e)}}function m(t){i.setTimeout(()=>{throw t},0)}function g(){var t=I;let e=null;return t.g&&(e=t.g,t.g=t.g.next,t.g||(t.h=null),e.next=null),e}var p=new class{constructor(t,e){this.i=t,this.j=e,this.h=0,this.g=null}get(){let t;return this.h>0?(this.h--,t=this.g,this.g=t.next,t.next=null):t=this.i(),t}}(()=>new y,t=>t.reset());class y{constructor(){this.next=this.g=this.h=null}set(t,e){this.h=t,this.g=e,this.next=null}reset(){this.next=this.g=this.h=null}}let v,w=!1,I=new class{constructor(){this.h=this.g=null}add(t,e){const n=p.get();n.set(t,e),this.h?this.h.next=n:this.g=n,this.h=n}},b=()=>{const t=Promise.resolve(void 0);v=()=>{t.then(T)}};function T(){for(var t;t=g();){try{t.h.call(t.g)}catch(n){m(n)}var e=p;e.j(t),e.h<100&&(e.h++,t.next=e.g,e.g=t)}w=!1}function E(){this.u=this.u,this.C=this.C}function S(t,e){this.type=t,this.g=this.target=e,this.defaultPrevented=!1}E.prototype.u=!1,E.prototype.dispose=function(){this.u||(this.u=!0,this.N())},E.prototype[Symbol.dispose]=function(){this.dispose()},E.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()},S.prototype.h=function(){this.defaultPrevented=!0};var O=function(){if(!i.addEventListener||!Object.defineProperty)return!1;var t=!1,e=Object.defineProperty({},"passive",{get:function(){t=!0}});try{const t=()=>{};i.addEventListener("test",t,e),i.removeEventListener("test",t,e)}catch(n){}return t}();function V(t){return/^[\s\xa0]*$/.test(t)}function P(t,e){S.call(this,t?t.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,t&&this.init(t,e)}h(P,S),P.prototype.init=function(t,e){const n=this.type=t.type,s=t.changedTouches&&t.changedTouches.length?t.changedTouches[0]:null;this.target=t.target||t.srcElement,this.g=e,(e=t.relatedTarget)||("mouseover"==n?e=t.fromElement:"mouseout"==n&&(e=t.toElement)),this.relatedTarget=e,s?(this.clientX=void 0!==s.clientX?s.clientX:s.pageX,this.clientY=void 0!==s.clientY?s.clientY:s.pageY,this.screenX=s.screenX||0,this.screenY=s.screenY||0):(this.clientX=void 0!==t.clientX?t.clientX:t.pageX,this.clientY=void 0!==t.clientY?t.clientY:t.pageY,this.screenX=t.screenX||0,this.screenY=t.screenY||0),this.button=t.button,this.key=t.key||"",this.ctrlKey=t.ctrlKey,this.altKey=t.altKey,this.shiftKey=t.shiftKey,this.metaKey=t.metaKey,this.pointerId=t.pointerId||0,this.pointerType=t.pointerType,this.state=t.state,this.i=t,t.defaultPrevented&&P.Z.h.call(this)},P.prototype.h=function(){P.Z.h.call(this);const t=this.i;t.preventDefault?t.preventDefault():t.returnValue=!1};var L="closure_listenable_"+(1e6*Math.random()|0),F=0;function U(t,e,n,s,r){this.listener=t,this.proxy=null,this.src=e,this.type=n,this.capture=!!s,this.ha=r,this.key=++F,this.da=this.fa=!1}function q(t){t.da=!0,t.listener=null,t.proxy=null,t.src=null,t.ha=null}function B(t,e,n){for(const s in t)e.call(n,t[s],s,t)}function j(t){const e={};for(const n in t)e[n]=t[n];return e}const z="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function K(t,e){let n,s;for(let r=1;r<arguments.length;r++){for(n in s=arguments[r],s)t[n]=s[n];for(let e=0;e<z.length;e++)n=z[e],Object.prototype.hasOwnProperty.call(s,n)&&(t[n]=s[n])}}function G(t){this.src=t,this.g={},this.h=0}function $(t,e){const n=e.type;if(n in t.g){var s,r=t.g[n],i=Array.prototype.indexOf.call(r,e,void 0);(s=i>=0)&&Array.prototype.splice.call(r,i,1),s&&(q(e),0==t.g[n].length&&(delete t.g[n],t.h--))}}function Q(t,e,n,s){for(let r=0;r<t.length;++r){const i=t[r];if(!i.da&&i.listener==e&&i.capture==!!n&&i.ha==s)return r}return-1}G.prototype.add=function(t,e,n,s,r){const i=t.toString();(t=this.g[i])||(t=this.g[i]=[],this.h++);const o=Q(t,e,s,r);return o>-1?(e=t[o],n||(e.fa=!1)):((e=new U(e,this.src,i,!!s,r)).fa=n,t.push(e)),e};var H="closure_lm_"+(1e6*Math.random()|0),X={};function Y(t,e,n,s,r){if(Array.isArray(e)){for(let i=0;i<e.length;i++)Y(t,e[i],n,s,r);return null}return n=st(n),t&&t[L]?t.J(e,n,!!o(s)&&!!s.capture,r):function(t,e,n,s,r,i){if(!e)throw Error("Invalid event type");const a=o(r)?!!r.capture:!!r;let u=et(t);if(u||(t[H]=u=new G(t)),n=u.add(e,n,s,a,i),n.proxy)return n;if(s=function(){function t(n){return e.call(t.src,t.listener,n)}const e=tt;return t}(),n.proxy=s,s.src=t,s.listener=n,t.addEventListener)O||(r=a),void 0===r&&(r=!1),t.addEventListener(e.toString(),s,r);else if(t.attachEvent)t.attachEvent(Z(e.toString()),s);else{if(!t.addListener||!t.removeListener)throw Error("addEventListener and attachEvent are unavailable.");t.addListener(s)}return n}(t,e,n,!1,s,r)}function W(t,e,n,s,r){if(Array.isArray(e))for(var i=0;i<e.length;i++)W(t,e[i],n,s,r);else s=o(s)?!!s.capture:!!s,n=st(n),t&&t[L]?(t=t.i,(i=String(e).toString())in t.g&&((n=Q(e=t.g[i],n,s,r))>-1&&(q(e[n]),Array.prototype.splice.call(e,n,1),0==e.length&&(delete t.g[i],t.h--)))):t&&(t=et(t))&&(e=t.g[e.toString()],t=-1,e&&(t=Q(e,n,s,r)),(n=t>-1?e[t]:null)&&J(n))}function J(t){if("number"!=typeof t&&t&&!t.da){var e=t.src;if(e&&e[L])$(e.i,t);else{var n=t.type,s=t.proxy;e.removeEventListener?e.removeEventListener(n,s,t.capture):e.detachEvent?e.detachEvent(Z(n),s):e.addListener&&e.removeListener&&e.removeListener(s),(n=et(e))?($(n,t),0==n.h&&(n.src=null,e[H]=null)):q(t)}}}function Z(t){return t in X?X[t]:X[t]="on"+t}function tt(t,e){if(t.da)t=!0;else{e=new P(e,this);const n=t.listener,s=t.ha||t.src;t.fa&&J(t),t=n.call(s,e)}return t}function et(t){return(t=t[H])instanceof G?t:null}var nt="__closure_events_fn_"+(1e9*Math.random()>>>0);function st(t){return"function"==typeof t?t:(t[nt]||(t[nt]=function(e){return t.handleEvent(e)}),t[nt])}function rt(){E.call(this),this.i=new G(this),this.M=this,this.G=null}function it(t,e){var n,s=t.G;if(s)for(n=[];s;s=s.G)n.push(s);if(t=t.M,s=e.type||e,"string"==typeof e)e=new S(e,t);else if(e instanceof S)e.target=e.target||t;else{var r=e;K(e=new S(s,t),r)}let i,o;if(r=!0,n)for(o=n.length-1;o>=0;o--)i=e.g=n[o],r=ot(i,s,!0,e)&&r;if(i=e.g=t,r=ot(i,s,!0,e)&&r,r=ot(i,s,!1,e)&&r,n)for(o=0;o<n.length;o++)i=e.g=n[o],r=ot(i,s,!1,e)&&r}function ot(t,e,n,s){if(!(e=t.i.g[String(e)]))return!0;e=e.concat();let r=!0;for(let i=0;i<e.length;++i){const o=e[i];if(o&&!o.da&&o.capture==n){const e=o.listener,n=o.ha||o.src;o.fa&&$(t.i,o),r=!1!==e.call(n,s)&&r}}return r&&!s.defaultPrevented}function at(t){t.g=function(t,e){if("function"!=typeof t){if(!t||"function"!=typeof t.handleEvent)throw Error("Invalid listener argument");t=u(t.handleEvent,t)}return Number(e)>2147483647?-1:i.setTimeout(t,e||0)}(()=>{t.g=null,t.i&&(t.i=!1,at(t))},t.l);const e=t.h;t.h=null,t.m.apply(null,e)}h(rt,E),rt.prototype[L]=!0,rt.prototype.removeEventListener=function(t,e,n,s){W(this,t,e,n,s)},rt.prototype.N=function(){if(rt.Z.N.call(this),this.i){var t=this.i;for(const e in t.g){const n=t.g[e];for(let t=0;t<n.length;t++)q(n[t]);delete t.g[e],t.h--}}this.G=null},rt.prototype.J=function(t,e,n,s){return this.i.add(String(t),e,!1,n,s)},rt.prototype.K=function(t,e,n,s){return this.i.add(String(t),e,!0,n,s)};class ut extends E{constructor(t,e){super(),this.m=t,this.l=e,this.h=null,this.i=!1,this.g=null}j(t){this.h=arguments,this.g?this.i=!0:at(this)}N(){super.N(),this.g&&(i.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function ct(t){E.call(this),this.h=t,this.g={}}h(ct,E);var ht=[];function lt(t){B(t.g,function(t,e){this.g.hasOwnProperty(e)&&J(t)},t),t.g={}}ct.prototype.N=function(){ct.Z.N.call(this),lt(this)},ct.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var dt=i.JSON.stringify,ft=i.JSON.parse,mt=class{stringify(t){return i.JSON.stringify(t,void 0)}parse(t){return i.JSON.parse(t,void 0)}};function gt(){}function pt(){}var yt={OPEN:"a",hb:"b",ERROR:"c",tb:"d"};function vt(){S.call(this,"d")}function wt(){S.call(this,"c")}h(vt,S),h(wt,S);var It={},bt=null;function Tt(){return bt=bt||new rt}function Et(t){S.call(this,It.Ia,t)}function St(t){const e=Tt();it(e,new Et(e))}function _t(t,e){S.call(this,It.STAT_EVENT,t),this.stat=e}function xt(t){const e=Tt();it(e,new _t(e,t))}function Ct(t,e){S.call(this,It.Ja,t),this.size=e}function At(t,e){if("function"!=typeof t)throw Error("Fn must not be null and must be a function");return i.setTimeout(function(){t()},e)}function Dt(){this.g=!0}function Nt(t,e,n,s){t.info(function(){return"XMLHTTP TEXT ("+e+"): "+function(t,e){if(!t.g)return e;if(!e)return null;try{const i=JSON.parse(e);if(i)for(t=0;t<i.length;t++)if(Array.isArray(i[t])){var n=i[t];if(!(n.length<2)){var s=n[1];if(Array.isArray(s)&&!(s.length<1)){var r=s[0];if("noop"!=r&&"stop"!=r&&"close"!=r)for(let t=1;t<s.length;t++)s[t]=""}}}return dt(i)}catch(i){return e}}(t,n)+(s?" "+s:"")})}It.Ia="serverreachability",h(Et,S),It.STAT_EVENT="statevent",h(_t,S),It.Ja="timingevent",h(Ct,S),Dt.prototype.ua=function(){this.g=!1},Dt.prototype.info=function(){};var kt,Rt={NO_ERROR:0,cb:1,qb:2,pb:3,kb:4,ob:5,rb:6,Ga:7,TIMEOUT:8,ub:9},Mt={ib:"complete",Fb:"success",ERROR:"error",Ga:"abort",xb:"ready",yb:"readystatechange",TIMEOUT:"timeout",sb:"incrementaldata",wb:"progress",lb:"downloadprogress",Nb:"uploadprogress"};function Ot(){}function Vt(t){return encodeURIComponent(String(t))}function Pt(t){var e=1;t=t.split(":");const n=[];for(;e>0&&t.length;)n.push(t.shift()),e--;return t.length&&n.push(t.join(":")),n}function Lt(t,e,n,s){this.j=t,this.i=e,this.l=n,this.S=s||1,this.V=new ct(this),this.H=45e3,this.J=null,this.o=!1,this.u=this.B=this.A=this.M=this.F=this.T=this.D=null,this.G=[],this.g=null,this.C=0,this.m=this.v=null,this.X=-1,this.K=!1,this.P=0,this.O=null,this.W=this.L=this.U=this.R=!1,this.h=new Ft}function Ft(){this.i=null,this.g="",this.h=!1}h(Ot,gt),Ot.prototype.g=function(){return new XMLHttpRequest},kt=new Ot;var Ut={},qt={};function Bt(t,e,n){t.M=1,t.A=de(ae(e)),t.u=n,t.R=!0,jt(t,null)}function jt(t,e){t.F=Date.now(),Gt(t),t.B=ae(t.A);var n=t.B,s=t.S;Array.isArray(s)||(s=[String(s)]),xe(n.i,"t",s),t.C=0,n=t.j.L,t.h=new Ft,t.g=fn(t.j,n?e:null,!t.u),t.P>0&&(t.O=new ut(u(t.Y,t,t.g),t.P)),e=t.V,n=t.g,s=t.ba;var r="readystatechange";Array.isArray(r)||(r&&(ht[0]=r.toString()),r=ht);for(let i=0;i<r.length;i++){const t=Y(n,r[i],s||e.handleEvent,!1,e.h||e);if(!t)break;e.g[t.key]=t}e=t.J?j(t.J):{},t.u?(t.v||(t.v="POST"),e["Content-Type"]="application/x-www-form-urlencoded",t.g.ea(t.B,t.v,t.u,e)):(t.v="GET",t.g.ea(t.B,t.v,null,e)),St(),function(t,e,n,s,r,i){t.info(function(){if(t.g)if(i){var o="",a=i.split("&");for(let t=0;t<a.length;t++){var u=a[t].split("=");if(u.length>1){const t=u[0];u=u[1];const e=t.split("_");o=e.length>=2&&"type"==e[1]?o+(t+"=")+u+"&":o+(t+"=redacted&")}}}else o=null;else o=i;return"XMLHTTP REQ ("+s+") [attempt "+r+"]: "+e+"\n"+n+"\n"+o})}(t.i,t.v,t.B,t.l,t.S,t.u)}function zt(t){return!!t.g&&("GET"==t.v&&2!=t.M&&t.j.Aa)}function Kt(t,e){var n=t.C,s=e.indexOf("\n",n);return-1==s?qt:(n=Number(e.substring(n,s)),isNaN(n)?Ut:(s+=1)+n>e.length?qt:(e=e.slice(s,s+n),t.C=s+n,e))}function Gt(t){t.T=Date.now()+t.H,$t(t,t.H)}function $t(t,e){if(null!=t.D)throw Error("WatchDog timer not null");t.D=At(u(t.aa,t),e)}function Qt(t){t.D&&(i.clearTimeout(t.D),t.D=null)}function Ht(t){0==t.j.I||t.K||un(t.j,t)}function Xt(t){Qt(t);var e=t.O;e&&"function"==typeof e.dispose&&e.dispose(),t.O=null,lt(t.V),t.g&&(e=t.g,t.g=null,e.abort(),e.dispose())}function Yt(t,e){try{var n=t.j;if(0!=n.I&&(n.g==t||ee(n.h,t)))if(!t.L&&ee(n.h,t)&&3==n.I){try{var s=n.Ba.g.parse(e)}catch(h){s=null}if(Array.isArray(s)&&3==s.length){var r=s;if(0==r[0]){t:if(!n.v){if(n.g){if(!(n.g.F+3e3<t.F))break t;an(n),Ye(n)}sn(n),xt(18)}}else n.xa=r[1],0<n.xa-n.K&&r[2]<37500&&n.F&&0==n.A&&!n.C&&(n.C=At(u(n.Va,n),6e3));te(n.h)<=1&&n.ta&&(n.ta=void 0)}else hn(n,11)}else if((t.L||n.g==t)&&an(n),!V(e))for(r=n.Ba.g.parse(e),e=0;e<r.length;e++){let u=r[e];const h=u[0];if(!(h<=n.K))if(n.K=h,u=u[1],2==n.I)if("c"==u[0]){n.M=u[1],n.ba=u[2];const e=u[3];null!=e&&(n.ka=e,n.j.info("VER="+n.ka));const r=u[4];null!=r&&(n.za=r,n.j.info("SVER="+n.za));const h=u[5];null!=h&&"number"==typeof h&&h>0&&(s=1.5*h,n.O=s,n.j.info("backChannelRequestTimeoutMs_="+s)),s=n;const l=t.g;if(l){const t=l.g?l.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(t){var i=s.h;i.g||-1==t.indexOf("spdy")&&-1==t.indexOf("quic")&&-1==t.indexOf("h2")||(i.j=i.l,i.g=new Set,i.h&&(ne(i,i.h),i.h=null))}if(s.G){const t=l.g?l.g.getResponseHeader("X-HTTP-Session-Id"):null;t&&(s.wa=t,le(s.J,s.G,t))}}n.I=3,n.l&&n.l.ra(),n.aa&&(n.T=Date.now()-t.F,n.j.info("Handshake RTT: "+n.T+"ms"));var o=t;if((s=n).na=dn(s,s.L?s.ba:null,s.W),o.L){se(s.h,o);var a=o,c=s.O;c&&(a.H=c),a.D&&(Qt(a),Gt(a)),s.g=o}else nn(s);n.i.length>0&&Je(n)}else"stop"!=u[0]&&"close"!=u[0]||hn(n,7);else 3==n.I&&("stop"==u[0]||"close"==u[0]?"stop"==u[0]?hn(n,7):Xe(n):"noop"!=u[0]&&n.l&&n.l.qa(u),n.A=0)}St()}catch(h){}}Lt.prototype.ba=function(t){t=t.target;const e=this.O;e&&3==Ge(t)?e.j():this.Y(t)},Lt.prototype.Y=function(t){try{if(t==this.g)t:{const u=Ge(this.g),c=this.g.ya();this.g.ca();if(!(u<3)&&(3!=u||this.g&&(this.h.h||this.g.la()||$e(this.g)))){this.K||4!=u||7==c||St(),Qt(this);var e=this.g.ca();this.X=e;var n=function(t){if(!zt(t))return t.g.la();const e=$e(t.g);if(""===e)return"";let n="";const s=e.length,r=4==Ge(t.g);if(!t.h.i){if("undefined"==typeof TextDecoder)return Xt(t),Ht(t),"";t.h.i=new i.TextDecoder}for(let i=0;i<s;i++)t.h.h=!0,n+=t.h.i.decode(e[i],{stream:!(r&&i==s-1)});return e.length=0,t.h.g+=n,t.C=0,t.h.g}(this);if(this.o=200==e,function(t,e,n,s,r,i,o){t.info(function(){return"XMLHTTP RESP ("+s+") [ attempt "+r+"]: "+e+"\n"+n+"\n"+i+" "+o})}(this.i,this.v,this.B,this.l,this.S,u,e),this.o){if(this.U&&!this.L){e:{if(this.g){var s,r=this.g;if((s=r.g?r.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!V(s)){var o=s;break e}}o=null}if(!(t=o)){this.o=!1,this.m=3,xt(12),Xt(this),Ht(this);break t}Nt(this.i,this.l,t,"Initial handshake response via X-HTTP-Initial-Response"),this.L=!0,Yt(this,t)}if(this.R){let e;for(t=!0;!this.K&&this.C<n.length;){if(e=Kt(this,n),e==qt){4==u&&(this.m=4,xt(14),t=!1),Nt(this.i,this.l,null,"[Incomplete Response]");break}if(e==Ut){this.m=4,xt(15),Nt(this.i,this.l,n,"[Invalid Chunk]"),t=!1;break}Nt(this.i,this.l,e,null),Yt(this,e)}if(zt(this)&&0!=this.C&&(this.h.g=this.h.g.slice(this.C),this.C=0),4!=u||0!=n.length||this.h.h||(this.m=1,xt(16),t=!1),this.o=this.o&&t,t){if(n.length>0&&!this.W){this.W=!0;var a=this.j;a.g==this&&a.aa&&!a.P&&(a.j.info("Great, no buffering proxy detected. Bytes received: "+n.length),rn(a),a.P=!0,xt(11))}}else Nt(this.i,this.l,n,"[Invalid Chunked Response]"),Xt(this),Ht(this)}else Nt(this.i,this.l,n,null),Yt(this,n);4==u&&Xt(this),this.o&&!this.K&&(4==u?un(this.j,this):(this.o=!1,Gt(this)))}else(function(t){const e={};t=(t.g&&Ge(t)>=2&&t.g.getAllResponseHeaders()||"").split("\r\n");for(let s=0;s<t.length;s++){if(V(t[s]))continue;var n=Pt(t[s]);const r=n[0];if("string"!=typeof(n=n[1]))continue;n=n.trim();const i=e[r]||[];e[r]=i,i.push(n)}!function(t,e){for(const n in t)e.call(void 0,t[n],n,t)}(e,function(t){return t.join(", ")})})(this.g),400==e&&n.indexOf("Unknown SID")>0?(this.m=3,xt(12)):(this.m=0,xt(13)),Xt(this),Ht(this)}}}catch(u){}},Lt.prototype.cancel=function(){this.K=!0,Xt(this)},Lt.prototype.aa=function(){this.D=null;const t=Date.now();t-this.T>=0?(function(t,e){t.info(function(){return"TIMEOUT: "+e})}(this.i,this.B),2!=this.M&&(St(),xt(17)),Xt(this),this.m=2,Ht(this)):$t(this,this.T-t)};var Wt=class{constructor(t,e){this.g=t,this.map=e}};function Jt(t){this.l=t||10,i.PerformanceNavigationTiming?t=(t=i.performance.getEntriesByType("navigation")).length>0&&("hq"==t[0].nextHopProtocol||"h2"==t[0].nextHopProtocol):t=!!(i.chrome&&i.chrome.loadTimes&&i.chrome.loadTimes()&&i.chrome.loadTimes().wasFetchedViaSpdy),this.j=t?this.l:1,this.g=null,this.j>1&&(this.g=new Set),this.h=null,this.i=[]}function Zt(t){return!!t.h||!!t.g&&t.g.size>=t.j}function te(t){return t.h?1:t.g?t.g.size:0}function ee(t,e){return t.h?t.h==e:!!t.g&&t.g.has(e)}function ne(t,e){t.g?t.g.add(e):t.h=e}function se(t,e){t.h&&t.h==e?t.h=null:t.g&&t.g.has(e)&&t.g.delete(e)}function re(t){if(null!=t.h)return t.i.concat(t.h.G);if(null!=t.g&&0!==t.g.size){let e=t.i;for(const n of t.g.values())e=e.concat(n.G);return e}return d(t.i)}Jt.prototype.cancel=function(){if(this.i=re(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&0!==this.g.size){for(const t of this.g.values())t.cancel();this.g.clear()}};var ie=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function oe(t){let e;this.g=this.o=this.j="",this.u=null,this.m=this.h="",this.l=!1,t instanceof oe?(this.l=t.l,ue(this,t.j),this.o=t.o,this.g=t.g,ce(this,t.u),this.h=t.h,he(this,Ce(t.i)),this.m=t.m):t&&(e=String(t).match(ie))?(this.l=!1,ue(this,e[1]||"",!0),this.o=fe(e[2]||""),this.g=fe(e[3]||"",!0),ce(this,e[4]),this.h=fe(e[5]||"",!0),he(this,e[6]||"",!0),this.m=fe(e[7]||"")):(this.l=!1,this.i=new be(null,this.l))}function ae(t){return new oe(t)}function ue(t,e,n){t.j=n?fe(e,!0):e,t.j&&(t.j=t.j.replace(/:$/,""))}function ce(t,e){if(e){if(e=Number(e),isNaN(e)||e<0)throw Error("Bad port number "+e);t.u=e}else t.u=null}function he(t,e,n){e instanceof be?(t.i=e,function(t,e){e&&!t.j&&(Te(t),t.i=null,t.g.forEach(function(t,e){const n=e.toLowerCase();e!=n&&(Ee(this,e),xe(this,n,t))},t)),t.j=e}(t.i,t.l)):(n||(e=me(e,we)),t.i=new be(e,t.l))}function le(t,e,n){t.i.set(e,n)}function de(t){return le(t,"zx",Math.floor(2147483648*Math.random()).toString(36)+Math.abs(Math.floor(2147483648*Math.random())^Date.now()).toString(36)),t}function fe(t,e){return t?e?decodeURI(t.replace(/%25/g,"%2525")):decodeURIComponent(t):""}function me(t,e,n){return"string"==typeof t?(t=encodeURI(t).replace(e,ge),n&&(t=t.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),t):null}function ge(t){return"%"+((t=t.charCodeAt(0))>>4&15).toString(16)+(15&t).toString(16)}oe.prototype.toString=function(){const t=[];var e=this.j;e&&t.push(me(e,pe,!0),":");var n=this.g;return(n||"file"==e)&&(t.push("//"),(e=this.o)&&t.push(me(e,pe,!0),"@"),t.push(Vt(n).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),null!=(n=this.u)&&t.push(":",String(n))),(n=this.h)&&(this.g&&"/"!=n.charAt(0)&&t.push("/"),t.push(me(n,"/"==n.charAt(0)?ve:ye,!0))),(n=this.i.toString())&&t.push("?",n),(n=this.m)&&t.push("#",me(n,Ie)),t.join("")},oe.prototype.resolve=function(t){const e=ae(this);let n=!!t.j;n?ue(e,t.j):n=!!t.o,n?e.o=t.o:n=!!t.g,n?e.g=t.g:n=null!=t.u;var s=t.h;if(n)ce(e,t.u);else if(n=!!t.h){if("/"!=s.charAt(0))if(this.g&&!this.h)s="/"+s;else{var r=e.h.lastIndexOf("/");-1!=r&&(s=e.h.slice(0,r+1)+s)}if(".."==(r=s)||"."==r)s="";else if(-1!=r.indexOf("./")||-1!=r.indexOf("/.")){s=0==r.lastIndexOf("/",0),r=r.split("/");const t=[];for(let e=0;e<r.length;){const n=r[e++];"."==n?s&&e==r.length&&t.push(""):".."==n?((t.length>1||1==t.length&&""!=t[0])&&t.pop(),s&&e==r.length&&t.push("")):(t.push(n),s=!0)}s=t.join("/")}else s=r}return n?e.h=s:n=""!==t.i.toString(),n?he(e,Ce(t.i)):n=!!t.m,n&&(e.m=t.m),e};var pe=/[#\/\?@]/g,ye=/[#\?:]/g,ve=/[#\?]/g,we=/[#\?@]/g,Ie=/#/g;function be(t,e){this.h=this.g=null,this.i=t||null,this.j=!!e}function Te(t){t.g||(t.g=new Map,t.h=0,t.i&&function(t,e){if(t){t=t.split("&");for(let n=0;n<t.length;n++){const s=t[n].indexOf("=");let r,i=null;s>=0?(r=t[n].substring(0,s),i=t[n].substring(s+1)):r=t[n],e(r,i?decodeURIComponent(i.replace(/\+/g," ")):"")}}}(t.i,function(e,n){t.add(decodeURIComponent(e.replace(/\+/g," ")),n)}))}function Ee(t,e){Te(t),e=Ae(t,e),t.g.has(e)&&(t.i=null,t.h-=t.g.get(e).length,t.g.delete(e))}function Se(t,e){return Te(t),e=Ae(t,e),t.g.has(e)}function _e(t,e){Te(t);let n=[];if("string"==typeof e)Se(t,e)&&(n=n.concat(t.g.get(Ae(t,e))));else for(t=Array.from(t.g.values()),e=0;e<t.length;e++)n=n.concat(t[e]);return n}function xe(t,e,n){Ee(t,e),n.length>0&&(t.i=null,t.g.set(Ae(t,e),d(n)),t.h+=n.length)}function Ce(t){const e=new be;return e.i=t.i,t.g&&(e.g=new Map(t.g),e.h=t.h),e}function Ae(t,e){return e=String(e),t.j&&(e=e.toLowerCase()),e}function De(t,e,n,s,r){try{r&&(r.onload=null,r.onerror=null,r.onabort=null,r.ontimeout=null),s(n)}catch(i){}}function Ne(){this.g=new mt}function ke(t){this.i=t.Sb||null,this.h=t.ab||!1}function Re(t,e){rt.call(this),this.H=t,this.o=e,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.A=new Headers,this.h=null,this.F="GET",this.D="",this.g=!1,this.B=this.j=this.l=null,this.v=new AbortController}function Me(t){t.j.read().then(t.Ma.bind(t)).catch(t.ga.bind(t))}function Oe(t){t.readyState=4,t.l=null,t.j=null,t.B=null,Ve(t)}function Ve(t){t.onreadystatechange&&t.onreadystatechange.call(t)}function Pe(t){let e="";return B(t,function(t,n){e+=n,e+=":",e+=t,e+="\r\n"}),e}function Le(t,e,n){t:{for(s in n){var s=!1;break t}s=!0}s||(n=Pe(n),"string"==typeof t?null!=n&&Vt(n):le(t,e,n))}function Fe(t){rt.call(this),this.headers=new Map,this.L=t||null,this.h=!1,this.g=null,this.D="",this.o=0,this.l="",this.j=this.B=this.v=this.A=!1,this.m=null,this.F="",this.H=!1}(t=be.prototype).add=function(t,e){Te(this),this.i=null,t=Ae(this,t);let n=this.g.get(t);return n||this.g.set(t,n=[]),n.push(e),this.h+=1,this},t.forEach=function(t,e){Te(this),this.g.forEach(function(n,s){n.forEach(function(n){t.call(e,n,s,this)},this)},this)},t.set=function(t,e){return Te(this),this.i=null,Se(this,t=Ae(this,t))&&(this.h-=this.g.get(t).length),this.g.set(t,[e]),this.h+=1,this},t.get=function(t,e){return t&&(t=_e(this,t)).length>0?String(t[0]):e},t.toString=function(){if(this.i)return this.i;if(!this.g)return"";const t=[],e=Array.from(this.g.keys());for(let s=0;s<e.length;s++){var n=e[s];const r=Vt(n);n=_e(this,n);for(let e=0;e<n.length;e++){let s=r;""!==n[e]&&(s+="="+Vt(n[e])),t.push(s)}}return this.i=t.join("&")},h(ke,gt),ke.prototype.g=function(){return new Re(this.i,this.h)},h(Re,rt),(t=Re.prototype).open=function(t,e){if(0!=this.readyState)throw this.abort(),Error("Error reopening a connection");this.F=t,this.D=e,this.readyState=1,Ve(this)},t.send=function(t){if(1!=this.readyState)throw this.abort(),Error("need to call open() first. ");if(this.v.signal.aborted)throw this.abort(),Error("Request was aborted.");this.g=!0;const e={headers:this.A,method:this.F,credentials:this.m,cache:void 0,signal:this.v.signal};t&&(e.body=t),(this.H||i).fetch(new Request(this.D,e)).then(this.Pa.bind(this),this.ga.bind(this))},t.abort=function(){this.response=this.responseText="",this.A=new Headers,this.status=0,this.v.abort(),this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),this.readyState>=1&&this.g&&4!=this.readyState&&(this.g=!1,Oe(this)),this.readyState=0},t.Pa=function(t){if(this.g&&(this.l=t,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=t.headers,this.readyState=2,Ve(this)),this.g&&(this.readyState=3,Ve(this),this.g)))if("arraybuffer"===this.responseType)t.arrayBuffer().then(this.Na.bind(this),this.ga.bind(this));else if(void 0!==i.ReadableStream&&"body"in t){if(this.j=t.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.B=new TextDecoder;Me(this)}else t.text().then(this.Oa.bind(this),this.ga.bind(this))},t.Ma=function(t){if(this.g){if(this.o&&t.value)this.response.push(t.value);else if(!this.o){var e=t.value?t.value:new Uint8Array(0);(e=this.B.decode(e,{stream:!t.done}))&&(this.response=this.responseText+=e)}t.done?Oe(this):Ve(this),3==this.readyState&&Me(this)}},t.Oa=function(t){this.g&&(this.response=this.responseText=t,Oe(this))},t.Na=function(t){this.g&&(this.response=t,Oe(this))},t.ga=function(){this.g&&Oe(this)},t.setRequestHeader=function(t,e){this.A.append(t,e)},t.getResponseHeader=function(t){return this.h&&this.h.get(t.toLowerCase())||""},t.getAllResponseHeaders=function(){if(!this.h)return"";const t=[],e=this.h.entries();for(var n=e.next();!n.done;)n=n.value,t.push(n[0]+": "+n[1]),n=e.next();return t.join("\r\n")},Object.defineProperty(Re.prototype,"withCredentials",{get:function(){return"include"===this.m},set:function(t){this.m=t?"include":"same-origin"}}),h(Fe,rt);var Ue=/^https?$/i,qe=["POST","PUT"];function Be(t,e){t.h=!1,t.g&&(t.j=!0,t.g.abort(),t.j=!1),t.l=e,t.o=5,je(t),Ke(t)}function je(t){t.A||(t.A=!0,it(t,"complete"),it(t,"error"))}function ze(t){if(t.h&&void 0!==r)if(t.v&&4==Ge(t))setTimeout(t.Ca.bind(t),0);else if(it(t,"readystatechange"),4==Ge(t)){t.h=!1;try{const r=t.ca();t:switch(r){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var e=!0;break t;default:e=!1}var n;if(!(n=e)){var s;if(s=0===r){let e=String(t.D).match(ie)[1]||null;!e&&i.self&&i.self.location&&(e=i.self.location.protocol.slice(0,-1)),s=!Ue.test(e?e.toLowerCase():"")}n=s}if(n)it(t,"complete"),it(t,"success");else{t.o=6;try{var o=Ge(t)>2?t.g.statusText:""}catch(a){o=""}t.l=o+" ["+t.ca()+"]",je(t)}}finally{Ke(t)}}}function Ke(t,e){if(t.g){t.m&&(clearTimeout(t.m),t.m=null);const s=t.g;t.g=null,e||it(t,"ready");try{s.onreadystatechange=null}catch(n){}}}function Ge(t){return t.g?t.g.readyState:0}function $e(t){try{if(!t.g)return null;if("response"in t.g)return t.g.response;switch(t.F){case"":case"text":return t.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in t.g)return t.g.mozResponseArrayBuffer}return null}catch(e){return null}}function Qe(t,e,n){return n&&n.internalChannelParams&&n.internalChannelParams[t]||e}function He(t){this.za=0,this.i=[],this.j=new Dt,this.ba=this.na=this.J=this.W=this.g=this.wa=this.G=this.H=this.u=this.U=this.o=null,this.Ya=this.V=0,this.Sa=Qe("failFast",!1,t),this.F=this.C=this.v=this.m=this.l=null,this.X=!0,this.xa=this.K=-1,this.Y=this.A=this.D=0,this.Qa=Qe("baseRetryDelayMs",5e3,t),this.Za=Qe("retryDelaySeedMs",1e4,t),this.Ta=Qe("forwardChannelMaxRetries",2,t),this.va=Qe("forwardChannelRequestTimeoutMs",2e4,t),this.ma=t&&t.xmlHttpFactory||void 0,this.Ua=t&&t.Rb||void 0,this.Aa=t&&t.useFetchStreams||!1,this.O=void 0,this.L=t&&t.supportsCrossDomainXhr||!1,this.M="",this.h=new Jt(t&&t.concurrentRequestLimit),this.Ba=new Ne,this.S=t&&t.fastHandshake||!1,this.R=t&&t.encodeInitMessageHeaders||!1,this.S&&this.R&&(this.R=!1),this.Ra=t&&t.Pb||!1,t&&t.ua&&this.j.ua(),t&&t.forceLongPolling&&(this.X=!1),this.aa=!this.S&&this.X&&t&&t.detectBufferingProxy||!1,this.ia=void 0,t&&t.longPollingTimeout&&t.longPollingTimeout>0&&(this.ia=t.longPollingTimeout),this.ta=void 0,this.T=0,this.P=!1,this.ja=this.B=null}function Xe(t){if(We(t),3==t.I){var e=t.V++,n=ae(t.J);if(le(n,"SID",t.M),le(n,"RID",e),le(n,"TYPE","terminate"),tn(t,n),(e=new Lt(t,t.j,e)).M=2,e.A=de(ae(n)),n=!1,i.navigator&&i.navigator.sendBeacon)try{n=i.navigator.sendBeacon(e.A.toString(),"")}catch(s){}!n&&i.Image&&((new Image).src=e.A,n=!0),n||(e.g=fn(e.j,null),e.g.ea(e.A)),e.F=Date.now(),Gt(e)}ln(t)}function Ye(t){t.g&&(rn(t),t.g.cancel(),t.g=null)}function We(t){Ye(t),t.v&&(i.clearTimeout(t.v),t.v=null),an(t),t.h.cancel(),t.m&&("number"==typeof t.m&&i.clearTimeout(t.m),t.m=null)}function Je(t){if(!Zt(t.h)&&!t.m){t.m=!0;var e=t.Ea;v||b(),w||(v(),w=!0),I.add(e,t),t.D=0}}function Ze(t,e){var n;n=e?e.l:t.V++;const s=ae(t.J);le(s,"SID",t.M),le(s,"RID",n),le(s,"AID",t.K),tn(t,s),t.u&&t.o&&Le(s,t.u,t.o),n=new Lt(t,t.j,n,t.D+1),null===t.u&&(n.J=t.o),e&&(t.i=e.G.concat(t.i)),e=en(t,n,1e3),n.H=Math.round(.5*t.va)+Math.round(.5*t.va*Math.random()),ne(t.h,n),Bt(n,s,e)}function tn(t,e){t.H&&B(t.H,function(t,n){le(e,n,t)}),t.l&&B({},function(t,n){le(e,n,t)})}function en(t,e,n){n=Math.min(t.i.length,n);const s=t.l?u(t.l.Ka,t.l,t):null;t:{var r=t.i;let e=-1;for(;;){const t=["count="+n];-1==e?n>0?(e=r[0].g,t.push("ofs="+e)):e=0:t.push("ofs="+e);let u=!0;for(let h=0;h<n;h++){var i=r[h].g;const n=r[h].map;if((i-=e)<0)e=Math.max(0,r[h].g-100),u=!1;else try{i="req"+i+"_"||"";try{var a=n instanceof Map?n:Object.entries(n);for(const[e,n]of a){let s=n;o(n)&&(s=dt(n)),t.push(i+e+"="+encodeURIComponent(s))}}catch(c){throw t.push(i+"type="+encodeURIComponent("_badmap")),c}}catch(c){s&&s(n)}}if(u){a=t.join("&");break t}}a=void 0}return t=t.i.splice(0,n),e.G=t,a}function nn(t){if(!t.g&&!t.v){t.Y=1;var e=t.Da;v||b(),w||(v(),w=!0),I.add(e,t),t.A=0}}function sn(t){return!(t.g||t.v||t.A>=3)&&(t.Y++,t.v=At(u(t.Da,t),cn(t,t.A)),t.A++,!0)}function rn(t){null!=t.B&&(i.clearTimeout(t.B),t.B=null)}function on(t){t.g=new Lt(t,t.j,"rpc",t.Y),null===t.u&&(t.g.J=t.o),t.g.P=0;var e=ae(t.na);le(e,"RID","rpc"),le(e,"SID",t.M),le(e,"AID",t.K),le(e,"CI",t.F?"0":"1"),!t.F&&t.ia&&le(e,"TO",t.ia),le(e,"TYPE","xmlhttp"),tn(t,e),t.u&&t.o&&Le(e,t.u,t.o),t.O&&(t.g.H=t.O);var n=t.g;t=t.ba,n.M=1,n.A=de(ae(e)),n.u=null,n.R=!0,jt(n,t)}function an(t){null!=t.C&&(i.clearTimeout(t.C),t.C=null)}function un(t,e){var n=null;if(t.g==e){an(t),rn(t),t.g=null;var s=2}else{if(!ee(t.h,e))return;n=e.G,se(t.h,e),s=1}if(0!=t.I)if(e.o)if(1==s){n=e.u?e.u.length:0,e=Date.now()-e.F;var r=t.D;it(s=Tt(),new Ct(s,n)),Je(t)}else nn(t);else if(3==(r=e.m)||0==r&&e.X>0||!(1==s&&function(t,e){return!(te(t.h)>=t.h.j-(t.m?1:0)||(t.m?(t.i=e.G.concat(t.i),0):1==t.I||2==t.I||t.D>=(t.Sa?0:t.Ta)||(t.m=At(u(t.Ea,t,e),cn(t,t.D)),t.D++,0)))}(t,e)||2==s&&sn(t)))switch(n&&n.length>0&&(e=t.h,e.i=e.i.concat(n)),r){case 1:hn(t,5);break;case 4:hn(t,10);break;case 3:hn(t,6);break;default:hn(t,2)}}function cn(t,e){let n=t.Qa+Math.floor(Math.random()*t.Za);return t.isActive()||(n*=2),n*e}function hn(t,e){if(t.j.info("Error code "+e),2==e){var n=u(t.bb,t),s=t.Ua;const e=!s;s=new oe(s||"//www.google.com/images/cleardot.gif"),i.location&&"http"==i.location.protocol||ue(s,"https"),de(s),e?function(t,e){const n=new Dt;if(i.Image){const s=new Image;s.onload=c(De,n,"TestLoadImage: loaded",!0,e,s),s.onerror=c(De,n,"TestLoadImage: error",!1,e,s),s.onabort=c(De,n,"TestLoadImage: abort",!1,e,s),s.ontimeout=c(De,n,"TestLoadImage: timeout",!1,e,s),i.setTimeout(function(){s.ontimeout&&s.ontimeout()},1e4),s.src=t}else e(!1)}(s.toString(),n):function(t,e){new Dt;const n=new AbortController,s=setTimeout(()=>{n.abort(),De(0,0,!1,e)},1e4);fetch(t,{signal:n.signal}).then(t=>{clearTimeout(s),t.ok?De(0,0,!0,e):De(0,0,!1,e)}).catch(()=>{clearTimeout(s),De(0,0,!1,e)})}(s.toString(),n)}else xt(2);t.I=0,t.l&&t.l.pa(e),ln(t),We(t)}function ln(t){if(t.I=0,t.ja=[],t.l){const e=re(t.h);0==e.length&&0==t.i.length||(f(t.ja,e),f(t.ja,t.i),t.h.i.length=0,d(t.i),t.i.length=0),t.l.oa()}}function dn(t,e,n){var s=n instanceof oe?ae(n):new oe(n);if(""!=s.g)e&&(s.g=e+"."+s.g),ce(s,s.u);else{var r=i.location;s=r.protocol,e=e?e+"."+r.hostname:r.hostname,r=+r.port;const t=new oe(null);s&&ue(t,s),e&&(t.g=e),r&&ce(t,r),n&&(t.h=n),s=t}return n=t.G,e=t.wa,n&&e&&le(s,n,e),le(s,"VER",t.ka),tn(t,s),s}function fn(t,e,n){if(e&&!t.L)throw Error("Can't create secondary domain capable XhrIo object.");return(e=t.Aa&&!t.ma?new Fe(new ke({ab:n})):new Fe(t.ma)).Fa(t.L),e}function mn(){}function gn(){}function pn(t,e){rt.call(this),this.g=new He(e),this.l=t,this.h=e&&e.messageUrlParams||null,t=e&&e.messageHeaders||null,e&&e.clientProtocolHeaderRequired&&(t?t["X-Client-Protocol"]="webchannel":t={"X-Client-Protocol":"webchannel"}),this.g.o=t,t=e&&e.initMessageHeaders||null,e&&e.messageContentType&&(t?t["X-WebChannel-Content-Type"]=e.messageContentType:t={"X-WebChannel-Content-Type":e.messageContentType}),e&&e.sa&&(t?t["X-WebChannel-Client-Profile"]=e.sa:t={"X-WebChannel-Client-Profile":e.sa}),this.g.U=t,(t=e&&e.Qb)&&!V(t)&&(this.g.u=t),this.A=e&&e.supportsCrossDomainXhr||!1,this.v=e&&e.sendRawJson||!1,(e=e&&e.httpSessionIdParam)&&!V(e)&&(this.g.G=e,null!==(t=this.h)&&e in t&&(e in(t=this.h)&&delete t[e])),this.j=new wn(this)}function yn(t){vt.call(this),t.__headers__&&(this.headers=t.__headers__,this.statusCode=t.__status__,delete t.__headers__,delete t.__status__);var e=t.__sm__;if(e){t:{for(const n in e){t=n;break t}t=void 0}(this.i=t)&&(t=this.i,e=null!==e&&t in e?e[t]:void 0),this.data=e}else this.data=t}function vn(){wt.call(this),this.status=1}function wn(t){this.g=t}(t=Fe.prototype).Fa=function(t){this.H=t},t.ea=function(t,e,n,s){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+t);e=e?e.toUpperCase():"GET",this.D=t,this.l="",this.o=0,this.A=!1,this.h=!0,this.g=this.L?this.L.g():kt.g(),this.g.onreadystatechange=l(u(this.Ca,this));try{this.B=!0,this.g.open(e,String(t),!0),this.B=!1}catch(o){return void Be(this,o)}if(t=n||"",n=new Map(this.headers),s)if(Object.getPrototypeOf(s)===Object.prototype)for(var r in s)n.set(r,s[r]);else{if("function"!=typeof s.keys||"function"!=typeof s.get)throw Error("Unknown input type for opt_headers: "+String(s));for(const t of s.keys())n.set(t,s.get(t))}s=Array.from(n.keys()).find(t=>"content-type"==t.toLowerCase()),r=i.FormData&&t instanceof i.FormData,!(Array.prototype.indexOf.call(qe,e,void 0)>=0)||s||r||n.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[i,a]of n)this.g.setRequestHeader(i,a);this.F&&(this.g.responseType=this.F),"withCredentials"in this.g&&this.g.withCredentials!==this.H&&(this.g.withCredentials=this.H);try{this.m&&(clearTimeout(this.m),this.m=null),this.v=!0,this.g.send(t),this.v=!1}catch(o){Be(this,o)}},t.abort=function(t){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.o=t||7,it(this,"complete"),it(this,"abort"),Ke(this))},t.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),Ke(this,!0)),Fe.Z.N.call(this)},t.Ca=function(){this.u||(this.B||this.v||this.j?ze(this):this.Xa())},t.Xa=function(){ze(this)},t.isActive=function(){return!!this.g},t.ca=function(){try{return Ge(this)>2?this.g.status:-1}catch(t){return-1}},t.la=function(){try{return this.g?this.g.responseText:""}catch(t){return""}},t.La=function(t){if(this.g){var e=this.g.responseText;return t&&0==e.indexOf(t)&&(e=e.substring(t.length)),ft(e)}},t.ya=function(){return this.o},t.Ha=function(){return"string"==typeof this.l?this.l:String(this.l)},(t=He.prototype).ka=8,t.I=1,t.connect=function(t,e,n,s){xt(0),this.W=t,this.H=e||{},n&&void 0!==s&&(this.H.OSID=n,this.H.OAID=s),this.F=this.X,this.J=dn(this,null,this.W),Je(this)},t.Ea=function(t){if(this.m)if(this.m=null,1==this.I){if(!t){this.V=Math.floor(1e5*Math.random()),t=this.V++;const r=new Lt(this,this.j,t);let i=this.o;if(this.U&&(i?(i=j(i),K(i,this.U)):i=this.U),null!==this.u||this.R||(r.J=i,i=null),this.S)t:{for(var e=0,n=0;n<this.i.length;n++){var s=this.i[n];if(void 0===(s="__data__"in s.map&&"string"==typeof(s=s.map.__data__)?s.length:void 0))break;if((e+=s)>4096){e=n;break t}if(4096===e||n===this.i.length-1){e=n+1;break t}}e=1e3}else e=1e3;e=en(this,r,e),le(n=ae(this.J),"RID",t),le(n,"CVER",22),this.G&&le(n,"X-HTTP-Session-Id",this.G),tn(this,n),i&&(this.R?e="headers="+Vt(Pe(i))+"&"+e:this.u&&Le(n,this.u,i)),ne(this.h,r),this.Ra&&le(n,"TYPE","init"),this.S?(le(n,"$req",e),le(n,"SID","null"),r.U=!0,Bt(r,n,null)):Bt(r,n,e),this.I=2}}else 3==this.I&&(t?Ze(this,t):0==this.i.length||Zt(this.h)||Ze(this))},t.Da=function(){if(this.v=null,on(this),this.aa&&!(this.P||null==this.g||this.T<=0)){var t=4*this.T;this.j.info("BP detection timer enabled: "+t),this.B=At(u(this.Wa,this),t)}},t.Wa=function(){this.B&&(this.B=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.P=!0,xt(10),Ye(this),on(this))},t.Va=function(){null!=this.C&&(this.C=null,Ye(this),sn(this),xt(19))},t.bb=function(t){t?(this.j.info("Successfully pinged google.com"),xt(2)):(this.j.info("Failed to ping google.com"),xt(1))},t.isActive=function(){return!!this.l&&this.l.isActive(this)},(t=mn.prototype).ra=function(){},t.qa=function(){},t.pa=function(){},t.oa=function(){},t.isActive=function(){return!0},t.Ka=function(){},gn.prototype.g=function(t,e){return new pn(t,e)},h(pn,rt),pn.prototype.m=function(){this.g.l=this.j,this.A&&(this.g.L=!0),this.g.connect(this.l,this.h||void 0)},pn.prototype.close=function(){Xe(this.g)},pn.prototype.o=function(t){var e=this.g;if("string"==typeof t){var n={};n.__data__=t,t=n}else this.v&&((n={}).__data__=dt(t),t=n);e.i.push(new Wt(e.Ya++,t)),3==e.I&&Je(e)},pn.prototype.N=function(){this.g.l=null,delete this.j,Xe(this.g),delete this.g,pn.Z.N.call(this)},h(yn,vt),h(vn,wt),h(wn,mn),wn.prototype.ra=function(){it(this.g,"a")},wn.prototype.qa=function(t){it(this.g,new yn(t))},wn.prototype.pa=function(t){it(this.g,new vn)},wn.prototype.oa=function(){it(this.g,"b")},gn.prototype.createWebChannel=gn.prototype.g,pn.prototype.send=pn.prototype.o,pn.prototype.open=pn.prototype.m,pn.prototype.close=pn.prototype.close,R=function(){return new gn},k=function(){return Tt()},N=It,D={jb:0,mb:1,nb:2,Hb:3,Mb:4,Jb:5,Kb:6,Ib:7,Gb:8,Lb:9,PROXY:10,NOPROXY:11,Eb:12,Ab:13,Bb:14,zb:15,Cb:16,Db:17,fb:18,eb:19,gb:20},Rt.NO_ERROR=0,Rt.TIMEOUT=8,Rt.HTTP_ERROR=6,A=Rt,Mt.COMPLETE="complete",C=Mt,pt.EventType=yt,yt.OPEN="a",yt.CLOSE="b",yt.ERROR="c",yt.MESSAGE="d",rt.prototype.listen=rt.prototype.J,x=pt,Fe.prototype.listenOnce=Fe.prototype.K,Fe.prototype.getLastError=Fe.prototype.Ha,Fe.prototype.getLastErrorCode=Fe.prototype.ya,Fe.prototype.getStatus=Fe.prototype.ca,Fe.prototype.getResponseJson=Fe.prototype.La,Fe.prototype.getResponseText=Fe.prototype.la,Fe.prototype.send=Fe.prototype.ea,Fe.prototype.setWithCredentials=Fe.prototype.Fa,_=Fe}).apply(void 0!==M?M:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{});const O="@firebase/firestore",V="4.9.3";
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class P{constructor(t){this.uid=t}isAuthenticated(){return null!=this.uid}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(t){return t.uid===this.uid}}P.UNAUTHENTICATED=new P(null),P.GOOGLE_CREDENTIALS=new P("google-credentials-uid"),P.FIRST_PARTY=new P("first-party-uid"),P.MOCK_USER=new P("mock-user");
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let L="12.7.0";
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const F=new t("@firebase/firestore");function U(){return F.logLevel}function q(t,...e){if(F.logLevel<=o.DEBUG){const n=e.map(z);F.debug(`Firestore (${L}): ${t}`,...n)}}function B(t,...e){if(F.logLevel<=o.ERROR){const n=e.map(z);F.error(`Firestore (${L}): ${t}`,...n)}}function j(t,...e){if(F.logLevel<=o.WARN){const n=e.map(z);F.warn(`Firestore (${L}): ${t}`,...n)}}function z(t){if("string"==typeof t)return t;try{
/**
    * @license
    * Copyright 2020 Google LLC
    *
    * Licensed under the Apache License, Version 2.0 (the "License");
    * you may not use this file except in compliance with the License.
    * You may obtain a copy of the License at
    *
    *   http://www.apache.org/licenses/LICENSE-2.0
    *
    * Unless required by applicable law or agreed to in writing, software
    * distributed under the License is distributed on an "AS IS" BASIS,
    * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    * See the License for the specific language governing permissions and
    * limitations under the License.
    */
return e=t,JSON.stringify(e)}catch(n){return t}var e}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function K(t,e,n){let s="Unexpected state";"string"==typeof e?s=e:n=e,G(t,s,n)}function G(t,e,n){let s=`FIRESTORE (${L}) INTERNAL ASSERTION FAILED: ${e} (ID: ${t.toString(16)})`;if(void 0!==n)try{s+=" CONTEXT: "+JSON.stringify(n)}catch(r){s+=" CONTEXT: "+n}throw B(s),new Error(s)}function $(t,e,n,s){let r="Unexpected state";"string"==typeof n?r=n:s=n,t||G(e,r,s)}function Q(t,e){return t}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const H={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class X extends i{constructor(t,e){super(t,e),this.code=t,this.message=e,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Y{constructor(){this.promise=new Promise((t,e)=>{this.resolve=t,this.reject=e})}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class W{constructor(t,e){this.user=e,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${t}`)}}class J{getToken(){return Promise.resolve(null)}invalidateToken(){}start(t,e){t.enqueueRetryable(()=>e(P.UNAUTHENTICATED))}shutdown(){}}class Z{constructor(t){this.token=t,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(t,e){this.changeListener=e,t.enqueueRetryable(()=>e(this.token.user))}shutdown(){this.changeListener=null}}class tt{constructor(t){this.t=t,this.currentUser=P.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(t,e){$(void 0===this.o,42304);let n=this.i;const s=t=>this.i!==n?(n=this.i,e(t)):Promise.resolve();let r=new Y;this.o=()=>{this.i++,this.currentUser=this.u(),r.resolve(),r=new Y,t.enqueueRetryable(()=>s(this.currentUser))};const i=()=>{const e=r;t.enqueueRetryable(async()=>{await e.promise,await s(this.currentUser)})},o=t=>{q("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=t,this.o&&(this.auth.addAuthTokenListener(this.o),i())};this.t.onInit(t=>o(t)),setTimeout(()=>{if(!this.auth){const t=this.t.getImmediate({optional:!0});t?o(t):(q("FirebaseAuthCredentialsProvider","Auth not yet detected"),r.resolve(),r=new Y)}},0),i()}getToken(){const t=this.i,e=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(e).then(e=>this.i!==t?(q("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):e?($("string"==typeof e.accessToken,31837,{l:e}),new W(e.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.o&&this.auth.removeAuthTokenListener(this.o),this.o=void 0}u(){const t=this.auth&&this.auth.getUid();return $(null===t||"string"==typeof t,2055,{h:t}),new P(t)}}class et{constructor(t,e,n){this.P=t,this.T=e,this.I=n,this.type="FirstParty",this.user=P.FIRST_PARTY,this.A=new Map}R(){return this.I?this.I():null}get headers(){this.A.set("X-Goog-AuthUser",this.P);const t=this.R();return t&&this.A.set("Authorization",t),this.T&&this.A.set("X-Goog-Iam-Authorization-Token",this.T),this.A}}class nt{constructor(t,e,n){this.P=t,this.T=e,this.I=n}getToken(){return Promise.resolve(new et(this.P,this.T,this.I))}start(t,e){t.enqueueRetryable(()=>e(P.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class st{constructor(t){this.value=t,this.type="AppCheck",this.headers=new Map,t&&t.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class rt{constructor(t,e){this.V=e,this.forceRefresh=!1,this.appCheck=null,this.m=null,this.p=null,r(t)&&t.settings.appCheckToken&&(this.p=t.settings.appCheckToken)}start(t,e){$(void 0===this.o,3512);const n=t=>{null!=t.error&&q("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${t.error.message}`);const n=t.token!==this.m;return this.m=t.token,q("FirebaseAppCheckTokenProvider",`Received ${n?"new":"existing"} token.`),n?e(t.token):Promise.resolve()};this.o=e=>{t.enqueueRetryable(()=>n(e))};const s=t=>{q("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=t,this.o&&this.appCheck.addTokenListener(this.o)};this.V.onInit(t=>s(t)),setTimeout(()=>{if(!this.appCheck){const t=this.V.getImmediate({optional:!0});t?s(t):q("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){if(this.p)return Promise.resolve(new st(this.p));const t=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(t).then(t=>t?($("string"==typeof t.token,44558,{tokenResult:t}),this.m=t.token,new st(t.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.o&&this.appCheck.removeTokenListener(this.o),this.o=void 0}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function it(t){const e="undefined"!=typeof self&&(self.crypto||self.msCrypto),n=new Uint8Array(t);if(e&&"function"==typeof e.getRandomValues)e.getRandomValues(n);else for(let s=0;s<t;s++)n[s]=Math.floor(256*Math.random());return n}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ot{static newId(){const t=62*Math.floor(256/62);let e="";for(;e.length<20;){const n=it(40);for(let s=0;s<n.length;++s)e.length<20&&n[s]<t&&(e+="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".charAt(n[s]%62))}return e}}function at(t,e){return t<e?-1:t>e?1:0}function ut(t,e){const n=Math.min(t.length,e.length);for(let s=0;s<n;s++){const n=t.charAt(s),r=e.charAt(s);if(n!==r)return lt(n)===lt(r)?at(n,r):lt(n)?1:-1}return at(t.length,e.length)}const ct=55296,ht=57343;function lt(t){const e=t.charCodeAt(0);return e>=ct&&e<=ht}function dt(t,e,n){return t.length===e.length&&t.every((t,s)=>n(t,e[s]))}function ft(t){return t+"\0"}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mt="__name__";class gt{constructor(t,e,n){void 0===e?e=0:e>t.length&&K(637,{offset:e,range:t.length}),void 0===n?n=t.length-e:n>t.length-e&&K(1746,{length:n,range:t.length-e}),this.segments=t,this.offset=e,this.len=n}get length(){return this.len}isEqual(t){return 0===gt.comparator(this,t)}child(t){const e=this.segments.slice(this.offset,this.limit());return t instanceof gt?t.forEach(t=>{e.push(t)}):e.push(t),this.construct(e)}limit(){return this.offset+this.length}popFirst(t){return t=void 0===t?1:t,this.construct(this.segments,this.offset+t,this.length-t)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(t){return this.segments[this.offset+t]}isEmpty(){return 0===this.length}isPrefixOf(t){if(t.length<this.length)return!1;for(let e=0;e<this.length;e++)if(this.get(e)!==t.get(e))return!1;return!0}isImmediateParentOf(t){if(this.length+1!==t.length)return!1;for(let e=0;e<this.length;e++)if(this.get(e)!==t.get(e))return!1;return!0}forEach(t){for(let e=this.offset,n=this.limit();e<n;e++)t(this.segments[e])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(t,e){const n=Math.min(t.length,e.length);for(let s=0;s<n;s++){const n=gt.compareSegments(t.get(s),e.get(s));if(0!==n)return n}return at(t.length,e.length)}static compareSegments(t,e){const n=gt.isNumericId(t),s=gt.isNumericId(e);return n&&!s?-1:!n&&s?1:n&&s?gt.extractNumericId(t).compare(gt.extractNumericId(e)):ut(t,e)}static isNumericId(t){return t.startsWith("__id")&&t.endsWith("__")}static extractNumericId(t){return T.fromString(t.substring(4,t.length-2))}}class pt extends gt{construct(t,e,n){return new pt(t,e,n)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...t){const e=[];for(const n of t){if(n.indexOf("//")>=0)throw new X(H.INVALID_ARGUMENT,`Invalid segment (${n}). Paths must not contain // in them.`);e.push(...n.split("/").filter(t=>t.length>0))}return new pt(e)}static emptyPath(){return new pt([])}}const yt=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class vt extends gt{construct(t,e,n){return new vt(t,e,n)}static isValidIdentifier(t){return yt.test(t)}canonicalString(){return this.toArray().map(t=>(t=t.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),vt.isValidIdentifier(t)||(t="`"+t+"`"),t)).join(".")}toString(){return this.canonicalString()}isKeyField(){return 1===this.length&&this.get(0)===mt}static keyField(){return new vt([mt])}static fromServerFormat(t){const e=[];let n="",s=0;const r=()=>{if(0===n.length)throw new X(H.INVALID_ARGUMENT,`Invalid field path (${t}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);e.push(n),n=""};let i=!1;for(;s<t.length;){const e=t[s];if("\\"===e){if(s+1===t.length)throw new X(H.INVALID_ARGUMENT,"Path has trailing escape character: "+t);const e=t[s+1];if("\\"!==e&&"."!==e&&"`"!==e)throw new X(H.INVALID_ARGUMENT,"Path has invalid escape sequence: "+t);n+=e,s+=2}else"`"===e?(i=!i,s++):"."!==e||i?(n+=e,s++):(r(),s++)}if(r(),i)throw new X(H.INVALID_ARGUMENT,"Unterminated ` in path: "+t);return new vt(e)}static emptyPath(){return new vt([])}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wt{constructor(t){this.path=t}static fromPath(t){return new wt(pt.fromString(t))}static fromName(t){return new wt(pt.fromString(t).popFirst(5))}static empty(){return new wt(pt.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(t){return this.path.length>=2&&this.path.get(this.path.length-2)===t}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(t){return null!==t&&0===pt.comparator(this.path,t.path)}toString(){return this.path.toString()}static comparator(t,e){return pt.comparator(t.path,e.path)}static isDocumentKey(t){return t.length%2==0}static fromSegments(t){return new wt(new pt(t.slice()))}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function It(t,e,n){if(!n)throw new X(H.INVALID_ARGUMENT,`Function ${t}() cannot be called with an empty ${e}.`)}function bt(t){if(!wt.isDocumentKey(t))throw new X(H.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${t} has ${t.length}.`)}function Tt(t){if(wt.isDocumentKey(t))throw new X(H.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${t} has ${t.length}.`)}function Et(t){return"object"==typeof t&&null!==t&&(Object.getPrototypeOf(t)===Object.prototype||null===Object.getPrototypeOf(t))}function St(t){if(void 0===t)return"undefined";if(null===t)return"null";if("string"==typeof t)return t.length>20&&(t=`${t.substring(0,20)}...`),JSON.stringify(t);if("number"==typeof t||"boolean"==typeof t)return""+t;if("object"==typeof t){if(t instanceof Array)return"an array";{const n=(e=t).constructor?e.constructor.name:null;return n?`a custom ${n} object`:"an object"}}var e;return"function"==typeof t?"a function":K(12329,{type:typeof t})}function _t(t,e){if("_delegate"in t&&(t=t._delegate),!(t instanceof e)){if(e.name===t.constructor.name)throw new X(H.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const n=St(t);throw new X(H.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${n}`)}}return t}
/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xt(t,e){const n={typeString:t};return e&&(n.value=e),n}function Ct(t,e){if(!Et(t))throw new X(H.INVALID_ARGUMENT,"JSON must be an object");let n;for(const s in e)if(e[s]){const r=e[s].typeString,i="value"in e[s]?{value:e[s].value}:void 0;if(!(s in t)){n=`JSON missing required field: '${s}'`;break}const o=t[s];if(r&&typeof o!==r){n=`JSON field '${s}' must be a ${r}.`;break}if(void 0!==i&&o!==i.value){n=`Expected '${s}' field to equal '${i.value}'`;break}}if(n)throw new X(H.INVALID_ARGUMENT,n);return!0}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const At=-62135596800,Dt=1e6;class Nt{static now(){return Nt.fromMillis(Date.now())}static fromDate(t){return Nt.fromMillis(t.getTime())}static fromMillis(t){const e=Math.floor(t/1e3),n=Math.floor((t-1e3*e)*Dt);return new Nt(e,n)}constructor(t,e){if(this.seconds=t,this.nanoseconds=e,e<0)throw new X(H.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+e);if(e>=1e9)throw new X(H.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+e);if(t<At)throw new X(H.INVALID_ARGUMENT,"Timestamp seconds out of range: "+t);if(t>=253402300800)throw new X(H.INVALID_ARGUMENT,"Timestamp seconds out of range: "+t)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/Dt}_compareTo(t){return this.seconds===t.seconds?at(this.nanoseconds,t.nanoseconds):at(this.seconds,t.seconds)}isEqual(t){return t.seconds===this.seconds&&t.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{type:Nt._jsonSchemaVersion,seconds:this.seconds,nanoseconds:this.nanoseconds}}static fromJSON(t){if(Ct(t,Nt._jsonSchema))return new Nt(t.seconds,t.nanoseconds)}valueOf(){const t=this.seconds-At;return String(t).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}Nt._jsonSchemaVersion="firestore/timestamp/1.0",Nt._jsonSchema={type:xt("string",Nt._jsonSchemaVersion),seconds:xt("number"),nanoseconds:xt("number")};
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kt{static fromTimestamp(t){return new kt(t)}static min(){return new kt(new Nt(0,0))}static max(){return new kt(new Nt(253402300799,999999999))}constructor(t){this.timestamp=t}compareTo(t){return this.timestamp._compareTo(t.timestamp)}isEqual(t){return this.timestamp.isEqual(t.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rt{constructor(t,e,n,s){this.indexId=t,this.collectionGroup=e,this.fields=n,this.indexState=s}}function Mt(t){return t.fields.find(t=>2===t.kind)}function Ot(t){return t.fields.filter(t=>2!==t.kind)}Rt.UNKNOWN_ID=-1;class Vt{constructor(t,e){this.fieldPath=t,this.kind=e}}class Pt{constructor(t,e){this.sequenceNumber=t,this.offset=e}static empty(){return new Pt(0,Ft.min())}}function Lt(t){return new Ft(t.readTime,t.key,-1)}class Ft{constructor(t,e,n){this.readTime=t,this.documentKey=e,this.largestBatchId=n}static min(){return new Ft(kt.min(),wt.empty(),-1)}static max(){return new Ft(kt.max(),wt.empty(),-1)}}function Ut(t,e){let n=t.readTime.compareTo(e.readTime);return 0!==n?n:(n=wt.comparator(t.documentKey,e.documentKey),0!==n?n:at(t.largestBatchId,e.largestBatchId)
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */)}const qt="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class Bt{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(t){this.onCommittedListeners.push(t)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(t=>t())}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function jt(t){if(t.code!==H.FAILED_PRECONDITION||t.message!==qt)throw t;q("LocalStore","Unexpectedly lost primary lease")}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zt{constructor(t){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,t(t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)},t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)})}catch(t){return this.next(void 0,t)}next(t,e){return this.callbackAttached&&K(59440),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(e,this.error):this.wrapSuccess(t,this.result):new zt((n,s)=>{this.nextCallback=e=>{this.wrapSuccess(t,e).next(n,s)},this.catchCallback=t=>{this.wrapFailure(e,t).next(n,s)}})}toPromise(){return new Promise((t,e)=>{this.next(t,e)})}wrapUserFunction(t){try{const e=t();return e instanceof zt?e:zt.resolve(e)}catch(e){return zt.reject(e)}}wrapSuccess(t,e){return t?this.wrapUserFunction(()=>t(e)):zt.resolve(e)}wrapFailure(t,e){return t?this.wrapUserFunction(()=>t(e)):zt.reject(e)}static resolve(t){return new zt((e,n)=>{e(t)})}static reject(t){return new zt((e,n)=>{n(t)})}static waitFor(t){return new zt((e,n)=>{let s=0,r=0,i=!1;t.forEach(t=>{++s,t.next(()=>{++r,i&&r===s&&e()},t=>n(t))}),i=!0,r===s&&e()})}static or(t){let e=zt.resolve(!1);for(const n of t)e=e.next(t=>t?zt.resolve(t):n());return e}static forEach(t,e){const n=[];return t.forEach((t,s)=>{n.push(e.call(this,t,s))}),this.waitFor(n)}static mapArray(t,e){return new zt((n,s)=>{const r=t.length,i=new Array(r);let o=0;for(let a=0;a<r;a++){const u=a;e(t[u]).next(t=>{i[u]=t,++o,o===r&&n(i)},t=>s(t))}})}static doWhile(t,e){return new zt((n,s)=>{const r=()=>{!0===t()?e().next(()=>{r()},s):n()};r()})}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Kt="SimpleDb";class Gt{static open(t,e,n,s){try{return new Gt(e,t.transaction(s,n))}catch(r){throw new Xt(e,r)}}constructor(t,e){this.action=t,this.transaction=e,this.aborted=!1,this.S=new Y,this.transaction.oncomplete=()=>{this.S.resolve()},this.transaction.onabort=()=>{e.error?this.S.reject(new Xt(t,e.error)):this.S.resolve()},this.transaction.onerror=e=>{const n=te(e.target.error);this.S.reject(new Xt(t,n))}}get D(){return this.S.promise}abort(t){t&&this.S.reject(t),this.aborted||(q(Kt,"Aborting transaction:",t?t.message:"Client-initiated abort"),this.aborted=!0,this.transaction.abort())}C(){const t=this.transaction;this.aborted||"function"!=typeof t.commit||t.commit()}store(t){const e=this.transaction.objectStore(t);return new Wt(e)}}class $t{static delete(t){return q(Kt,"Removing database:",t),Jt(w().indexedDB.deleteDatabase(t)).toPromise()}static v(){if(!I())return!1;if($t.F())return!0;const t=y(),e=$t.M(t),n=0<e&&e<10,s=Qt(t),r=0<s&&s<4.5;return!(t.indexOf("MSIE ")>0||t.indexOf("Trident/")>0||t.indexOf("Edge/")>0||n||r)}static F(){var t;return"undefined"!=typeof process&&"YES"===(null==(t=process.__PRIVATE_env)?void 0:t.__PRIVATE_USE_MOCK_PERSISTENCE)}static O(t,e){return t.store(e)}static M(t){const e=t.match(/i(?:phone|pad|pod) os ([\d_]+)/i),n=e?e[1].split("_").slice(0,2).join("."):"-1";return Number(n)}constructor(t,e,n){this.name=t,this.version=e,this.N=n,this.B=null,12.2===$t.M(y())&&B("Firestore persistence suffers from a bug in iOS 12.2 Safari that may cause your app to stop working. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.")}async L(t){return this.db||(q(Kt,"Opening database:",this.name),this.db=await new Promise((e,n)=>{const s=indexedDB.open(this.name,this.version);s.onsuccess=t=>{const n=t.target.result;e(n)},s.onblocked=()=>{n(new Xt(t,"Cannot upgrade IndexedDB schema while another tab is open. Close all tabs that access Firestore and reload this page to proceed."))},s.onerror=e=>{const s=e.target.error;"VersionError"===s.name?n(new X(H.FAILED_PRECONDITION,"A newer version of the Firestore SDK was previously used and so the persisted data is not compatible with the version of the SDK you are now using. The SDK will operate with persistence disabled. If you need persistence, please re-upgrade to a newer version of the SDK or else clear the persisted IndexedDB data for your app to start fresh.")):"InvalidStateError"===s.name?n(new X(H.FAILED_PRECONDITION,"Unable to open an IndexedDB connection. This could be due to running in a private browsing session on a browser whose private browsing sessions do not support IndexedDB: "+s)):n(new Xt(t,s))},s.onupgradeneeded=t=>{q(Kt,'Database "'+this.name+'" requires upgrade from version:',t.oldVersion);const e=t.target.result;this.N.k(e,s.transaction,t.oldVersion,this.version).next(()=>{q(Kt,"Database upgrade to version "+this.version+" complete")})}})),this.q&&(this.db.onversionchange=t=>this.q(t)),this.db}$(t){this.q=t,this.db&&(this.db.onversionchange=e=>t(e))}async runTransaction(t,e,n,s){const r="readonly"===e;let i=0;for(;;){++i;try{this.db=await this.L(t);const e=Gt.open(this.db,t,r?"readonly":"readwrite",n),i=s(e).next(t=>(e.C(),t)).catch(t=>(e.abort(t),zt.reject(t))).toPromise();return i.catch(()=>{}),await e.D,i}catch(o){const t=o,e="FirebaseError"!==t.name&&i<3;if(q(Kt,"Transaction failed with error:",t.message,"Retrying:",e),this.close(),!e)return Promise.reject(t)}}}close(){this.db&&this.db.close(),this.db=void 0}}function Qt(t){const e=t.match(/Android ([\d.]+)/i),n=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(n)}class Ht{constructor(t){this.U=t,this.K=!1,this.W=null}get isDone(){return this.K}get G(){return this.W}set cursor(t){this.U=t}done(){this.K=!0}j(t){this.W=t}delete(){return Jt(this.U.delete())}}class Xt extends X{constructor(t,e){super(H.UNAVAILABLE,`IndexedDB transaction '${t}' failed: ${e}`),this.name="IndexedDbTransactionError"}}function Yt(t){return"IndexedDbTransactionError"===t.name}class Wt{constructor(t){this.store=t}put(t,e){let n;return void 0!==e?(q(Kt,"PUT",this.store.name,t,e),n=this.store.put(e,t)):(q(Kt,"PUT",this.store.name,"<auto-key>",t),n=this.store.put(t)),Jt(n)}add(t){return q(Kt,"ADD",this.store.name,t,t),Jt(this.store.add(t))}get(t){return Jt(this.store.get(t)).next(e=>(void 0===e&&(e=null),q(Kt,"GET",this.store.name,t,e),e))}delete(t){return q(Kt,"DELETE",this.store.name,t),Jt(this.store.delete(t))}count(){return q(Kt,"COUNT",this.store.name),Jt(this.store.count())}J(t,e){const n=this.options(t,e),s=n.index?this.store.index(n.index):this.store;if("function"==typeof s.getAll){const t=s.getAll(n.range);return new zt((e,n)=>{t.onerror=t=>{n(t.target.error)},t.onsuccess=t=>{e(t.target.result)}})}{const t=this.cursor(n),e=[];return this.H(t,(t,n)=>{e.push(n)}).next(()=>e)}}Y(t,e){const n=this.store.getAll(t,null===e?void 0:e);return new zt((t,e)=>{n.onerror=t=>{e(t.target.error)},n.onsuccess=e=>{t(e.target.result)}})}Z(t,e){q(Kt,"DELETE ALL",this.store.name);const n=this.options(t,e);n.X=!1;const s=this.cursor(n);return this.H(s,(t,e,n)=>n.delete())}ee(t,e){let n;e?n=t:(n={},e=t);const s=this.cursor(n);return this.H(s,e)}te(t){const e=this.cursor({});return new zt((n,s)=>{e.onerror=t=>{const e=te(t.target.error);s(e)},e.onsuccess=e=>{const s=e.target.result;s?t(s.primaryKey,s.value).next(t=>{t?s.continue():n()}):n()}})}H(t,e){const n=[];return new zt((s,r)=>{t.onerror=t=>{r(t.target.error)},t.onsuccess=t=>{const r=t.target.result;if(!r)return void s();const i=new Ht(r),o=e(r.primaryKey,r.value,i);if(o instanceof zt){const t=o.catch(t=>(i.done(),zt.reject(t)));n.push(t)}i.isDone?s():null===i.G?r.continue():r.continue(i.G)}}).next(()=>zt.waitFor(n))}options(t,e){let n;return void 0!==t&&("string"==typeof t?n=t:e=t),{index:n,range:e}}cursor(t){let e="next";if(t.reverse&&(e="prev"),t.index){const n=this.store.index(t.index);return t.X?n.openKeyCursor(t.range,e):n.openCursor(t.range,e)}return this.store.openCursor(t.range,e)}}function Jt(t){return new zt((e,n)=>{t.onsuccess=t=>{const n=t.target.result;e(n)},t.onerror=t=>{const e=te(t.target.error);n(e)}})}let Zt=!1;function te(t){const e=$t.M(y());if(e>=12.2&&e<13){const e="An internal error was encountered in the Indexed Database server";if(t.message.indexOf(e)>=0){const t=new X("internal",`IOS_INDEXEDDB_BUG1: IndexedDb has thrown '${e}'. This is likely due to an unavoidable bug in iOS. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.`);return Zt||(Zt=!0,setTimeout(()=>{throw t},0)),t}}return t}const ee="IndexBackfiller";class ne{constructor(t,e){this.asyncQueue=t,this.ne=e,this.task=null}start(){this.re(15e3)}stop(){this.task&&(this.task.cancel(),this.task=null)}get started(){return null!==this.task}re(t){q(ee,`Scheduled in ${t}ms`),this.task=this.asyncQueue.enqueueAfterDelay("index_backfill",t,async()=>{this.task=null;try{const t=await this.ne.ie();q(ee,`Documents written: ${t}`)}catch(t){Yt(t)?q(ee,"Ignoring IndexedDB error during index backfill: ",t):await jt(t)}await this.re(6e4)})}}class se{constructor(t,e){this.localStore=t,this.persistence=e}async ie(t=50){return this.persistence.runTransaction("Backfill Indexes","readwrite-primary",e=>this.se(e,t))}se(t,e){const n=new Set;let s=e,r=!0;return zt.doWhile(()=>!0===r&&s>0,()=>this.localStore.indexManager.getNextCollectionGroupToUpdate(t).next(e=>{if(null!==e&&!n.has(e))return q(ee,`Processing collection: ${e}`),this.oe(t,e,s).next(t=>{s-=t,n.add(e)});r=!1})).next(()=>e-s)}oe(t,e,n){return this.localStore.indexManager.getMinOffsetFromCollectionGroup(t,e).next(s=>this.localStore.localDocuments.getNextDocuments(t,e,s,n).next(n=>{const r=n.changes;return this.localStore.indexManager.updateIndexEntries(t,r).next(()=>this._e(s,n)).next(n=>(q(ee,`Updating offset: ${n}`),this.localStore.indexManager.updateCollectionGroup(t,e,n))).next(()=>r.size)}))}_e(t,e){let n=t;return e.changes.forEach((t,e)=>{const s=Lt(e);Ut(s,n)>0&&(n=s)}),new Ft(n.readTime,n.documentKey,Math.max(e.batchId,t.largestBatchId))}}
/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class re{constructor(t,e){this.previousValue=t,e&&(e.sequenceNumberHandler=t=>this.ae(t),this.ue=t=>e.writeSequenceNumber(t))}ae(t){return this.previousValue=Math.max(t,this.previousValue),this.previousValue}next(){const t=++this.previousValue;return this.ue&&this.ue(t),t}}re.ce=-1;
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ie=-1;function oe(t){return null==t}function ae(t){return 0===t&&1/t==-1/0}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ue="";function ce(t){let e="";for(let n=0;n<t.length;n++)e.length>0&&(e=le(e)),e=he(t.get(n),e);return le(e)}function he(t,e){let n=e;const s=t.length;for(let r=0;r<s;r++){const e=t.charAt(r);switch(e){case"\0":n+="";break;case ue:n+="";break;default:n+=e}}return n}function le(t){return t+ue+""}function de(t){const e=t.length;if($(e>=2,64408,{path:t}),2===e)return $(t.charAt(0)===ue&&""===t.charAt(1),56145,{path:t}),pt.emptyPath();const n=e-2,s=[];let r="";for(let i=0;i<e;){const e=t.indexOf(ue,i);switch((e<0||e>n)&&K(50515,{path:t}),t.charAt(e+1)){case"":const n=t.substring(i,e);let o;0===r.length?o=n:(r+=n,o=r,r=""),s.push(o);break;case"":r+=t.substring(i,e),r+="\0";break;case"":r+=t.substring(i,e+1);break;default:K(61167,{path:t})}i=e+2}return new pt(s)}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fe="remoteDocuments",me="owner",ge="owner",pe="mutationQueues",ye="mutations",ve="batchId",we="userMutationsIndex",Ie=["userId","batchId"];
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function be(t,e){return[t,ce(e)]}function Te(t,e,n){return[t,ce(e),n]}const Ee={},Se="documentMutations",_e="remoteDocumentsV14",xe=["prefixPath","collectionGroup","readTime","documentId"],Ce="documentKeyIndex",Ae=["prefixPath","collectionGroup","documentId"],De="collectionGroupIndex",Ne=["collectionGroup","readTime","prefixPath","documentId"],ke="remoteDocumentGlobal",Re="remoteDocumentGlobalKey",Me="targets",Oe="queryTargetsIndex",Ve=["canonicalId","targetId"],Pe="targetDocuments",Le=["targetId","path"],Fe="documentTargetsIndex",Ue=["path","targetId"],qe="targetGlobalKey",Be="targetGlobal",je="collectionParents",ze=["collectionId","parent"],Ke="clientMetadata",Ge="bundles",$e="namedQueries",Qe="indexConfiguration",He="collectionGroupIndex",Xe="indexState",Ye=["indexId","uid"],We="sequenceNumberIndex",Je=["uid","sequenceNumber"],Ze="indexEntries",tn=["indexId","uid","arrayValue","directionalValue","orderedDocumentKey","documentKey"],en="documentKeyIndex",nn=["indexId","uid","orderedDocumentKey"],sn="documentOverlays",rn=["userId","collectionPath","documentId"],on="collectionPathOverlayIndex",an=["userId","collectionPath","largestBatchId"],un="collectionGroupOverlayIndex",cn=["userId","collectionGroup","largestBatchId"],hn="globals",ln=[pe,ye,Se,fe,Me,me,Be,Pe,Ke,ke,je,Ge,$e],dn=[...ln,sn],fn=[pe,ye,Se,_e,Me,me,Be,Pe,Ke,ke,je,Ge,$e,sn],mn=fn,gn=[...mn,Qe,Xe,Ze],pn=gn,yn=[...gn,hn],vn=yn;
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wn extends Bt{constructor(t,e){super(),this.le=t,this.currentSequenceNumber=e}}function In(t,e){const n=Q(t);return $t.O(n.le,e)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function bn(t){let e=0;for(const n in t)Object.prototype.hasOwnProperty.call(t,n)&&e++;return e}function Tn(t,e){for(const n in t)Object.prototype.hasOwnProperty.call(t,n)&&e(n,t[n])}function En(t){for(const e in t)if(Object.prototype.hasOwnProperty.call(t,e))return!1;return!0}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sn{constructor(t,e){this.comparator=t,this.root=e||xn.EMPTY}insert(t,e){return new Sn(this.comparator,this.root.insert(t,e,this.comparator).copy(null,null,xn.BLACK,null,null))}remove(t){return new Sn(this.comparator,this.root.remove(t,this.comparator).copy(null,null,xn.BLACK,null,null))}get(t){let e=this.root;for(;!e.isEmpty();){const n=this.comparator(t,e.key);if(0===n)return e.value;n<0?e=e.left:n>0&&(e=e.right)}return null}indexOf(t){let e=0,n=this.root;for(;!n.isEmpty();){const s=this.comparator(t,n.key);if(0===s)return e+n.left.size;s<0?n=n.left:(e+=n.left.size+1,n=n.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(t){return this.root.inorderTraversal(t)}forEach(t){this.inorderTraversal((e,n)=>(t(e,n),!1))}toString(){const t=[];return this.inorderTraversal((e,n)=>(t.push(`${e}:${n}`),!1)),`{${t.join(", ")}}`}reverseTraversal(t){return this.root.reverseTraversal(t)}getIterator(){return new _n(this.root,null,this.comparator,!1)}getIteratorFrom(t){return new _n(this.root,t,this.comparator,!1)}getReverseIterator(){return new _n(this.root,null,this.comparator,!0)}getReverseIteratorFrom(t){return new _n(this.root,t,this.comparator,!0)}}class _n{constructor(t,e,n,s){this.isReverse=s,this.nodeStack=[];let r=1;for(;!t.isEmpty();)if(r=e?n(t.key,e):1,e&&s&&(r*=-1),r<0)t=this.isReverse?t.left:t.right;else{if(0===r){this.nodeStack.push(t);break}this.nodeStack.push(t),t=this.isReverse?t.right:t.left}}getNext(){let t=this.nodeStack.pop();const e={key:t.key,value:t.value};if(this.isReverse)for(t=t.left;!t.isEmpty();)this.nodeStack.push(t),t=t.right;else for(t=t.right;!t.isEmpty();)this.nodeStack.push(t),t=t.left;return e}hasNext(){return this.nodeStack.length>0}peek(){if(0===this.nodeStack.length)return null;const t=this.nodeStack[this.nodeStack.length-1];return{key:t.key,value:t.value}}}class xn{constructor(t,e,n,s,r){this.key=t,this.value=e,this.color=null!=n?n:xn.RED,this.left=null!=s?s:xn.EMPTY,this.right=null!=r?r:xn.EMPTY,this.size=this.left.size+1+this.right.size}copy(t,e,n,s,r){return new xn(null!=t?t:this.key,null!=e?e:this.value,null!=n?n:this.color,null!=s?s:this.left,null!=r?r:this.right)}isEmpty(){return!1}inorderTraversal(t){return this.left.inorderTraversal(t)||t(this.key,this.value)||this.right.inorderTraversal(t)}reverseTraversal(t){return this.right.reverseTraversal(t)||t(this.key,this.value)||this.left.reverseTraversal(t)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(t,e,n){let s=this;const r=n(t,s.key);return s=r<0?s.copy(null,null,null,s.left.insert(t,e,n),null):0===r?s.copy(null,e,null,null,null):s.copy(null,null,null,null,s.right.insert(t,e,n)),s.fixUp()}removeMin(){if(this.left.isEmpty())return xn.EMPTY;let t=this;return t.left.isRed()||t.left.left.isRed()||(t=t.moveRedLeft()),t=t.copy(null,null,null,t.left.removeMin(),null),t.fixUp()}remove(t,e){let n,s=this;if(e(t,s.key)<0)s.left.isEmpty()||s.left.isRed()||s.left.left.isRed()||(s=s.moveRedLeft()),s=s.copy(null,null,null,s.left.remove(t,e),null);else{if(s.left.isRed()&&(s=s.rotateRight()),s.right.isEmpty()||s.right.isRed()||s.right.left.isRed()||(s=s.moveRedRight()),0===e(t,s.key)){if(s.right.isEmpty())return xn.EMPTY;n=s.right.min(),s=s.copy(n.key,n.value,null,null,s.right.removeMin())}s=s.copy(null,null,null,null,s.right.remove(t,e))}return s.fixUp()}isRed(){return this.color}fixUp(){let t=this;return t.right.isRed()&&!t.left.isRed()&&(t=t.rotateLeft()),t.left.isRed()&&t.left.left.isRed()&&(t=t.rotateRight()),t.left.isRed()&&t.right.isRed()&&(t=t.colorFlip()),t}moveRedLeft(){let t=this.colorFlip();return t.right.left.isRed()&&(t=t.copy(null,null,null,null,t.right.rotateRight()),t=t.rotateLeft(),t=t.colorFlip()),t}moveRedRight(){let t=this.colorFlip();return t.left.left.isRed()&&(t=t.rotateRight(),t=t.colorFlip()),t}rotateLeft(){const t=this.copy(null,null,xn.RED,null,this.right.left);return this.right.copy(null,null,this.color,t,null)}rotateRight(){const t=this.copy(null,null,xn.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,t)}colorFlip(){const t=this.left.copy(null,null,!this.left.color,null,null),e=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,t,e)}checkMaxDepth(){const t=this.check();return Math.pow(2,t)<=this.size+1}check(){if(this.isRed()&&this.left.isRed())throw K(43730,{key:this.key,value:this.value});if(this.right.isRed())throw K(14113,{key:this.key,value:this.value});const t=this.left.check();if(t!==this.right.check())throw K(27949);return t+(this.isRed()?0:1)}}xn.EMPTY=null,xn.RED=!0,xn.BLACK=!1,xn.EMPTY=new class{constructor(){this.size=0}get key(){throw K(57766)}get value(){throw K(16141)}get color(){throw K(16727)}get left(){throw K(29726)}get right(){throw K(36894)}copy(t,e,n,s,r){return this}insert(t,e,n){return new xn(t,e)}remove(t,e){return this}isEmpty(){return!0}inorderTraversal(t){return!1}reverseTraversal(t){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cn{constructor(t){this.comparator=t,this.data=new Sn(this.comparator)}has(t){return null!==this.data.get(t)}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(t){return this.data.indexOf(t)}forEach(t){this.data.inorderTraversal((e,n)=>(t(e),!1))}forEachInRange(t,e){const n=this.data.getIteratorFrom(t[0]);for(;n.hasNext();){const s=n.getNext();if(this.comparator(s.key,t[1])>=0)return;e(s.key)}}forEachWhile(t,e){let n;for(n=void 0!==e?this.data.getIteratorFrom(e):this.data.getIterator();n.hasNext();)if(!t(n.getNext().key))return}firstAfterOrEqual(t){const e=this.data.getIteratorFrom(t);return e.hasNext()?e.getNext().key:null}getIterator(){return new An(this.data.getIterator())}getIteratorFrom(t){return new An(this.data.getIteratorFrom(t))}add(t){return this.copy(this.data.remove(t).insert(t,!0))}delete(t){return this.has(t)?this.copy(this.data.remove(t)):this}isEmpty(){return this.data.isEmpty()}unionWith(t){let e=this;return e.size<t.size&&(e=t,t=this),t.forEach(t=>{e=e.add(t)}),e}isEqual(t){if(!(t instanceof Cn))return!1;if(this.size!==t.size)return!1;const e=this.data.getIterator(),n=t.data.getIterator();for(;e.hasNext();){const t=e.getNext().key,s=n.getNext().key;if(0!==this.comparator(t,s))return!1}return!0}toArray(){const t=[];return this.forEach(e=>{t.push(e)}),t}toString(){const t=[];return this.forEach(e=>t.push(e)),"SortedSet("+t.toString()+")"}copy(t){const e=new Cn(this.comparator);return e.data=t,e}}class An{constructor(t){this.iter=t}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}function Dn(t){return t.hasNext()?t.getNext():void 0}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nn{constructor(t){this.fields=t,t.sort(vt.comparator)}static empty(){return new Nn([])}unionWith(t){let e=new Cn(vt.comparator);for(const n of this.fields)e=e.add(n);for(const n of t)e=e.add(n);return new Nn(e.toArray())}covers(t){for(const e of this.fields)if(e.isPrefixOf(t))return!0;return!1}isEqual(t){return dt(this.fields,t.fields,(t,e)=>t.isEqual(e))}}
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kn extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rn{constructor(t){this.binaryString=t}static fromBase64String(t){const e=function(t){try{return atob(t)}catch(e){throw"undefined"!=typeof DOMException&&e instanceof DOMException?new kn("Invalid base64 string: "+e):e}}(t);return new Rn(e)}static fromUint8Array(t){const e=function(t){let e="";for(let n=0;n<t.length;++n)e+=String.fromCharCode(t[n]);return e}(t);return new Rn(e)}[Symbol.iterator](){let t=0;return{next:()=>t<this.binaryString.length?{value:this.binaryString.charCodeAt(t++),done:!1}:{value:void 0,done:!0}}}toBase64(){return t=this.binaryString,btoa(t);var t}toUint8Array(){return function(t){const e=new Uint8Array(t.length);for(let n=0;n<t.length;n++)e[n]=t.charCodeAt(n);return e}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(t){return at(this.binaryString,t.binaryString)}isEqual(t){return this.binaryString===t.binaryString}}Rn.EMPTY_BYTE_STRING=new Rn("");const Mn=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function On(t){if($(!!t,39018),"string"==typeof t){let e=0;const n=Mn.exec(t);if($(!!n,46558,{timestamp:t}),n[1]){let t=n[1];t=(t+"000000000").substr(0,9),e=Number(t)}const s=new Date(t);return{seconds:Math.floor(s.getTime()/1e3),nanos:e}}return{seconds:Vn(t.seconds),nanos:Vn(t.nanos)}}function Vn(t){return"number"==typeof t?t:"string"==typeof t?Number(t):0}function Pn(t){return"string"==typeof t?Rn.fromBase64String(t):Rn.fromUint8Array(t)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ln="server_timestamp",Fn="__type__",Un="__previous_value__",qn="__local_write_time__";function Bn(t){var e,n;return(null==(n=((null==(e=null==t?void 0:t.mapValue)?void 0:e.fields)||{})[Fn])?void 0:n.stringValue)===Ln}function jn(t){const e=t.mapValue.fields[Un];return Bn(e)?jn(e):e}function zn(t){const e=On(t.mapValue.fields[qn].timestampValue);return new Nt(e.seconds,e.nanos)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kn{constructor(t,e,n,s,r,i,o,a,u,c){this.databaseId=t,this.appId=e,this.persistenceKey=n,this.host=s,this.ssl=r,this.forceLongPolling=i,this.autoDetectLongPolling=o,this.longPollingOptions=a,this.useFetchStreams=u,this.isUsingEmulator=c}}const Gn="(default)";class $n{constructor(t,e){this.projectId=t,this.database=e||Gn}static empty(){return new $n("","")}get isDefaultDatabase(){return this.database===Gn}isEqual(t){return t instanceof $n&&t.projectId===this.projectId&&t.database===this.database}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Qn="__type__",Hn="__max__",Xn={mapValue:{fields:{__type__:{stringValue:Hn}}}},Yn="__vector__",Wn="value",Jn={nullValue:"NULL_VALUE"};function Zn(t){return"nullValue"in t?0:"booleanValue"in t?1:"integerValue"in t||"doubleValue"in t?2:"timestampValue"in t?3:"stringValue"in t?5:"bytesValue"in t?6:"referenceValue"in t?7:"geoPointValue"in t?8:"arrayValue"in t?9:"mapValue"in t?Bn(t)?4:ps(t)?9007199254740991:ms(t)?10:11:K(28295,{value:t})}function ts(t,e){if(t===e)return!0;const n=Zn(t);if(n!==Zn(e))return!1;switch(n){case 0:case 9007199254740991:return!0;case 1:return t.booleanValue===e.booleanValue;case 4:return zn(t).isEqual(zn(e));case 3:return function(t,e){if("string"==typeof t.timestampValue&&"string"==typeof e.timestampValue&&t.timestampValue.length===e.timestampValue.length)return t.timestampValue===e.timestampValue;const n=On(t.timestampValue),s=On(e.timestampValue);return n.seconds===s.seconds&&n.nanos===s.nanos}(t,e);case 5:return t.stringValue===e.stringValue;case 6:return s=e,Pn(t.bytesValue).isEqual(Pn(s.bytesValue));case 7:return t.referenceValue===e.referenceValue;case 8:return function(t,e){return Vn(t.geoPointValue.latitude)===Vn(e.geoPointValue.latitude)&&Vn(t.geoPointValue.longitude)===Vn(e.geoPointValue.longitude)}(t,e);case 2:return function(t,e){if("integerValue"in t&&"integerValue"in e)return Vn(t.integerValue)===Vn(e.integerValue);if("doubleValue"in t&&"doubleValue"in e){const n=Vn(t.doubleValue),s=Vn(e.doubleValue);return n===s?ae(n)===ae(s):isNaN(n)&&isNaN(s)}return!1}(t,e);case 9:return dt(t.arrayValue.values||[],e.arrayValue.values||[],ts);case 10:case 11:return function(t,e){const n=t.mapValue.fields||{},s=e.mapValue.fields||{};if(bn(n)!==bn(s))return!1;for(const r in n)if(n.hasOwnProperty(r)&&(void 0===s[r]||!ts(n[r],s[r])))return!1;return!0}(t,e);default:return K(52216,{left:t})}var s}function es(t,e){return void 0!==(t.values||[]).find(t=>ts(t,e))}function ns(t,e){if(t===e)return 0;const n=Zn(t),s=Zn(e);if(n!==s)return at(n,s);switch(n){case 0:case 9007199254740991:return 0;case 1:return at(t.booleanValue,e.booleanValue);case 2:return function(t,e){const n=Vn(t.integerValue||t.doubleValue),s=Vn(e.integerValue||e.doubleValue);return n<s?-1:n>s?1:n===s?0:isNaN(n)?isNaN(s)?0:-1:1}(t,e);case 3:return ss(t.timestampValue,e.timestampValue);case 4:return ss(zn(t),zn(e));case 5:return ut(t.stringValue,e.stringValue);case 6:return function(t,e){const n=Pn(t),s=Pn(e);return n.compareTo(s)}(t.bytesValue,e.bytesValue);case 7:return function(t,e){const n=t.split("/"),s=e.split("/");for(let r=0;r<n.length&&r<s.length;r++){const t=at(n[r],s[r]);if(0!==t)return t}return at(n.length,s.length)}(t.referenceValue,e.referenceValue);case 8:return function(t,e){const n=at(Vn(t.latitude),Vn(e.latitude));return 0!==n?n:at(Vn(t.longitude),Vn(e.longitude))}(t.geoPointValue,e.geoPointValue);case 9:return rs(t.arrayValue,e.arrayValue);case 10:return function(t,e){var n,s,r,i;const o=t.fields||{},a=e.fields||{},u=null==(n=o[Wn])?void 0:n.arrayValue,c=null==(s=a[Wn])?void 0:s.arrayValue,h=at((null==(r=null==u?void 0:u.values)?void 0:r.length)||0,(null==(i=null==c?void 0:c.values)?void 0:i.length)||0);return 0!==h?h:rs(u,c)}(t.mapValue,e.mapValue);case 11:return function(t,e){if(t===Xn.mapValue&&e===Xn.mapValue)return 0;if(t===Xn.mapValue)return 1;if(e===Xn.mapValue)return-1;const n=t.fields||{},s=Object.keys(n),r=e.fields||{},i=Object.keys(r);s.sort(),i.sort();for(let o=0;o<s.length&&o<i.length;++o){const t=ut(s[o],i[o]);if(0!==t)return t;const e=ns(n[s[o]],r[i[o]]);if(0!==e)return e}return at(s.length,i.length)}(t.mapValue,e.mapValue);default:throw K(23264,{he:n})}}function ss(t,e){if("string"==typeof t&&"string"==typeof e&&t.length===e.length)return at(t,e);const n=On(t),s=On(e),r=at(n.seconds,s.seconds);return 0!==r?r:at(n.nanos,s.nanos)}function rs(t,e){const n=t.values||[],s=e.values||[];for(let r=0;r<n.length&&r<s.length;++r){const t=ns(n[r],s[r]);if(t)return t}return at(n.length,s.length)}function is(t){return os(t)}function os(t){return"nullValue"in t?"null":"booleanValue"in t?""+t.booleanValue:"integerValue"in t?""+t.integerValue:"doubleValue"in t?""+t.doubleValue:"timestampValue"in t?function(t){const e=On(t);return`time(${e.seconds},${e.nanos})`}(t.timestampValue):"stringValue"in t?t.stringValue:"bytesValue"in t?Pn(t.bytesValue).toBase64():"referenceValue"in t?function(t){return wt.fromName(t).toString()}(t.referenceValue):"geoPointValue"in t?function(t){return`geo(${t.latitude},${t.longitude})`}(t.geoPointValue):"arrayValue"in t?function(t){let e="[",n=!0;for(const s of t.values||[])n?n=!1:e+=",",e+=os(s);return e+"]"}(t.arrayValue):"mapValue"in t?function(t){const e=Object.keys(t.fields||{}).sort();let n="{",s=!0;for(const r of e)s?s=!1:n+=",",n+=`${r}:${os(t.fields[r])}`;return n+"}"}(t.mapValue):K(61005,{value:t})}function as(t){switch(Zn(t)){case 0:case 1:return 4;case 2:return 8;case 3:case 8:return 16;case 4:const e=jn(t);return e?16+as(e):16;case 5:return 2*t.stringValue.length;case 6:return Pn(t.bytesValue).approximateByteSize();case 7:return t.referenceValue.length;case 9:return(t.arrayValue.values||[]).reduce((t,e)=>t+as(e),0);case 10:case 11:return function(t){let e=0;return Tn(t.fields,(t,n)=>{e+=t.length+as(n)}),e}(t.mapValue);default:throw K(13486,{value:t})}}function us(t,e){return{referenceValue:`projects/${t.projectId}/databases/${t.database}/documents/${e.path.canonicalString()}`}}function cs(t){return!!t&&"integerValue"in t}function hs(t){return!!t&&"arrayValue"in t}function ls(t){return!!t&&"nullValue"in t}function ds(t){return!!t&&"doubleValue"in t&&isNaN(Number(t.doubleValue))}function fs(t){return!!t&&"mapValue"in t}function ms(t){var e,n;return(null==(n=((null==(e=null==t?void 0:t.mapValue)?void 0:e.fields)||{})[Qn])?void 0:n.stringValue)===Yn}function gs(t){if(t.geoPointValue)return{geoPointValue:{...t.geoPointValue}};if(t.timestampValue&&"object"==typeof t.timestampValue)return{timestampValue:{...t.timestampValue}};if(t.mapValue){const e={mapValue:{fields:{}}};return Tn(t.mapValue.fields,(t,n)=>e.mapValue.fields[t]=gs(n)),e}if(t.arrayValue){const e={arrayValue:{values:[]}};for(let n=0;n<(t.arrayValue.values||[]).length;++n)e.arrayValue.values[n]=gs(t.arrayValue.values[n]);return e}return{...t}}function ps(t){return(((t.mapValue||{}).fields||{}).__type__||{}).stringValue===Hn}const ys={mapValue:{fields:{[Qn]:{stringValue:Yn},[Wn]:{arrayValue:{}}}}};function vs(t){return"nullValue"in t?Jn:"booleanValue"in t?{booleanValue:!1}:"integerValue"in t||"doubleValue"in t?{doubleValue:NaN}:"timestampValue"in t?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"stringValue"in t?{stringValue:""}:"bytesValue"in t?{bytesValue:""}:"referenceValue"in t?us($n.empty(),wt.empty()):"geoPointValue"in t?{geoPointValue:{latitude:-90,longitude:-180}}:"arrayValue"in t?{arrayValue:{}}:"mapValue"in t?ms(t)?ys:{mapValue:{}}:K(35942,{value:t})}function ws(t){return"nullValue"in t?{booleanValue:!1}:"booleanValue"in t?{doubleValue:NaN}:"integerValue"in t||"doubleValue"in t?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"timestampValue"in t?{stringValue:""}:"stringValue"in t?{bytesValue:""}:"bytesValue"in t?us($n.empty(),wt.empty()):"referenceValue"in t?{geoPointValue:{latitude:-90,longitude:-180}}:"geoPointValue"in t?{arrayValue:{}}:"arrayValue"in t?ys:"mapValue"in t?ms(t)?{mapValue:{}}:Xn:K(61959,{value:t})}function Is(t,e){const n=ns(t.value,e.value);return 0!==n?n:t.inclusive&&!e.inclusive?-1:!t.inclusive&&e.inclusive?1:0}function bs(t,e){const n=ns(t.value,e.value);return 0!==n?n:t.inclusive&&!e.inclusive?1:!t.inclusive&&e.inclusive?-1:0}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ts{constructor(t){this.value=t}static empty(){return new Ts({mapValue:{}})}field(t){if(t.isEmpty())return this.value;{let e=this.value;for(let n=0;n<t.length-1;++n)if(e=(e.mapValue.fields||{})[t.get(n)],!fs(e))return null;return e=(e.mapValue.fields||{})[t.lastSegment()],e||null}}set(t,e){this.getFieldsMap(t.popLast())[t.lastSegment()]=gs(e)}setAll(t){let e=vt.emptyPath(),n={},s=[];t.forEach((t,r)=>{if(!e.isImmediateParentOf(r)){const t=this.getFieldsMap(e);this.applyChanges(t,n,s),n={},s=[],e=r.popLast()}t?n[r.lastSegment()]=gs(t):s.push(r.lastSegment())});const r=this.getFieldsMap(e);this.applyChanges(r,n,s)}delete(t){const e=this.field(t.popLast());fs(e)&&e.mapValue.fields&&delete e.mapValue.fields[t.lastSegment()]}isEqual(t){return ts(this.value,t.value)}getFieldsMap(t){let e=this.value;e.mapValue.fields||(e.mapValue={fields:{}});for(let n=0;n<t.length;++n){let s=e.mapValue.fields[t.get(n)];fs(s)&&s.mapValue.fields||(s={mapValue:{fields:{}}},e.mapValue.fields[t.get(n)]=s),e=s}return e.mapValue.fields}applyChanges(t,e,n){Tn(e,(e,n)=>t[e]=n);for(const s of n)delete t[s]}clone(){return new Ts(gs(this.value))}}function Es(t){const e=[];return Tn(t.fields,(t,n)=>{const s=new vt([t]);if(fs(n)){const t=Es(n.mapValue).fields;if(0===t.length)e.push(s);else for(const n of t)e.push(s.child(n))}else e.push(s)}),new Nn(e)
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */}class Ss{constructor(t,e,n,s,r,i,o){this.key=t,this.documentType=e,this.version=n,this.readTime=s,this.createTime=r,this.data=i,this.documentState=o}static newInvalidDocument(t){return new Ss(t,0,kt.min(),kt.min(),kt.min(),Ts.empty(),0)}static newFoundDocument(t,e,n,s){return new Ss(t,1,e,kt.min(),n,s,0)}static newNoDocument(t,e){return new Ss(t,2,e,kt.min(),kt.min(),Ts.empty(),0)}static newUnknownDocument(t,e){return new Ss(t,3,e,kt.min(),kt.min(),Ts.empty(),2)}convertToFoundDocument(t,e){return!this.createTime.isEqual(kt.min())||2!==this.documentType&&0!==this.documentType||(this.createTime=t),this.version=t,this.documentType=1,this.data=e,this.documentState=0,this}convertToNoDocument(t){return this.version=t,this.documentType=2,this.data=Ts.empty(),this.documentState=0,this}convertToUnknownDocument(t){return this.version=t,this.documentType=3,this.data=Ts.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=kt.min(),this}setReadTime(t){return this.readTime=t,this}get hasLocalMutations(){return 1===this.documentState}get hasCommittedMutations(){return 2===this.documentState}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return 0!==this.documentType}isFoundDocument(){return 1===this.documentType}isNoDocument(){return 2===this.documentType}isUnknownDocument(){return 3===this.documentType}isEqual(t){return t instanceof Ss&&this.key.isEqual(t.key)&&this.version.isEqual(t.version)&&this.documentType===t.documentType&&this.documentState===t.documentState&&this.data.isEqual(t.data)}mutableCopy(){return new Ss(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _s{constructor(t,e){this.position=t,this.inclusive=e}}function xs(t,e,n){let s=0;for(let r=0;r<t.position.length;r++){const i=e[r],o=t.position[r];if(s=i.field.isKeyField()?wt.comparator(wt.fromName(o.referenceValue),n.key):ns(o,n.data.field(i.field)),"desc"===i.dir&&(s*=-1),0!==s)break}return s}function Cs(t,e){if(null===t)return null===e;if(null===e)return!1;if(t.inclusive!==e.inclusive||t.position.length!==e.position.length)return!1;for(let n=0;n<t.position.length;n++)if(!ts(t.position[n],e.position[n]))return!1;return!0}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class As{constructor(t,e="asc"){this.field=t,this.dir=e}}function Ds(t,e){return t.dir===e.dir&&t.field.isEqual(e.field)}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ns{}class ks extends Ns{constructor(t,e,n){super(),this.field=t,this.op=e,this.value=n}static create(t,e,n){return t.isKeyField()?"in"===e||"not-in"===e?this.createKeyFieldInFilter(t,e,n):new Bs(t,e,n):"array-contains"===e?new Gs(t,n):"in"===e?new $s(t,n):"not-in"===e?new Qs(t,n):"array-contains-any"===e?new Hs(t,n):new ks(t,e,n)}static createKeyFieldInFilter(t,e,n){return"in"===e?new js(t,n):new zs(t,n)}matches(t){const e=t.data.field(this.field);return"!="===this.op?null!==e&&void 0===e.nullValue&&this.matchesComparison(ns(e,this.value)):null!==e&&Zn(this.value)===Zn(e)&&this.matchesComparison(ns(e,this.value))}matchesComparison(t){switch(this.op){case"<":return t<0;case"<=":return t<=0;case"==":return 0===t;case"!=":return 0!==t;case">":return t>0;case">=":return t>=0;default:return K(47266,{operator:this.op})}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class Rs extends Ns{constructor(t,e){super(),this.filters=t,this.op=e,this.Pe=null}static create(t,e){return new Rs(t,e)}matches(t){return Ms(this)?void 0===this.filters.find(e=>!e.matches(t)):void 0!==this.filters.find(e=>e.matches(t))}getFlattenedFilters(){return null!==this.Pe||(this.Pe=this.filters.reduce((t,e)=>t.concat(e.getFlattenedFilters()),[])),this.Pe}getFilters(){return Object.assign([],this.filters)}}function Ms(t){return"and"===t.op}function Os(t){return"or"===t.op}function Vs(t){return Ps(t)&&Ms(t)}function Ps(t){for(const e of t.filters)if(e instanceof Rs)return!1;return!0}function Ls(t){if(t instanceof ks)return t.field.canonicalString()+t.op.toString()+is(t.value);if(Vs(t))return t.filters.map(t=>Ls(t)).join(",");{const e=t.filters.map(t=>Ls(t)).join(",");return`${t.op}(${e})`}}function Fs(t,e){return t instanceof ks?(n=t,(s=e)instanceof ks&&n.op===s.op&&n.field.isEqual(s.field)&&ts(n.value,s.value)):t instanceof Rs?function(t,e){return e instanceof Rs&&t.op===e.op&&t.filters.length===e.filters.length&&t.filters.reduce((t,n,s)=>t&&Fs(n,e.filters[s]),!0)}(t,e):void K(19439);var n,s}function Us(t,e){const n=t.filters.concat(e);return Rs.create(n,t.op)}function qs(t){return t instanceof ks?`${(e=t).field.canonicalString()} ${e.op} ${is(e.value)}`:t instanceof Rs?function(t){return t.op.toString()+" {"+t.getFilters().map(qs).join(" ,")+"}"}(t):"Filter";var e}class Bs extends ks{constructor(t,e,n){super(t,e,n),this.key=wt.fromName(n.referenceValue)}matches(t){const e=wt.comparator(t.key,this.key);return this.matchesComparison(e)}}class js extends ks{constructor(t,e){super(t,"in",e),this.keys=Ks("in",e)}matches(t){return this.keys.some(e=>e.isEqual(t.key))}}class zs extends ks{constructor(t,e){super(t,"not-in",e),this.keys=Ks("not-in",e)}matches(t){return!this.keys.some(e=>e.isEqual(t.key))}}function Ks(t,e){var n;return((null==(n=e.arrayValue)?void 0:n.values)||[]).map(t=>wt.fromName(t.referenceValue))}class Gs extends ks{constructor(t,e){super(t,"array-contains",e)}matches(t){const e=t.data.field(this.field);return hs(e)&&es(e.arrayValue,this.value)}}class $s extends ks{constructor(t,e){super(t,"in",e)}matches(t){const e=t.data.field(this.field);return null!==e&&es(this.value.arrayValue,e)}}class Qs extends ks{constructor(t,e){super(t,"not-in",e)}matches(t){if(es(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const e=t.data.field(this.field);return null!==e&&void 0===e.nullValue&&!es(this.value.arrayValue,e)}}class Hs extends ks{constructor(t,e){super(t,"array-contains-any",e)}matches(t){const e=t.data.field(this.field);return!(!hs(e)||!e.arrayValue.values)&&e.arrayValue.values.some(t=>es(this.value.arrayValue,t))}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xs{constructor(t,e=null,n=[],s=[],r=null,i=null,o=null){this.path=t,this.collectionGroup=e,this.orderBy=n,this.filters=s,this.limit=r,this.startAt=i,this.endAt=o,this.Te=null}}function Ys(t,e=null,n=[],s=[],r=null,i=null,o=null){return new Xs(t,e,n,s,r,i,o)}function Ws(t){const e=Q(t);if(null===e.Te){let t=e.path.canonicalString();null!==e.collectionGroup&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map(t=>Ls(t)).join(","),t+="|ob:",t+=e.orderBy.map(t=>{return(e=t).field.canonicalString()+e.dir;var e}).join(","),oe(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map(t=>is(t)).join(",")),e.endAt&&(t+="|ub:",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map(t=>is(t)).join(",")),e.Te=t}return e.Te}function Js(t,e){if(t.limit!==e.limit)return!1;if(t.orderBy.length!==e.orderBy.length)return!1;for(let n=0;n<t.orderBy.length;n++)if(!Ds(t.orderBy[n],e.orderBy[n]))return!1;if(t.filters.length!==e.filters.length)return!1;for(let n=0;n<t.filters.length;n++)if(!Fs(t.filters[n],e.filters[n]))return!1;return t.collectionGroup===e.collectionGroup&&!!t.path.isEqual(e.path)&&!!Cs(t.startAt,e.startAt)&&Cs(t.endAt,e.endAt)}function Zs(t){return wt.isDocumentKey(t.path)&&null===t.collectionGroup&&0===t.filters.length}function tr(t,e){return t.filters.filter(t=>t instanceof ks&&t.field.isEqual(e))}function er(t,e,n){let s=Jn,r=!0;for(const i of tr(t,e)){let t=Jn,e=!0;switch(i.op){case"<":case"<=":t=vs(i.value);break;case"==":case"in":case">=":t=i.value;break;case">":t=i.value,e=!1;break;case"!=":case"not-in":t=Jn}Is({value:s,inclusive:r},{value:t,inclusive:e})<0&&(s=t,r=e)}if(null!==n)for(let i=0;i<t.orderBy.length;++i)if(t.orderBy[i].field.isEqual(e)){const t=n.position[i];Is({value:s,inclusive:r},{value:t,inclusive:n.inclusive})<0&&(s=t,r=n.inclusive);break}return{value:s,inclusive:r}}function nr(t,e,n){let s=Xn,r=!0;for(const i of tr(t,e)){let t=Xn,e=!0;switch(i.op){case">=":case">":t=ws(i.value),e=!1;break;case"==":case"in":case"<=":t=i.value;break;case"<":t=i.value,e=!1;break;case"!=":case"not-in":t=Xn}bs({value:s,inclusive:r},{value:t,inclusive:e})>0&&(s=t,r=e)}if(null!==n)for(let i=0;i<t.orderBy.length;++i)if(t.orderBy[i].field.isEqual(e)){const t=n.position[i];bs({value:s,inclusive:r},{value:t,inclusive:n.inclusive})>0&&(s=t,r=n.inclusive);break}return{value:s,inclusive:r}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sr{constructor(t,e=null,n=[],s=[],r=null,i="F",o=null,a=null){this.path=t,this.collectionGroup=e,this.explicitOrderBy=n,this.filters=s,this.limit=r,this.limitType=i,this.startAt=o,this.endAt=a,this.Ie=null,this.Ee=null,this.de=null,this.startAt,this.endAt}}function rr(t){return new sr(t)}function ir(t){return 0===t.filters.length&&null===t.limit&&null==t.startAt&&null==t.endAt&&(0===t.explicitOrderBy.length||1===t.explicitOrderBy.length&&t.explicitOrderBy[0].field.isKeyField())}function or(t){return null!==t.collectionGroup}function ar(t){const e=Q(t);if(null===e.Ie){e.Ie=[];const t=new Set;for(const s of e.explicitOrderBy)e.Ie.push(s),t.add(s.field.canonicalString());const n=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(t){let e=new Cn(vt.comparator);return t.filters.forEach(t=>{t.getFlattenedFilters().forEach(t=>{t.isInequality()&&(e=e.add(t.field))})}),e})(e).forEach(s=>{t.has(s.canonicalString())||s.isKeyField()||e.Ie.push(new As(s,n))}),t.has(vt.keyField().canonicalString())||e.Ie.push(new As(vt.keyField(),n))}return e.Ie}function ur(t){const e=Q(t);return e.Ee||(e.Ee=function(t,e){if("F"===t.limitType)return Ys(t.path,t.collectionGroup,e,t.filters,t.limit,t.startAt,t.endAt);{e=e.map(t=>{const e="desc"===t.dir?"asc":"desc";return new As(t.field,e)});const n=t.endAt?new _s(t.endAt.position,t.endAt.inclusive):null,s=t.startAt?new _s(t.startAt.position,t.startAt.inclusive):null;return Ys(t.path,t.collectionGroup,e,t.filters,t.limit,n,s)}}(e,ar(t))),e.Ee}function cr(t,e){const n=t.filters.concat([e]);return new sr(t.path,t.collectionGroup,t.explicitOrderBy.slice(),n,t.limit,t.limitType,t.startAt,t.endAt)}function hr(t,e,n){return new sr(t.path,t.collectionGroup,t.explicitOrderBy.slice(),t.filters.slice(),e,n,t.startAt,t.endAt)}function lr(t,e){return Js(ur(t),ur(e))&&t.limitType===e.limitType}function dr(t){return`${Ws(ur(t))}|lt:${t.limitType}`}function fr(t){return`Query(target=${function(t){let e=t.path.canonicalString();return null!==t.collectionGroup&&(e+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(e+=`, filters: [${t.filters.map(t=>qs(t)).join(", ")}]`),oe(t.limit)||(e+=", limit: "+t.limit),t.orderBy.length>0&&(e+=`, orderBy: [${t.orderBy.map(t=>{return`${(e=t).field.canonicalString()} (${e.dir})`;var e}).join(", ")}]`),t.startAt&&(e+=", startAt: ",e+=t.startAt.inclusive?"b:":"a:",e+=t.startAt.position.map(t=>is(t)).join(",")),t.endAt&&(e+=", endAt: ",e+=t.endAt.inclusive?"a:":"b:",e+=t.endAt.position.map(t=>is(t)).join(",")),`Target(${e})`}(ur(t))}; limitType=${t.limitType})`}function mr(t,e){return e.isFoundDocument()&&function(t,e){const n=e.key.path;return null!==t.collectionGroup?e.key.hasCollectionId(t.collectionGroup)&&t.path.isPrefixOf(n):wt.isDocumentKey(t.path)?t.path.isEqual(n):t.path.isImmediateParentOf(n)}(t,e)&&function(t,e){for(const n of ar(t))if(!n.field.isKeyField()&&null===e.data.field(n.field))return!1;return!0}(t,e)&&function(t,e){for(const n of t.filters)if(!n.matches(e))return!1;return!0}(t,e)&&(s=e,!((n=t).startAt&&!function(t,e,n){const s=xs(t,e,n);return t.inclusive?s<=0:s<0}(n.startAt,ar(n),s)||n.endAt&&!function(t,e,n){const s=xs(t,e,n);return t.inclusive?s>=0:s>0}(n.endAt,ar(n),s)));var n,s}function gr(t){return(e,n)=>{let s=!1;for(const r of ar(t)){const t=pr(r,e,n);if(0!==t)return t;s=s||r.field.isKeyField()}return 0}}function pr(t,e,n){const s=t.field.isKeyField()?wt.comparator(e.key,n.key):function(t,e,n){const s=e.data.field(t),r=n.data.field(t);return null!==s&&null!==r?ns(s,r):K(42886)}(t.field,e,n);switch(t.dir){case"asc":return s;case"desc":return-1*s;default:return K(19790,{direction:t.dir})}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yr{constructor(t,e){this.mapKeyFn=t,this.equalsFn=e,this.inner={},this.innerSize=0}get(t){const e=this.mapKeyFn(t),n=this.inner[e];if(void 0!==n)for(const[s,r]of n)if(this.equalsFn(s,t))return r}has(t){return void 0!==this.get(t)}set(t,e){const n=this.mapKeyFn(t),s=this.inner[n];if(void 0===s)return this.inner[n]=[[t,e]],void this.innerSize++;for(let r=0;r<s.length;r++)if(this.equalsFn(s[r][0],t))return void(s[r]=[t,e]);s.push([t,e]),this.innerSize++}delete(t){const e=this.mapKeyFn(t),n=this.inner[e];if(void 0===n)return!1;for(let s=0;s<n.length;s++)if(this.equalsFn(n[s][0],t))return 1===n.length?delete this.inner[e]:n.splice(s,1),this.innerSize--,!0;return!1}forEach(t){Tn(this.inner,(e,n)=>{for(const[s,r]of n)t(s,r)})}isEmpty(){return En(this.inner)}size(){return this.innerSize}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vr=new Sn(wt.comparator);function wr(){return vr}const Ir=new Sn(wt.comparator);function br(...t){let e=Ir;for(const n of t)e=e.insert(n.key,n);return e}function Tr(t){let e=Ir;return t.forEach((t,n)=>e=e.insert(t,n.overlayedDocument)),e}function Er(){return _r()}function Sr(){return _r()}function _r(){return new yr(t=>t.toString(),(t,e)=>t.isEqual(e))}const xr=new Sn(wt.comparator),Cr=new Cn(wt.comparator);function Ar(...t){let e=Cr;for(const n of t)e=e.add(n);return e}const Dr=new Cn(at);
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nr(t,e){if(t.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:ae(e)?"-0":e}}function kr(t){return{integerValue:""+t}}function Rr(t,e){return function(t){return"number"==typeof t&&Number.isInteger(t)&&!ae(t)&&t<=Number.MAX_SAFE_INTEGER&&t>=Number.MIN_SAFE_INTEGER}(e)?kr(e):Nr(t,e)}
/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mr{constructor(){this._=void 0}}function Or(t,e,n){return t instanceof Lr?function(t,e){const n={fields:{[Fn]:{stringValue:Ln},[qn]:{timestampValue:{seconds:t.seconds,nanos:t.nanoseconds}}}};return e&&Bn(e)&&(e=jn(e)),e&&(n.fields[Un]=e),{mapValue:n}}(n,e):t instanceof Fr?Ur(t,e):t instanceof qr?Br(t,e):function(t,e){const n=Pr(t,e),s=zr(n)+zr(t.Ae);return cs(n)&&cs(t.Ae)?kr(s):Nr(t.serializer,s)}(t,e)}function Vr(t,e,n){return t instanceof Fr?Ur(t,e):t instanceof qr?Br(t,e):n}function Pr(t,e){return t instanceof jr?cs(n=e)||(s=n)&&"doubleValue"in s?e:{integerValue:0}:null;var n,s}class Lr extends Mr{}class Fr extends Mr{constructor(t){super(),this.elements=t}}function Ur(t,e){const n=Kr(e);for(const s of t.elements)n.some(t=>ts(t,s))||n.push(s);return{arrayValue:{values:n}}}class qr extends Mr{constructor(t){super(),this.elements=t}}function Br(t,e){let n=Kr(e);for(const s of t.elements)n=n.filter(t=>!ts(t,s));return{arrayValue:{values:n}}}class jr extends Mr{constructor(t,e){super(),this.serializer=t,this.Ae=e}}function zr(t){return Vn(t.integerValue||t.doubleValue)}function Kr(t){return hs(t)&&t.arrayValue.values?t.arrayValue.values.slice():[]}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gr{constructor(t,e){this.field=t,this.transform=e}}class $r{constructor(t,e){this.version=t,this.transformResults=e}}class Qr{constructor(t,e){this.updateTime=t,this.exists=e}static none(){return new Qr}static exists(t){return new Qr(void 0,t)}static updateTime(t){return new Qr(t)}get isNone(){return void 0===this.updateTime&&void 0===this.exists}isEqual(t){return this.exists===t.exists&&(this.updateTime?!!t.updateTime&&this.updateTime.isEqual(t.updateTime):!t.updateTime)}}function Hr(t,e){return void 0!==t.updateTime?e.isFoundDocument()&&e.version.isEqual(t.updateTime):void 0===t.exists||t.exists===e.isFoundDocument()}class Xr{}function Yr(t,e){if(!t.hasLocalMutations||e&&0===e.fields.length)return null;if(null===e)return t.isNoDocument()?new oi(t.key,Qr.none()):new ei(t.key,t.data,Qr.none());{const n=t.data,s=Ts.empty();let r=new Cn(vt.comparator);for(let t of e.fields)if(!r.has(t)){let e=n.field(t);null===e&&t.length>1&&(t=t.popLast(),e=n.field(t)),null===e?s.delete(t):s.set(t,e),r=r.add(t)}return new ni(t.key,s,new Nn(r.toArray()),Qr.none())}}function Wr(t,e,n){var s;t instanceof ei?function(t,e,n){const s=t.value.clone(),r=ri(t.fieldTransforms,e,n.transformResults);s.setAll(r),e.convertToFoundDocument(n.version,s).setHasCommittedMutations()}(t,e,n):t instanceof ni?function(t,e,n){if(!Hr(t.precondition,e))return void e.convertToUnknownDocument(n.version);const s=ri(t.fieldTransforms,e,n.transformResults),r=e.data;r.setAll(si(t)),r.setAll(s),e.convertToFoundDocument(n.version,r).setHasCommittedMutations()}(t,e,n):(s=n,e.convertToNoDocument(s.version).setHasCommittedMutations())}function Jr(t,e,n,s){return t instanceof ei?function(t,e,n,s){if(!Hr(t.precondition,e))return n;const r=t.value.clone(),i=ii(t.fieldTransforms,s,e);return r.setAll(i),e.convertToFoundDocument(e.version,r).setHasLocalMutations(),null}(t,e,n,s):t instanceof ni?function(t,e,n,s){if(!Hr(t.precondition,e))return n;const r=ii(t.fieldTransforms,s,e),i=e.data;return i.setAll(si(t)),i.setAll(r),e.convertToFoundDocument(e.version,i).setHasLocalMutations(),null===n?null:n.unionWith(t.fieldMask.fields).unionWith(t.fieldTransforms.map(t=>t.field))}(t,e,n,s):(r=e,i=n,Hr(t.precondition,r)?(r.convertToNoDocument(r.version).setHasLocalMutations(),null):i);var r,i}function Zr(t,e){let n=null;for(const s of t.fieldTransforms){const t=e.data.field(s.field),r=Pr(s.transform,t||null);null!=r&&(null===n&&(n=Ts.empty()),n.set(s.field,r))}return n||null}function ti(t,e){return t.type===e.type&&!!t.key.isEqual(e.key)&&!!t.precondition.isEqual(e.precondition)&&(n=t.fieldTransforms,s=e.fieldTransforms,!!(void 0===n&&void 0===s||n&&s&&dt(n,s,(t,e)=>function(t,e){return t.field.isEqual(e.field)&&(n=t.transform,s=e.transform,n instanceof Fr&&s instanceof Fr||n instanceof qr&&s instanceof qr?dt(n.elements,s.elements,ts):n instanceof jr&&s instanceof jr?ts(n.Ae,s.Ae):n instanceof Lr&&s instanceof Lr);var n,s}(t,e)))&&(0===t.type?t.value.isEqual(e.value):1!==t.type||t.data.isEqual(e.data)&&t.fieldMask.isEqual(e.fieldMask)));var n,s}class ei extends Xr{constructor(t,e,n,s=[]){super(),this.key=t,this.value=e,this.precondition=n,this.fieldTransforms=s,this.type=0}getFieldMask(){return null}}class ni extends Xr{constructor(t,e,n,s,r=[]){super(),this.key=t,this.data=e,this.fieldMask=n,this.precondition=s,this.fieldTransforms=r,this.type=1}getFieldMask(){return this.fieldMask}}function si(t){const e=new Map;return t.fieldMask.fields.forEach(n=>{if(!n.isEmpty()){const s=t.data.field(n);e.set(n,s)}}),e}function ri(t,e,n){const s=new Map;$(t.length===n.length,32656,{Re:n.length,Ve:t.length});for(let r=0;r<n.length;r++){const i=t[r],o=i.transform,a=e.data.field(i.field);s.set(i.field,Vr(o,a,n[r]))}return s}function ii(t,e,n){const s=new Map;for(const r of t){const t=r.transform,i=n.data.field(r.field);s.set(r.field,Or(t,i,e))}return s}class oi extends Xr{constructor(t,e){super(),this.key=t,this.precondition=e,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class ai extends Xr{constructor(t,e){super(),this.key=t,this.precondition=e,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ui{constructor(t,e,n,s){this.batchId=t,this.localWriteTime=e,this.baseMutations=n,this.mutations=s}applyToRemoteDocument(t,e){const n=e.mutationResults;for(let s=0;s<this.mutations.length;s++){const e=this.mutations[s];e.key.isEqual(t.key)&&Wr(e,t,n[s])}}applyToLocalView(t,e){for(const n of this.baseMutations)n.key.isEqual(t.key)&&(e=Jr(n,t,e,this.localWriteTime));for(const n of this.mutations)n.key.isEqual(t.key)&&(e=Jr(n,t,e,this.localWriteTime));return e}applyToLocalDocumentSet(t,e){const n=Sr();return this.mutations.forEach(s=>{const r=t.get(s.key),i=r.overlayedDocument;let o=this.applyToLocalView(i,r.mutatedFields);o=e.has(s.key)?null:o;const a=Yr(i,o);null!==a&&n.set(s.key,a),i.isValidDocument()||i.convertToNoDocument(kt.min())}),n}keys(){return this.mutations.reduce((t,e)=>t.add(e.key),Ar())}isEqual(t){return this.batchId===t.batchId&&dt(this.mutations,t.mutations,(t,e)=>ti(t,e))&&dt(this.baseMutations,t.baseMutations,(t,e)=>ti(t,e))}}class ci{constructor(t,e,n,s){this.batch=t,this.commitVersion=e,this.mutationResults=n,this.docVersions=s}static from(t,e,n){$(t.mutations.length===n.length,58842,{me:t.mutations.length,fe:n.length});let s=function(){return xr}();const r=t.mutations;for(let i=0;i<r.length;i++)s=s.insert(r[i].key,n[i].version);return new ci(t,e,n,s)}}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hi{constructor(t,e){this.largestBatchId=t,this.mutation=e}getKey(){return this.mutation.key}isEqual(t){return null!==t&&this.mutation===t.mutation}toString(){return`Overlay{\n      largestBatchId: ${this.largestBatchId},\n      mutation: ${this.mutation.toString()}\n    }`}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class li{constructor(t,e){this.count=t,this.unchangedNames=e}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var di,fi;function mi(t){if(void 0===t)return B("GRPC error has no .code"),H.UNKNOWN;switch(t){case di.OK:return H.OK;case di.CANCELLED:return H.CANCELLED;case di.UNKNOWN:return H.UNKNOWN;case di.DEADLINE_EXCEEDED:return H.DEADLINE_EXCEEDED;case di.RESOURCE_EXHAUSTED:return H.RESOURCE_EXHAUSTED;case di.INTERNAL:return H.INTERNAL;case di.UNAVAILABLE:return H.UNAVAILABLE;case di.UNAUTHENTICATED:return H.UNAUTHENTICATED;case di.INVALID_ARGUMENT:return H.INVALID_ARGUMENT;case di.NOT_FOUND:return H.NOT_FOUND;case di.ALREADY_EXISTS:return H.ALREADY_EXISTS;case di.PERMISSION_DENIED:return H.PERMISSION_DENIED;case di.FAILED_PRECONDITION:return H.FAILED_PRECONDITION;case di.ABORTED:return H.ABORTED;case di.OUT_OF_RANGE:return H.OUT_OF_RANGE;case di.UNIMPLEMENTED:return H.UNIMPLEMENTED;case di.DATA_LOSS:return H.DATA_LOSS;default:return K(39323,{code:t})}}(fi=di||(di={}))[fi.OK=0]="OK",fi[fi.CANCELLED=1]="CANCELLED",fi[fi.UNKNOWN=2]="UNKNOWN",fi[fi.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",fi[fi.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",fi[fi.NOT_FOUND=5]="NOT_FOUND",fi[fi.ALREADY_EXISTS=6]="ALREADY_EXISTS",fi[fi.PERMISSION_DENIED=7]="PERMISSION_DENIED",fi[fi.UNAUTHENTICATED=16]="UNAUTHENTICATED",fi[fi.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",fi[fi.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",fi[fi.ABORTED=10]="ABORTED",fi[fi.OUT_OF_RANGE=11]="OUT_OF_RANGE",fi[fi.UNIMPLEMENTED=12]="UNIMPLEMENTED",fi[fi.INTERNAL=13]="INTERNAL",fi[fi.UNAVAILABLE=14]="UNAVAILABLE",fi[fi.DATA_LOSS=15]="DATA_LOSS";
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gi=new T([4294967295,4294967295],0);function pi(t){const e=(new TextEncoder).encode(t),n=new E;return n.update(e),new Uint8Array(n.digest())}function yi(t){const e=new DataView(t.buffer),n=e.getUint32(0,!0),s=e.getUint32(4,!0),r=e.getUint32(8,!0),i=e.getUint32(12,!0);return[new T([n,s],0),new T([r,i],0)]}class vi{constructor(t,e,n){if(this.bitmap=t,this.padding=e,this.hashCount=n,e<0||e>=8)throw new wi(`Invalid padding: ${e}`);if(n<0)throw new wi(`Invalid hash count: ${n}`);if(t.length>0&&0===this.hashCount)throw new wi(`Invalid hash count: ${n}`);if(0===t.length&&0!==e)throw new wi(`Invalid padding when bitmap length is 0: ${e}`);this.ge=8*t.length-e,this.pe=T.fromNumber(this.ge)}ye(t,e,n){let s=t.add(e.multiply(T.fromNumber(n)));return 1===s.compare(gi)&&(s=new T([s.getBits(0),s.getBits(1)],0)),s.modulo(this.pe).toNumber()}we(t){return!!(this.bitmap[Math.floor(t/8)]&1<<t%8)}mightContain(t){if(0===this.ge)return!1;const e=pi(t),[n,s]=yi(e);for(let r=0;r<this.hashCount;r++){const t=this.ye(n,s,r);if(!this.we(t))return!1}return!0}static create(t,e,n){const s=t%8==0?0:8-t%8,r=new Uint8Array(Math.ceil(t/8)),i=new vi(r,s,e);return n.forEach(t=>i.insert(t)),i}insert(t){if(0===this.ge)return;const e=pi(t),[n,s]=yi(e);for(let r=0;r<this.hashCount;r++){const t=this.ye(n,s,r);this.Se(t)}}Se(t){const e=Math.floor(t/8),n=t%8;this.bitmap[e]|=1<<n}}class wi extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ii{constructor(t,e,n,s,r){this.snapshotVersion=t,this.targetChanges=e,this.targetMismatches=n,this.documentUpdates=s,this.resolvedLimboDocuments=r}static createSynthesizedRemoteEventForCurrentChange(t,e,n){const s=new Map;return s.set(t,bi.createSynthesizedTargetChangeForCurrentChange(t,e,n)),new Ii(kt.min(),s,new Sn(at),wr(),Ar())}}class bi{constructor(t,e,n,s,r){this.resumeToken=t,this.current=e,this.addedDocuments=n,this.modifiedDocuments=s,this.removedDocuments=r}static createSynthesizedTargetChangeForCurrentChange(t,e,n){return new bi(n,e,Ar(),Ar(),Ar())}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ti{constructor(t,e,n,s){this.be=t,this.removedTargetIds=e,this.key=n,this.De=s}}class Ei{constructor(t,e){this.targetId=t,this.Ce=e}}class Si{constructor(t,e,n=Rn.EMPTY_BYTE_STRING,s=null){this.state=t,this.targetIds=e,this.resumeToken=n,this.cause=s}}class _i{constructor(){this.ve=0,this.Fe=Ai(),this.Me=Rn.EMPTY_BYTE_STRING,this.xe=!1,this.Oe=!0}get current(){return this.xe}get resumeToken(){return this.Me}get Ne(){return 0!==this.ve}get Be(){return this.Oe}Le(t){t.approximateByteSize()>0&&(this.Oe=!0,this.Me=t)}ke(){let t=Ar(),e=Ar(),n=Ar();return this.Fe.forEach((s,r)=>{switch(r){case 0:t=t.add(s);break;case 2:e=e.add(s);break;case 1:n=n.add(s);break;default:K(38017,{changeType:r})}}),new bi(this.Me,this.xe,t,e,n)}qe(){this.Oe=!1,this.Fe=Ai()}Qe(t,e){this.Oe=!0,this.Fe=this.Fe.insert(t,e)}$e(t){this.Oe=!0,this.Fe=this.Fe.remove(t)}Ue(){this.ve+=1}Ke(){this.ve-=1,$(this.ve>=0,3241,{ve:this.ve})}We(){this.Oe=!0,this.xe=!0}}class xi{constructor(t){this.Ge=t,this.ze=new Map,this.je=wr(),this.Je=Ci(),this.He=Ci(),this.Ye=new Sn(at)}Ze(t){for(const e of t.be)t.De&&t.De.isFoundDocument()?this.Xe(e,t.De):this.et(e,t.key,t.De);for(const e of t.removedTargetIds)this.et(e,t.key,t.De)}tt(t){this.forEachTarget(t,e=>{const n=this.nt(e);switch(t.state){case 0:this.rt(e)&&n.Le(t.resumeToken);break;case 1:n.Ke(),n.Ne||n.qe(),n.Le(t.resumeToken);break;case 2:n.Ke(),n.Ne||this.removeTarget(e);break;case 3:this.rt(e)&&(n.We(),n.Le(t.resumeToken));break;case 4:this.rt(e)&&(this.it(e),n.Le(t.resumeToken));break;default:K(56790,{state:t.state})}})}forEachTarget(t,e){t.targetIds.length>0?t.targetIds.forEach(e):this.ze.forEach((t,n)=>{this.rt(n)&&e(n)})}st(t){const e=t.targetId,n=t.Ce.count,s=this.ot(e);if(s){const r=s.target;if(Zs(r))if(0===n){const t=new wt(r.path);this.et(e,t,Ss.newNoDocument(t,kt.min()))}else $(1===n,20013,{expectedCount:n});else{const s=this._t(e);if(s!==n){const n=this.ut(t),r=n?this.ct(n,t,s):1;if(0!==r){this.it(e);const t=2===r?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.Ye=this.Ye.insert(e,t)}}}}}ut(t){const e=t.Ce.unchangedNames;if(!e||!e.bits)return null;const{bits:{bitmap:n="",padding:s=0},hashCount:r=0}=e;let i,o;try{i=Pn(n).toUint8Array()}catch(a){if(a instanceof kn)return j("Decoding the base64 bloom filter in existence filter failed ("+a.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw a}try{o=new vi(i,s,r)}catch(a){return j(a instanceof wi?"BloomFilter error: ":"Applying bloom filter failed: ",a),null}return 0===o.ge?null:o}ct(t,e,n){return e.Ce.count===n-this.Pt(t,e.targetId)?0:2}Pt(t,e){const n=this.Ge.getRemoteKeysForTarget(e);let s=0;return n.forEach(n=>{const r=this.Ge.ht(),i=`projects/${r.projectId}/databases/${r.database}/documents/${n.path.canonicalString()}`;t.mightContain(i)||(this.et(e,n,null),s++)}),s}Tt(t){const e=new Map;this.ze.forEach((n,s)=>{const r=this.ot(s);if(r){if(n.current&&Zs(r.target)){const e=new wt(r.target.path);this.It(e).has(s)||this.Et(s,e)||this.et(s,e,Ss.newNoDocument(e,t))}n.Be&&(e.set(s,n.ke()),n.qe())}});let n=Ar();this.He.forEach((t,e)=>{let s=!0;e.forEachWhile(t=>{const e=this.ot(t);return!e||"TargetPurposeLimboResolution"===e.purpose||(s=!1,!1)}),s&&(n=n.add(t))}),this.je.forEach((e,n)=>n.setReadTime(t));const s=new Ii(t,e,this.Ye,this.je,n);return this.je=wr(),this.Je=Ci(),this.He=Ci(),this.Ye=new Sn(at),s}Xe(t,e){if(!this.rt(t))return;const n=this.Et(t,e.key)?2:0;this.nt(t).Qe(e.key,n),this.je=this.je.insert(e.key,e),this.Je=this.Je.insert(e.key,this.It(e.key).add(t)),this.He=this.He.insert(e.key,this.dt(e.key).add(t))}et(t,e,n){if(!this.rt(t))return;const s=this.nt(t);this.Et(t,e)?s.Qe(e,1):s.$e(e),this.He=this.He.insert(e,this.dt(e).delete(t)),this.He=this.He.insert(e,this.dt(e).add(t)),n&&(this.je=this.je.insert(e,n))}removeTarget(t){this.ze.delete(t)}_t(t){const e=this.nt(t).ke();return this.Ge.getRemoteKeysForTarget(t).size+e.addedDocuments.size-e.removedDocuments.size}Ue(t){this.nt(t).Ue()}nt(t){let e=this.ze.get(t);return e||(e=new _i,this.ze.set(t,e)),e}dt(t){let e=this.He.get(t);return e||(e=new Cn(at),this.He=this.He.insert(t,e)),e}It(t){let e=this.Je.get(t);return e||(e=new Cn(at),this.Je=this.Je.insert(t,e)),e}rt(t){const e=null!==this.ot(t);return e||q("WatchChangeAggregator","Detected inactive target",t),e}ot(t){const e=this.ze.get(t);return e&&e.Ne?null:this.Ge.At(t)}it(t){this.ze.set(t,new _i),this.Ge.getRemoteKeysForTarget(t).forEach(e=>{this.et(t,e,null)})}Et(t,e){return this.Ge.getRemoteKeysForTarget(t).has(e)}}function Ci(){return new Sn(wt.comparator)}function Ai(){return new Sn(wt.comparator)}const Di=(()=>({asc:"ASCENDING",desc:"DESCENDING"}))(),Ni=(()=>({"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"}))(),ki=(()=>({and:"AND",or:"OR"}))();class Ri{constructor(t,e){this.databaseId=t,this.useProto3Json=e}}function Mi(t,e){return t.useProto3Json||oe(e)?e:{value:e}}function Oi(t,e){return t.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function Vi(t,e){return t.useProto3Json?e.toBase64():e.toUint8Array()}function Pi(t,e){return Oi(t,e.toTimestamp())}function Li(t){return $(!!t,49232),kt.fromTimestamp(function(t){const e=On(t);return new Nt(e.seconds,e.nanos)}(t))}function Fi(t,e){return Ui(t,e).canonicalString()}function Ui(t,e){const n=(s=t,new pt(["projects",s.projectId,"databases",s.database])).child("documents");var s;return void 0===e?n:n.child(e)}function qi(t){const e=pt.fromString(t);return $(ao(e),10190,{key:e.toString()}),e}function Bi(t,e){return Fi(t.databaseId,e.path)}function ji(t,e){const n=qi(e);if(n.get(1)!==t.databaseId.projectId)throw new X(H.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+n.get(1)+" vs "+t.databaseId.projectId);if(n.get(3)!==t.databaseId.database)throw new X(H.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+n.get(3)+" vs "+t.databaseId.database);return new wt($i(n))}function zi(t,e){return Fi(t.databaseId,e)}function Ki(t){const e=qi(t);return 4===e.length?pt.emptyPath():$i(e)}function Gi(t){return new pt(["projects",t.databaseId.projectId,"databases",t.databaseId.database]).canonicalString()}function $i(t){return $(t.length>4&&"documents"===t.get(4),29091,{key:t.toString()}),t.popFirst(5)}function Qi(t,e,n){return{name:Bi(t,e),fields:n.value.mapValue.fields}}function Hi(t,e){let n;if(e instanceof ei)n={update:Qi(t,e.key,e.value)};else if(e instanceof oi)n={delete:Bi(t,e.key)};else if(e instanceof ni)n={update:Qi(t,e.key,e.data),updateMask:oo(e.fieldMask)};else{if(!(e instanceof ai))return K(16599,{Vt:e.type});n={verify:Bi(t,e.key)}}return e.fieldTransforms.length>0&&(n.updateTransforms=e.fieldTransforms.map(t=>function(t,e){const n=e.transform;if(n instanceof Lr)return{fieldPath:e.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(n instanceof Fr)return{fieldPath:e.field.canonicalString(),appendMissingElements:{values:n.elements}};if(n instanceof qr)return{fieldPath:e.field.canonicalString(),removeAllFromArray:{values:n.elements}};if(n instanceof jr)return{fieldPath:e.field.canonicalString(),increment:n.Ae};throw K(20930,{transform:e.transform})}(0,t))),e.precondition.isNone||(n.currentDocument=(s=t,void 0!==(r=e.precondition).updateTime?{updateTime:Pi(s,r.updateTime)}:void 0!==r.exists?{exists:r.exists}:K(27497))),n;var s,r}function Xi(t,e){const n=e.currentDocument?void 0!==(r=e.currentDocument).updateTime?Qr.updateTime(Li(r.updateTime)):void 0!==r.exists?Qr.exists(r.exists):Qr.none():Qr.none(),s=e.updateTransforms?e.updateTransforms.map(e=>function(t,e){let n=null;if("setToServerValue"in e)$("REQUEST_TIME"===e.setToServerValue,16630,{proto:e}),n=new Lr;else if("appendMissingElements"in e){const t=e.appendMissingElements.values||[];n=new Fr(t)}else if("removeAllFromArray"in e){const t=e.removeAllFromArray.values||[];n=new qr(t)}else"increment"in e?n=new jr(t,e.increment):K(16584,{proto:e});const s=vt.fromServerFormat(e.fieldPath);return new Gr(s,n)}(t,e)):[];var r;if(e.update){e.update.name;const r=ji(t,e.update.name),i=new Ts({mapValue:{fields:e.update.fields}});if(e.updateMask){const t=function(t){const e=t.fieldPaths||[];return new Nn(e.map(t=>vt.fromServerFormat(t)))}(e.updateMask);return new ni(r,i,t,n,s)}return new ei(r,i,n,s)}if(e.delete){const s=ji(t,e.delete);return new oi(s,n)}if(e.verify){const s=ji(t,e.verify);return new ai(s,n)}return K(1463,{proto:e})}function Yi(t,e){return{documents:[zi(t,e.path)]}}function Wi(t,e){const n={structuredQuery:{}},s=e.path;let r;null!==e.collectionGroup?(r=s,n.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(r=s.popLast(),n.structuredQuery.from=[{collectionId:s.lastSegment()}]),n.parent=zi(t,r);const i=function(t){if(0!==t.length)return io(Rs.create(t,"and"))}(e.filters);i&&(n.structuredQuery.where=i);const o=function(t){if(0!==t.length)return t.map(t=>{return{field:so((e=t).field),direction:to(e.dir)};var e})}(e.orderBy);o&&(n.structuredQuery.orderBy=o);const a=Mi(t,e.limit);return null!==a&&(n.structuredQuery.limit=a),e.startAt&&(n.structuredQuery.startAt={before:(u=e.startAt).inclusive,values:u.position}),e.endAt&&(n.structuredQuery.endAt=function(t){return{before:!t.inclusive,values:t.position}}(e.endAt)),{ft:n,parent:r};var u}function Ji(t){let e=Ki(t.parent);const n=t.structuredQuery,s=n.from?n.from.length:0;let r=null;if(s>0){$(1===s,65062);const t=n.from[0];t.allDescendants?r=t.collectionId:e=e.child(t.collectionId)}let i=[];n.where&&(i=function(t){const e=Zi(t);return e instanceof Rs&&Vs(e)?e.getFilters():[e]}(n.where));let o=[];n.orderBy&&(o=n.orderBy.map(t=>{return new As(ro((e=t).field),function(t){switch(t){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(e.direction));var e}));let a=null;n.limit&&(a=function(t){let e;return e="object"==typeof t?t.value:t,oe(e)?null:e}(n.limit));let u=null;n.startAt&&(u=function(t){const e=!!t.before,n=t.values||[];return new _s(n,e)}(n.startAt));let c=null;return n.endAt&&(c=function(t){const e=!t.before,n=t.values||[];return new _s(n,e)}(n.endAt)),function(t,e,n,s,r,i,o,a){return new sr(t,e,n,s,r,i,o,a)}(e,r,o,i,a,"F",u,c)}function Zi(t){return void 0!==t.unaryFilter?function(t){switch(t.unaryFilter.op){case"IS_NAN":const e=ro(t.unaryFilter.field);return ks.create(e,"==",{doubleValue:NaN});case"IS_NULL":const n=ro(t.unaryFilter.field);return ks.create(n,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const s=ro(t.unaryFilter.field);return ks.create(s,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const r=ro(t.unaryFilter.field);return ks.create(r,"!=",{nullValue:"NULL_VALUE"});case"OPERATOR_UNSPECIFIED":return K(61313);default:return K(60726)}}(t):void 0!==t.fieldFilter?(e=t,ks.create(ro(e.fieldFilter.field),function(t){switch(t){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";case"OPERATOR_UNSPECIFIED":return K(58110);default:return K(50506)}}(e.fieldFilter.op),e.fieldFilter.value)):void 0!==t.compositeFilter?function(t){return Rs.create(t.compositeFilter.filters.map(t=>Zi(t)),function(t){switch(t){case"AND":return"and";case"OR":return"or";default:return K(1026)}}(t.compositeFilter.op))}(t):K(30097,{filter:t});var e}function to(t){return Di[t]}function eo(t){return Ni[t]}function no(t){return ki[t]}function so(t){return{fieldPath:t.canonicalString()}}function ro(t){return vt.fromServerFormat(t.fieldPath)}function io(t){return t instanceof ks?function(t){if("=="===t.op){if(ds(t.value))return{unaryFilter:{field:so(t.field),op:"IS_NAN"}};if(ls(t.value))return{unaryFilter:{field:so(t.field),op:"IS_NULL"}}}else if("!="===t.op){if(ds(t.value))return{unaryFilter:{field:so(t.field),op:"IS_NOT_NAN"}};if(ls(t.value))return{unaryFilter:{field:so(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:so(t.field),op:eo(t.op),value:t.value}}}(t):t instanceof Rs?function(t){const e=t.getFilters().map(t=>io(t));return 1===e.length?e[0]:{compositeFilter:{op:no(t.op),filters:e}}}(t):K(54877,{filter:t})}function oo(t){const e=[];return t.fields.forEach(t=>e.push(t.canonicalString())),{fieldPaths:e}}function ao(t){return t.length>=4&&"projects"===t.get(0)&&"databases"===t.get(2)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uo{constructor(t,e,n,s,r=kt.min(),i=kt.min(),o=Rn.EMPTY_BYTE_STRING,a=null){this.target=t,this.targetId=e,this.purpose=n,this.sequenceNumber=s,this.snapshotVersion=r,this.lastLimboFreeSnapshotVersion=i,this.resumeToken=o,this.expectedCount=a}withSequenceNumber(t){return new uo(this.target,this.targetId,this.purpose,t,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(t,e){return new uo(this.target,this.targetId,this.purpose,this.sequenceNumber,e,this.lastLimboFreeSnapshotVersion,t,null)}withExpectedCount(t){return new uo(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,t)}withLastLimboFreeSnapshotVersion(t){return new uo(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,t,this.resumeToken,this.expectedCount)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class co{constructor(t){this.yt=t}}function ho(t,e){let n;if(e.document)n=function(t,e,n){const s=ji(t,e.name),r=Li(e.updateTime),i=e.createTime?Li(e.createTime):kt.min(),o=new Ts({mapValue:{fields:e.fields}}),a=Ss.newFoundDocument(s,r,i,o);return n&&a.setHasCommittedMutations(),n?a.setHasCommittedMutations():a}(t.yt,e.document,!!e.hasCommittedMutations);else if(e.noDocument){const t=wt.fromSegments(e.noDocument.path),s=go(e.noDocument.readTime);n=Ss.newNoDocument(t,s),e.hasCommittedMutations&&n.setHasCommittedMutations()}else{if(!e.unknownDocument)return K(56709);{const t=wt.fromSegments(e.unknownDocument.path),s=go(e.unknownDocument.version);n=Ss.newUnknownDocument(t,s)}}return e.readTime&&n.setReadTime(function(t){const e=new Nt(t[0],t[1]);return kt.fromTimestamp(e)}(e.readTime)),n}function lo(t,e){const n=e.key,s={prefixPath:n.getCollectionPath().popLast().toArray(),collectionGroup:n.collectionGroup,documentId:n.path.lastSegment(),readTime:fo(e.readTime),hasCommittedMutations:e.hasCommittedMutations};if(e.isFoundDocument())s.document={name:Bi(r=t.yt,(i=e).key),fields:i.data.value.mapValue.fields,updateTime:Oi(r,i.version.toTimestamp()),createTime:Oi(r,i.createTime.toTimestamp())};else if(e.isNoDocument())s.noDocument={path:n.path.toArray(),readTime:mo(e.version)};else{if(!e.isUnknownDocument())return K(57904,{document:e});s.unknownDocument={path:n.path.toArray(),version:mo(e.version)}}var r,i;return s}function fo(t){const e=t.toTimestamp();return[e.seconds,e.nanoseconds]}function mo(t){const e=t.toTimestamp();return{seconds:e.seconds,nanoseconds:e.nanoseconds}}function go(t){const e=new Nt(t.seconds,t.nanoseconds);return kt.fromTimestamp(e)}function po(t,e){const n=(e.baseMutations||[]).map(e=>Xi(t.yt,e));for(let i=0;i<e.mutations.length-1;++i){const t=e.mutations[i];if(i+1<e.mutations.length&&void 0!==e.mutations[i+1].transform){const n=e.mutations[i+1];t.updateTransforms=n.transform.fieldTransforms,e.mutations.splice(i+1,1),++i}}const s=e.mutations.map(e=>Xi(t.yt,e)),r=Nt.fromMillis(e.localWriteTimeMs);return new ui(e.batchId,r,n,s)}function yo(t){const e=go(t.readTime),n=void 0!==t.lastLimboFreeSnapshotVersion?go(t.lastLimboFreeSnapshotVersion):kt.min();let s;return s=void 0!==t.query.documents?function(t){const e=t.documents.length;return $(1===e,1966,{count:e}),ur(rr(Ki(t.documents[0])))}(t.query):function(t){return ur(Ji(t))}(t.query),new uo(s,t.targetId,"TargetPurposeListen",t.lastListenSequenceNumber,e,n,Rn.fromBase64String(t.resumeToken))}function vo(t,e){const n=mo(e.snapshotVersion),s=mo(e.lastLimboFreeSnapshotVersion);let r;r=Zs(e.target)?Yi(t.yt,e.target):Wi(t.yt,e.target).ft;const i=e.resumeToken.toBase64();return{targetId:e.targetId,canonicalId:Ws(e.target),readTime:n,resumeToken:i,lastListenSequenceNumber:e.sequenceNumber,lastLimboFreeSnapshotVersion:s,query:r}}function wo(t){const e=Ji({parent:t.parent,structuredQuery:t.structuredQuery});return"LAST"===t.limitType?hr(e,e.limit,"L"):e}function Io(t,e){return new hi(e.largestBatchId,Xi(t.yt,e.overlayMutation))}function bo(t,e){const n=e.path.lastSegment();return[t,ce(e.path.popLast()),n]}function To(t,e,n,s){return{indexId:t,uid:e,sequenceNumber:n,readTime:mo(s.readTime),documentKey:ce(s.documentKey.path),largestBatchId:s.largestBatchId}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Eo{getBundleMetadata(t,e){return So(t).get(e).next(t=>{if(t)return{id:(e=t).bundleId,createTime:go(e.createTime),version:e.version};var e})}saveBundleMetadata(t,e){return So(t).put({bundleId:(n=e).id,createTime:mo(Li(n.createTime)),version:n.version});var n}getNamedQuery(t,e){return _o(t).get(e).next(t=>{if(t)return{name:(e=t).name,query:wo(e.bundledQuery),readTime:go(e.readTime)};var e})}saveNamedQuery(t,e){return _o(t).put({name:(n=e).name,readTime:mo(Li(n.readTime)),bundledQuery:n.bundledQuery});var n}}function So(t){return In(t,Ge)}function _o(t){return In(t,$e)}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xo{constructor(t,e){this.serializer=t,this.userId=e}static wt(t,e){const n=e.uid||"";return new xo(t,n)}getOverlay(t,e){return Co(t).get(bo(this.userId,e)).next(t=>t?Io(this.serializer,t):null)}getOverlays(t,e){const n=Er();return zt.forEach(e,e=>this.getOverlay(t,e).next(t=>{null!==t&&n.set(e,t)})).next(()=>n)}saveOverlays(t,e,n){const s=[];return n.forEach((n,r)=>{const i=new hi(e,r);s.push(this.St(t,i))}),zt.waitFor(s)}removeOverlaysForBatchId(t,e,n){const s=new Set;e.forEach(t=>s.add(ce(t.getCollectionPath())));const r=[];return s.forEach(e=>{const s=IDBKeyRange.bound([this.userId,e,n],[this.userId,e,n+1],!1,!0);r.push(Co(t).Z(on,s))}),zt.waitFor(r)}getOverlaysForCollection(t,e,n){const s=Er(),r=ce(e),i=IDBKeyRange.bound([this.userId,r,n],[this.userId,r,Number.POSITIVE_INFINITY],!0);return Co(t).J(on,i).next(t=>{for(const e of t){const t=Io(this.serializer,e);s.set(t.getKey(),t)}return s})}getOverlaysForCollectionGroup(t,e,n,s){const r=Er();let i;const o=IDBKeyRange.bound([this.userId,e,n],[this.userId,e,Number.POSITIVE_INFINITY],!0);return Co(t).ee({index:un,range:o},(t,e,n)=>{const o=Io(this.serializer,e);r.size()<s||o.largestBatchId===i?(r.set(o.getKey(),o),i=o.largestBatchId):n.done()}).next(()=>r)}St(t,e){return Co(t).put(function(t,e,n){const[s,r,i]=bo(e,n.mutation.key);return{userId:e,collectionPath:r,documentId:i,collectionGroup:n.mutation.key.getCollectionGroup(),largestBatchId:n.largestBatchId,overlayMutation:Hi(t.yt,n.mutation)}}(this.serializer,this.userId,e))}}function Co(t){return In(t,sn)}
/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ao{bt(t){return In(t,hn)}getSessionToken(t){return this.bt(t).get("sessionToken").next(t=>{const e=null==t?void 0:t.value;return e?Rn.fromUint8Array(e):Rn.EMPTY_BYTE_STRING})}setSessionToken(t,e){return this.bt(t).put({name:"sessionToken",value:e.toUint8Array()})}}
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Do{constructor(){}Dt(t,e){this.Ct(t,e),e.vt()}Ct(t,e){if("nullValue"in t)this.Ft(e,5);else if("booleanValue"in t)this.Ft(e,10),e.Mt(t.booleanValue?1:0);else if("integerValue"in t)this.Ft(e,15),e.Mt(Vn(t.integerValue));else if("doubleValue"in t){const n=Vn(t.doubleValue);isNaN(n)?this.Ft(e,13):(this.Ft(e,15),ae(n)?e.Mt(0):e.Mt(n))}else if("timestampValue"in t){let n=t.timestampValue;this.Ft(e,20),"string"==typeof n&&(n=On(n)),e.xt(`${n.seconds||""}`),e.Mt(n.nanos||0)}else if("stringValue"in t)this.Ot(t.stringValue,e),this.Nt(e);else if("bytesValue"in t)this.Ft(e,30),e.Bt(Pn(t.bytesValue)),this.Nt(e);else if("referenceValue"in t)this.Lt(t.referenceValue,e);else if("geoPointValue"in t){const n=t.geoPointValue;this.Ft(e,45),e.Mt(n.latitude||0),e.Mt(n.longitude||0)}else"mapValue"in t?ps(t)?this.Ft(e,Number.MAX_SAFE_INTEGER):ms(t)?this.kt(t.mapValue,e):(this.qt(t.mapValue,e),this.Nt(e)):"arrayValue"in t?(this.Qt(t.arrayValue,e),this.Nt(e)):K(19022,{$t:t})}Ot(t,e){this.Ft(e,25),this.Ut(t,e)}Ut(t,e){e.xt(t)}qt(t,e){const n=t.fields||{};this.Ft(e,55);for(const s of Object.keys(n))this.Ot(s,e),this.Ct(n[s],e)}kt(t,e){var n,s;const r=t.fields||{};this.Ft(e,53);const i=Wn,o=(null==(s=null==(n=r[i].arrayValue)?void 0:n.values)?void 0:s.length)||0;this.Ft(e,15),e.Mt(Vn(o)),this.Ot(i,e),this.Ct(r[i],e)}Qt(t,e){const n=t.values||[];this.Ft(e,50);for(const s of n)this.Ct(s,e)}Lt(t,e){this.Ft(e,37),wt.fromName(t).path.forEach(t=>{this.Ft(e,60),this.Ut(t,e)})}Ft(t,e){t.Mt(e)}Nt(t){t.Mt(2)}}Do.Kt=new Do;
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law | agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES | CONDITIONS OF ANY KIND, either express | implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const No=255;function ko(t){if(0===t)return 8;let e=0;return t>>4||(e+=4,t<<=4),t>>6||(e+=2,t<<=2),t>>7||(e+=1),e}function Ro(t){const e=64-function(t){let e=0;for(let n=0;n<8;++n){const s=ko(255&t[n]);if(e+=s,8!==s)break}return e}(t);return Math.ceil(e/8)}class Mo{constructor(){this.buffer=new Uint8Array(1024),this.position=0}Wt(t){const e=t[Symbol.iterator]();let n=e.next();for(;!n.done;)this.Gt(n.value),n=e.next();this.zt()}jt(t){const e=t[Symbol.iterator]();let n=e.next();for(;!n.done;)this.Jt(n.value),n=e.next();this.Ht()}Yt(t){for(const e of t){const t=e.charCodeAt(0);if(t<128)this.Gt(t);else if(t<2048)this.Gt(960|t>>>6),this.Gt(128|63&t);else if(e<"\ud800"||"\udbff"<e)this.Gt(480|t>>>12),this.Gt(128|63&t>>>6),this.Gt(128|63&t);else{const t=e.codePointAt(0);this.Gt(240|t>>>18),this.Gt(128|63&t>>>12),this.Gt(128|63&t>>>6),this.Gt(128|63&t)}}this.zt()}Zt(t){for(const e of t){const t=e.charCodeAt(0);if(t<128)this.Jt(t);else if(t<2048)this.Jt(960|t>>>6),this.Jt(128|63&t);else if(e<"\ud800"||"\udbff"<e)this.Jt(480|t>>>12),this.Jt(128|63&t>>>6),this.Jt(128|63&t);else{const t=e.codePointAt(0);this.Jt(240|t>>>18),this.Jt(128|63&t>>>12),this.Jt(128|63&t>>>6),this.Jt(128|63&t)}}this.Ht()}Xt(t){const e=this.en(t),n=Ro(e);this.tn(1+n),this.buffer[this.position++]=255&n;for(let s=e.length-n;s<e.length;++s)this.buffer[this.position++]=255&e[s]}nn(t){const e=this.en(t),n=Ro(e);this.tn(1+n),this.buffer[this.position++]=~(255&n);for(let s=e.length-n;s<e.length;++s)this.buffer[this.position++]=~(255&e[s])}rn(){this.sn(No),this.sn(255)}_n(){this.an(No),this.an(255)}reset(){this.position=0}seed(t){this.tn(t.length),this.buffer.set(t,this.position),this.position+=t.length}un(){return this.buffer.slice(0,this.position)}en(t){const e=function(t){const e=new DataView(new ArrayBuffer(8));return e.setFloat64(0,t,!1),new Uint8Array(e.buffer)}(t),n=!!(128&e[0]);e[0]^=n?255:128;for(let s=1;s<e.length;++s)e[s]^=n?255:0;return e}Gt(t){const e=255&t;0===e?(this.sn(0),this.sn(255)):e===No?(this.sn(No),this.sn(0)):this.sn(e)}Jt(t){const e=255&t;0===e?(this.an(0),this.an(255)):e===No?(this.an(No),this.an(0)):this.an(t)}zt(){this.sn(0),this.sn(1)}Ht(){this.an(0),this.an(1)}sn(t){this.tn(1),this.buffer[this.position++]=t}an(t){this.tn(1),this.buffer[this.position++]=~t}tn(t){const e=t+this.position;if(e<=this.buffer.length)return;let n=2*this.buffer.length;n<e&&(n=e);const s=new Uint8Array(n);s.set(this.buffer),this.buffer=s}}class Oo{constructor(t){this.cn=t}Bt(t){this.cn.Wt(t)}xt(t){this.cn.Yt(t)}Mt(t){this.cn.Xt(t)}vt(){this.cn.rn()}}class Vo{constructor(t){this.cn=t}Bt(t){this.cn.jt(t)}xt(t){this.cn.Zt(t)}Mt(t){this.cn.nn(t)}vt(){this.cn._n()}}class Po{constructor(){this.cn=new Mo,this.ln=new Oo(this.cn),this.hn=new Vo(this.cn)}seed(t){this.cn.seed(t)}Pn(t){return 0===t?this.ln:this.hn}un(){return this.cn.un()}reset(){this.cn.reset()}}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lo{constructor(t,e,n,s){this.Tn=t,this.In=e,this.En=n,this.dn=s}An(){const t=this.dn.length,e=0===t||255===this.dn[t-1]?t+1:t,n=new Uint8Array(e);return n.set(this.dn,0),e!==t?n.set([0],this.dn.length):++n[n.length-1],new Lo(this.Tn,this.In,this.En,n)}Rn(t,e,n){return{indexId:this.Tn,uid:t,arrayValue:qo(this.En),directionalValue:qo(this.dn),orderedDocumentKey:qo(e),documentKey:n.path.toArray()}}Vn(t,e,n){const s=this.Rn(t,e,n);return[s.indexId,s.uid,s.arrayValue,s.directionalValue,s.orderedDocumentKey,s.documentKey]}}function Fo(t,e){let n=t.Tn-e.Tn;return 0!==n?n:(n=Uo(t.En,e.En),0!==n?n:(n=Uo(t.dn,e.dn),0!==n?n:wt.comparator(t.In,e.In)))}function Uo(t,e){for(let n=0;n<t.length&&n<e.length;++n){const s=t[n]-e[n];if(0!==s)return s}return t.length-e.length}function qo(t){return b()?function(t){let e="";for(let n=0;n<t.length;n++)e+=String.fromCharCode(t[n]);return e}(t):t}function Bo(t){return"string"!=typeof t?t:function(t){const e=new Uint8Array(t.length);for(let n=0;n<t.length;n++)e[n]=t.charCodeAt(n);return e}(t)}class jo{constructor(t){this.mn=new Cn((t,e)=>vt.comparator(t.field,e.field)),this.collectionId=null!=t.collectionGroup?t.collectionGroup:t.path.lastSegment(),this.fn=t.orderBy,this.gn=[];for(const e of t.filters){const t=e;t.isInequality()?this.mn=this.mn.add(t):this.gn.push(t)}}get pn(){return this.mn.size>1}yn(t){if($(t.collectionGroup===this.collectionId,49279),this.pn)return!1;const e=Mt(t);if(void 0!==e&&!this.wn(e))return!1;const n=Ot(t);let s=new Set,r=0,i=0;for(;r<n.length&&this.wn(n[r]);++r)s=s.add(n[r].fieldPath.canonicalString());if(r===n.length)return!0;if(this.mn.size>0){const t=this.mn.getIterator().getNext();if(!s.has(t.field.canonicalString())){const e=n[r];if(!this.Sn(t,e)||!this.bn(this.fn[i++],e))return!1}++r}for(;r<n.length;++r){const t=n[r];if(i>=this.fn.length||!this.bn(this.fn[i++],t))return!1}return!0}Dn(){if(this.pn)return null;let t=new Cn(vt.comparator);const e=[];for(const n of this.gn)if(!n.field.isKeyField())if("array-contains"===n.op||"array-contains-any"===n.op)e.push(new Vt(n.field,2));else{if(t.has(n.field))continue;t=t.add(n.field),e.push(new Vt(n.field,0))}for(const n of this.fn)n.field.isKeyField()||t.has(n.field)||(t=t.add(n.field),e.push(new Vt(n.field,"asc"===n.dir?0:1)));return new Rt(Rt.UNKNOWN_ID,this.collectionId,e,Pt.empty())}wn(t){for(const e of this.gn)if(this.Sn(e,t))return!0;return!1}Sn(t,e){if(void 0===t||!t.field.isEqual(e.fieldPath))return!1;const n="array-contains"===t.op||"array-contains-any"===t.op;return 2===e.kind===n}bn(t,e){return!!t.field.isEqual(e.fieldPath)&&(0===e.kind&&"asc"===t.dir||1===e.kind&&"desc"===t.dir)}}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function zo(t){var e,n;if($(t instanceof ks||t instanceof Rs,20012),t instanceof ks){if(t instanceof $s){const s=(null==(n=null==(e=t.value.arrayValue)?void 0:e.values)?void 0:n.map(e=>ks.create(t.field,"==",e)))||[];return Rs.create(s,"or")}return t}const s=t.filters.map(t=>zo(t));return Rs.create(s,t.op)}function Ko(t){if(0===t.getFilters().length)return[];const e=Ho(zo(t));return $(Qo(e),7391),Go(e)||$o(e)?[e]:e.getFilters()}function Go(t){return t instanceof ks}function $o(t){return t instanceof Rs&&Vs(t)}function Qo(t){return Go(t)||$o(t)||function(t){if(t instanceof Rs&&Os(t)){for(const e of t.getFilters())if(!Go(e)&&!$o(e))return!1;return!0}return!1}(t)}function Ho(t){if($(t instanceof ks||t instanceof Rs,34018),t instanceof ks)return t;if(1===t.filters.length)return Ho(t.filters[0]);const e=t.filters.map(t=>Ho(t));let n=Rs.create(e,t.op);return n=Wo(n),Qo(n)?n:($(n instanceof Rs,64498),$(Ms(n),40251),$(n.filters.length>1,57927),n.filters.reduce((t,e)=>Xo(t,e)))}function Xo(t,e){let n;return $(t instanceof ks||t instanceof Rs,38388),$(e instanceof ks||e instanceof Rs,25473),n=t instanceof ks?e instanceof ks?(s=t,r=e,Rs.create([s,r],"and")):Yo(t,e):e instanceof ks?Yo(e,t):function(t,e){if($(t.filters.length>0&&e.filters.length>0,48005),Ms(t)&&Ms(e))return Us(t,e.getFilters());const n=Os(t)?t:e,s=Os(t)?e:t,r=n.filters.map(t=>Xo(t,s));return Rs.create(r,"or")}(t,e),Wo(n);var s,r}function Yo(t,e){if(Ms(e))return Us(e,t.getFilters());{const n=e.filters.map(e=>Xo(t,e));return Rs.create(n,"or")}}function Wo(t){if($(t instanceof ks||t instanceof Rs,11850),t instanceof ks)return t;const e=t.getFilters();if(1===e.length)return Wo(e[0]);if(Ps(t))return t;const n=e.map(t=>Wo(t)),s=[];return n.forEach(e=>{e instanceof ks?s.push(e):e instanceof Rs&&(e.op===t.op?s.push(...e.filters):s.push(e))}),1===s.length?s[0]:Rs.create(s,t.op)
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */}class Jo{constructor(){this.Cn=new Zo}addToCollectionParentIndex(t,e){return this.Cn.add(e),zt.resolve()}getCollectionParents(t,e){return zt.resolve(this.Cn.getEntries(e))}addFieldIndex(t,e){return zt.resolve()}deleteFieldIndex(t,e){return zt.resolve()}deleteAllFieldIndexes(t){return zt.resolve()}createTargetIndexes(t,e){return zt.resolve()}getDocumentsMatchingTarget(t,e){return zt.resolve(null)}getIndexType(t,e){return zt.resolve(0)}getFieldIndexes(t,e){return zt.resolve([])}getNextCollectionGroupToUpdate(t){return zt.resolve(null)}getMinOffset(t,e){return zt.resolve(Ft.min())}getMinOffsetFromCollectionGroup(t,e){return zt.resolve(Ft.min())}updateCollectionGroup(t,e,n){return zt.resolve()}updateIndexEntries(t,e){return zt.resolve()}}class Zo{constructor(){this.index={}}add(t){const e=t.lastSegment(),n=t.popLast(),s=this.index[e]||new Cn(pt.comparator),r=!s.has(n);return this.index[e]=s.add(n),r}has(t){const e=t.lastSegment(),n=t.popLast(),s=this.index[e];return s&&s.has(n)}getEntries(t){return(this.index[t]||new Cn(pt.comparator)).toArray()}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ta="IndexedDbIndexManager",ea=new Uint8Array(0);class na{constructor(t,e){this.databaseId=e,this.vn=new Zo,this.Fn=new yr(t=>Ws(t),(t,e)=>Js(t,e)),this.uid=t.uid||""}addToCollectionParentIndex(t,e){if(!this.vn.has(e)){const n=e.lastSegment(),s=e.popLast();t.addOnCommittedListener(()=>{this.vn.add(e)});const r={collectionId:n,parent:ce(s)};return sa(t).put(r)}return zt.resolve()}getCollectionParents(t,e){const n=[],s=IDBKeyRange.bound([e,""],[ft(e),""],!1,!0);return sa(t).J(s).next(t=>{for(const s of t){if(s.collectionId!==e)break;n.push(de(s.parent))}return n})}addFieldIndex(t,e){const n=ia(t),s={indexId:(r=e).indexId,collectionGroup:r.collectionGroup,fields:r.fields.map(t=>[t.fieldPath.canonicalString(),t.kind])};var r;delete s.indexId;const i=n.add(s);if(e.indexState){const n=oa(t);return i.next(t=>{n.put(To(t,this.uid,e.indexState.sequenceNumber,e.indexState.offset))})}return i.next()}deleteFieldIndex(t,e){const n=ia(t),s=oa(t),r=ra(t);return n.delete(e.indexId).next(()=>s.delete(IDBKeyRange.bound([e.indexId],[e.indexId+1],!1,!0))).next(()=>r.delete(IDBKeyRange.bound([e.indexId],[e.indexId+1],!1,!0)))}deleteAllFieldIndexes(t){const e=ia(t),n=ra(t),s=oa(t);return e.Z().next(()=>n.Z()).next(()=>s.Z())}createTargetIndexes(t,e){return zt.forEach(this.Mn(e),e=>this.getIndexType(t,e).next(n=>{if(0===n||1===n){const n=new jo(e).Dn();if(null!=n)return this.addFieldIndex(t,n)}}))}getDocumentsMatchingTarget(t,e){const n=ra(t);let s=!0;const r=new Map;return zt.forEach(this.Mn(e),e=>this.xn(t,e).next(t=>{s&&(s=!!t),r.set(e,t)})).next(()=>{if(s){let t=Ar();const s=[];return zt.forEach(r,(r,i)=>{var o;q(ta,`Using index ${o=r,`id=${o.indexId}|cg=${o.collectionGroup}|f=${o.fields.map(t=>`${t.fieldPath}:${t.kind}`).join(",")}`} to execute ${Ws(e)}`);const a=function(t,e){const n=Mt(e);if(void 0===n)return null;for(const s of tr(t,n.fieldPath))switch(s.op){case"array-contains-any":return s.value.arrayValue.values||[];case"array-contains":return[s.value]}return null}(i,r),u=function(t,e){const n=new Map;for(const s of Ot(e))for(const e of tr(t,s.fieldPath))switch(e.op){case"==":case"in":n.set(s.fieldPath.canonicalString(),e.value);break;case"not-in":case"!=":return n.set(s.fieldPath.canonicalString(),e.value),Array.from(n.values())}return null}(i,r),c=function(t,e){const n=[];let s=!0;for(const r of Ot(e)){const e=0===r.kind?er(t,r.fieldPath,t.startAt):nr(t,r.fieldPath,t.startAt);n.push(e.value),s&&(s=e.inclusive)}return new _s(n,s)}(i,r),h=function(t,e){const n=[];let s=!0;for(const r of Ot(e)){const e=0===r.kind?nr(t,r.fieldPath,t.endAt):er(t,r.fieldPath,t.endAt);n.push(e.value),s&&(s=e.inclusive)}return new _s(n,s)}(i,r),l=this.On(r,i,c),d=this.On(r,i,h),f=this.Nn(r,i,u),m=this.Bn(r.indexId,a,l,c.inclusive,d,h.inclusive,f);return zt.forEach(m,r=>n.Y(r,e.limit).next(e=>{e.forEach(e=>{const n=wt.fromSegments(e.documentKey);t.has(n)||(t=t.add(n),s.push(n))})}))}).next(()=>s)}return zt.resolve(null)})}Mn(t){let e=this.Fn.get(t);return e||(e=0===t.filters.length?[t]:Ko(Rs.create(t.filters,"and")).map(e=>Ys(t.path,t.collectionGroup,t.orderBy,e.getFilters(),t.limit,t.startAt,t.endAt)),this.Fn.set(t,e),e)}Bn(t,e,n,s,r,i,o){const a=(null!=e?e.length:1)*Math.max(n.length,r.length),u=a/(null!=e?e.length:1),c=[];for(let h=0;h<a;++h){const a=e?this.Ln(e[h/u]):ea,l=this.kn(t,a,n[h%u],s),d=this.qn(t,a,r[h%u],i),f=o.map(e=>this.kn(t,a,e,!0));c.push(...this.createRange(l,d,f))}return c}kn(t,e,n,s){const r=new Lo(t,wt.empty(),e,n);return s?r:r.An()}qn(t,e,n,s){const r=new Lo(t,wt.empty(),e,n);return s?r.An():r}xn(t,e){const n=new jo(e),s=null!=e.collectionGroup?e.collectionGroup:e.path.lastSegment();return this.getFieldIndexes(t,s).next(t=>{let e=null;for(const s of t)n.yn(s)&&(!e||s.fields.length>e.fields.length)&&(e=s);return e})}getIndexType(t,e){let n=2;const s=this.Mn(e);return zt.forEach(s,e=>this.xn(t,e).next(t=>{t?0!==n&&t.fields.length<function(t){let e=new Cn(vt.comparator),n=!1;for(const s of t.filters)for(const t of s.getFlattenedFilters())t.field.isKeyField()||("array-contains"===t.op||"array-contains-any"===t.op?n=!0:e=e.add(t.field));for(const s of t.orderBy)s.field.isKeyField()||(e=e.add(s.field));return e.size+(n?1:0)}(e)&&(n=1):n=0})).next(()=>null!==e.limit&&s.length>1&&2===n?1:n)}Qn(t,e){const n=new Po;for(const s of Ot(t)){const t=e.data.field(s.fieldPath);if(null==t)return null;const r=n.Pn(s.kind);Do.Kt.Dt(t,r)}return n.un()}Ln(t){const e=new Po;return Do.Kt.Dt(t,e.Pn(0)),e.un()}$n(t,e){const n=new Po;return Do.Kt.Dt(us(this.databaseId,e),n.Pn(function(t){const e=Ot(t);return 0===e.length?0:e[e.length-1].kind}(t))),n.un()}Nn(t,e,n){if(null===n)return[];let s=[];s.push(new Po);let r=0;for(const i of Ot(t)){const t=n[r++];for(const n of s)if(this.Un(e,i.fieldPath)&&hs(t))s=this.Kn(s,i,t);else{const e=n.Pn(i.kind);Do.Kt.Dt(t,e)}}return this.Wn(s)}On(t,e,n){return this.Nn(t,e,n.position)}Wn(t){const e=[];for(let n=0;n<t.length;++n)e[n]=t[n].un();return e}Kn(t,e,n){const s=[...t],r=[];for(const i of n.arrayValue.values||[])for(const t of s){const n=new Po;n.seed(t.un()),Do.Kt.Dt(i,n.Pn(e.kind)),r.push(n)}return r}Un(t,e){return!!t.filters.find(t=>t instanceof ks&&t.field.isEqual(e)&&("in"===t.op||"not-in"===t.op))}getFieldIndexes(t,e){const n=ia(t),s=oa(t);return(e?n.J(He,IDBKeyRange.bound(e,e)):n.J()).next(t=>{const e=[];return zt.forEach(t,t=>s.get([t.indexId,this.uid]).next(n=>{e.push(function(t,e){const n=e?new Pt(e.sequenceNumber,new Ft(go(e.readTime),new wt(de(e.documentKey)),e.largestBatchId)):Pt.empty(),s=t.fields.map(([t,e])=>new Vt(vt.fromServerFormat(t),e));return new Rt(t.indexId,t.collectionGroup,s,n)}(t,n))})).next(()=>e)})}getNextCollectionGroupToUpdate(t){return this.getFieldIndexes(t).next(t=>0===t.length?null:(t.sort((t,e)=>{const n=t.indexState.sequenceNumber-e.indexState.sequenceNumber;return 0!==n?n:at(t.collectionGroup,e.collectionGroup)}),t[0].collectionGroup))}updateCollectionGroup(t,e,n){const s=ia(t),r=oa(t);return this.Gn(t).next(t=>s.J(He,IDBKeyRange.bound(e,e)).next(e=>zt.forEach(e,e=>r.put(To(e.indexId,this.uid,t,n)))))}updateIndexEntries(t,e){const n=new Map;return zt.forEach(e,(e,s)=>{const r=n.get(e.collectionGroup);return(r?zt.resolve(r):this.getFieldIndexes(t,e.collectionGroup)).next(r=>(n.set(e.collectionGroup,r),zt.forEach(r,n=>this.zn(t,e,n).next(e=>{const r=this.jn(s,n);return e.isEqual(r)?zt.resolve():this.Jn(t,s,n,e,r)}))))})}Hn(t,e,n,s){return ra(t).put(s.Rn(this.uid,this.$n(n,e.key),e.key))}Yn(t,e,n,s){return ra(t).delete(s.Vn(this.uid,this.$n(n,e.key),e.key))}zn(t,e,n){const s=ra(t);let r=new Cn(Fo);return s.ee({index:en,range:IDBKeyRange.only([n.indexId,this.uid,qo(this.$n(n,e))])},(t,s)=>{r=r.add(new Lo(n.indexId,e,Bo(s.arrayValue),Bo(s.directionalValue)))}).next(()=>r)}jn(t,e){let n=new Cn(Fo);const s=this.Qn(e,t);if(null==s)return n;const r=Mt(e);if(null!=r){const i=t.data.field(r.fieldPath);if(hs(i))for(const r of i.arrayValue.values||[])n=n.add(new Lo(e.indexId,t.key,this.Ln(r),s))}else n=n.add(new Lo(e.indexId,t.key,ea,s));return n}Jn(t,e,n,s,r){q(ta,"Updating index entries for document '%s'",e.key);const i=[];return function(t,e,n,s,r){const i=t.getIterator(),o=e.getIterator();let a=Dn(i),u=Dn(o);for(;a||u;){let t=!1,e=!1;if(a&&u){const s=n(a,u);s<0?e=!0:s>0&&(t=!0)}else null!=a?e=!0:t=!0;t?(s(u),u=Dn(o)):e?(r(a),a=Dn(i)):(a=Dn(i),u=Dn(o))}}(s,r,Fo,s=>{i.push(this.Hn(t,e,n,s))},s=>{i.push(this.Yn(t,e,n,s))}),zt.waitFor(i)}Gn(t){let e=1;return oa(t).ee({index:We,reverse:!0,range:IDBKeyRange.upperBound([this.uid,Number.MAX_SAFE_INTEGER])},(t,n,s)=>{s.done(),e=n.sequenceNumber+1}).next(()=>e)}createRange(t,e,n){n=n.sort((t,e)=>Fo(t,e)).filter((t,e,n)=>!e||0!==Fo(t,n[e-1]));const s=[];s.push(t);for(const i of n){const n=Fo(i,t),r=Fo(i,e);if(0===n)s[0]=t.An();else if(n>0&&r<0)s.push(i),s.push(i.An());else if(r>0)break}s.push(e);const r=[];for(let i=0;i<s.length;i+=2){if(this.Zn(s[i],s[i+1]))return[];const t=s[i].Vn(this.uid,ea,wt.empty()),e=s[i+1].Vn(this.uid,ea,wt.empty());r.push(IDBKeyRange.bound(t,e))}return r}Zn(t,e){return Fo(t,e)>0}getMinOffsetFromCollectionGroup(t,e){return this.getFieldIndexes(t,e).next(aa)}getMinOffset(t,e){return zt.mapArray(this.Mn(e),e=>this.xn(t,e).next(t=>t||K(44426))).next(aa)}}function sa(t){return In(t,je)}function ra(t){return In(t,Ze)}function ia(t){return In(t,Qe)}function oa(t){return In(t,Xe)}function aa(t){$(0!==t.length,28825);let e=t[0].indexState.offset,n=e.largestBatchId;for(let s=1;s<t.length;s++){const r=t[s].indexState.offset;Ut(r,e)<0&&(e=r),n<r.largestBatchId&&(n=r.largestBatchId)}return new Ft(e.readTime,e.documentKey,n)}
/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ua={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0},ca=41943040;class ha{static withCacheSize(t){return new ha(t,ha.DEFAULT_COLLECTION_PERCENTILE,ha.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}constructor(t,e,n){this.cacheSizeCollectionThreshold=t,this.percentileToCollect=e,this.maximumSequenceNumbersToCollect=n}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function la(t,e,n){const s=t.store(ye),r=t.store(Se),i=[],o=IDBKeyRange.only(n.batchId);let a=0;const u=s.ee({range:o},(t,e,n)=>(a++,n.delete()));i.push(u.next(()=>{$(1===a,47070,{batchId:n.batchId})}));const c=[];for(const h of n.mutations){const t=Te(e,h.key.path,n.batchId);i.push(r.delete(t)),c.push(h.key)}return zt.waitFor(i).next(()=>c)}function da(t){if(!t)return 0;let e;if(t.document)e=t.document;else if(t.unknownDocument)e=t.unknownDocument;else{if(!t.noDocument)throw K(14731);e=t.noDocument}return JSON.stringify(e).length}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ha.DEFAULT_COLLECTION_PERCENTILE=10,ha.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,ha.DEFAULT=new ha(ca,ha.DEFAULT_COLLECTION_PERCENTILE,ha.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),ha.DISABLED=new ha(-1,0,0);class fa{constructor(t,e,n,s){this.userId=t,this.serializer=e,this.indexManager=n,this.referenceDelegate=s,this.Xn={}}static wt(t,e,n,s){$(""!==t.uid,64387);const r=t.isAuthenticated()?t.uid:"";return new fa(r,e,n,s)}checkEmpty(t){let e=!0;const n=IDBKeyRange.bound([this.userId,Number.NEGATIVE_INFINITY],[this.userId,Number.POSITIVE_INFINITY]);return ga(t).ee({index:we,range:n},(t,n,s)=>{e=!1,s.done()}).next(()=>e)}addMutationBatch(t,e,n,s){const r=pa(t),i=ga(t);return i.add({}).next(o=>{$("number"==typeof o,49019);const a=new ui(o,e,n,s),u=function(t,e,n){const s=n.baseMutations.map(e=>Hi(t.yt,e)),r=n.mutations.map(e=>Hi(t.yt,e));return{userId:e,batchId:n.batchId,localWriteTimeMs:n.localWriteTime.toMillis(),baseMutations:s,mutations:r}}(this.serializer,this.userId,a),c=[];let h=new Cn((t,e)=>at(t.canonicalString(),e.canonicalString()));for(const t of s){const e=Te(this.userId,t.key.path,o);h=h.add(t.key.path.popLast()),c.push(i.put(u)),c.push(r.put(e,Ee))}return h.forEach(e=>{c.push(this.indexManager.addToCollectionParentIndex(t,e))}),t.addOnCommittedListener(()=>{this.Xn[o]=a.keys()}),zt.waitFor(c).next(()=>a)})}lookupMutationBatch(t,e){return ga(t).get(e).next(t=>t?($(t.userId===this.userId,48,"Unexpected user for mutation batch",{userId:t.userId,batchId:e}),po(this.serializer,t)):null)}er(t,e){return this.Xn[e]?zt.resolve(this.Xn[e]):this.lookupMutationBatch(t,e).next(t=>{if(t){const n=t.keys();return this.Xn[e]=n,n}return null})}getNextMutationBatchAfterBatchId(t,e){const n=e+1,s=IDBKeyRange.lowerBound([this.userId,n]);let r=null;return ga(t).ee({index:we,range:s},(t,e,s)=>{e.userId===this.userId&&($(e.batchId>=n,47524,{tr:n}),r=po(this.serializer,e)),s.done()}).next(()=>r)}getHighestUnacknowledgedBatchId(t){const e=IDBKeyRange.upperBound([this.userId,Number.POSITIVE_INFINITY]);let n=ie;return ga(t).ee({index:we,range:e,reverse:!0},(t,e,s)=>{n=e.batchId,s.done()}).next(()=>n)}getAllMutationBatches(t){const e=IDBKeyRange.bound([this.userId,ie],[this.userId,Number.POSITIVE_INFINITY]);return ga(t).J(we,e).next(t=>t.map(t=>po(this.serializer,t)))}getAllMutationBatchesAffectingDocumentKey(t,e){const n=be(this.userId,e.path),s=IDBKeyRange.lowerBound(n),r=[];return pa(t).ee({range:s},(n,s,i)=>{const[o,a,u]=n,c=de(a);if(o===this.userId&&e.path.isEqual(c))return ga(t).get(u).next(t=>{if(!t)throw K(61480,{nr:n,batchId:u});$(t.userId===this.userId,10503,"Unexpected user for mutation batch",{userId:t.userId,batchId:u}),r.push(po(this.serializer,t))});i.done()}).next(()=>r)}getAllMutationBatchesAffectingDocumentKeys(t,e){let n=new Cn(at);const s=[];return e.forEach(e=>{const r=be(this.userId,e.path),i=IDBKeyRange.lowerBound(r),o=pa(t).ee({range:i},(t,s,r)=>{const[i,o,a]=t,u=de(o);i===this.userId&&e.path.isEqual(u)?n=n.add(a):r.done()});s.push(o)}),zt.waitFor(s).next(()=>this.rr(t,n))}getAllMutationBatchesAffectingQuery(t,e){const n=e.path,s=n.length+1,r=be(this.userId,n),i=IDBKeyRange.lowerBound(r);let o=new Cn(at);return pa(t).ee({range:i},(t,e,r)=>{const[i,a,u]=t,c=de(a);i===this.userId&&n.isPrefixOf(c)?c.length===s&&(o=o.add(u)):r.done()}).next(()=>this.rr(t,o))}rr(t,e){const n=[],s=[];return e.forEach(e=>{s.push(ga(t).get(e).next(t=>{if(null===t)throw K(35274,{batchId:e});$(t.userId===this.userId,9748,"Unexpected user for mutation batch",{userId:t.userId,batchId:e}),n.push(po(this.serializer,t))}))}),zt.waitFor(s).next(()=>n)}removeMutationBatch(t,e){return la(t.le,this.userId,e).next(n=>(t.addOnCommittedListener(()=>{this.ir(e.batchId)}),zt.forEach(n,e=>this.referenceDelegate.markPotentiallyOrphaned(t,e))))}ir(t){delete this.Xn[t]}performConsistencyCheck(t){return this.checkEmpty(t).next(e=>{if(!e)return zt.resolve();const n=IDBKeyRange.lowerBound(function(t){return[t]}(this.userId)),s=[];return pa(t).ee({range:n},(t,e,n)=>{if(t[0]===this.userId){const e=de(t[1]);s.push(e)}else n.done()}).next(()=>{$(0===s.length,56720,{sr:s.map(t=>t.canonicalString())})})})}containsKey(t,e){return ma(t,this.userId,e)}_r(t){return ya(t).get(this.userId).next(t=>t||{userId:this.userId,lastAcknowledgedBatchId:ie,lastStreamToken:""})}}function ma(t,e,n){const s=be(e,n.path),r=s[1],i=IDBKeyRange.lowerBound(s);let o=!1;return pa(t).ee({range:i,X:!0},(t,n,s)=>{const[i,a,u]=t;i===e&&a===r&&(o=!0),s.done()}).next(()=>o)}function ga(t){return In(t,ye)}function pa(t){return In(t,Se)}function ya(t){return In(t,pe)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class va{constructor(t){this.ar=t}next(){return this.ar+=2,this.ar}static ur(){return new va(0)}static cr(){return new va(-1)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wa{constructor(t,e){this.referenceDelegate=t,this.serializer=e}allocateTargetId(t){return this.lr(t).next(e=>{const n=new va(e.highestTargetId);return e.highestTargetId=n.next(),this.hr(t,e).next(()=>e.highestTargetId)})}getLastRemoteSnapshotVersion(t){return this.lr(t).next(t=>kt.fromTimestamp(new Nt(t.lastRemoteSnapshotVersion.seconds,t.lastRemoteSnapshotVersion.nanoseconds)))}getHighestSequenceNumber(t){return this.lr(t).next(t=>t.highestListenSequenceNumber)}setTargetsMetadata(t,e,n){return this.lr(t).next(s=>(s.highestListenSequenceNumber=e,n&&(s.lastRemoteSnapshotVersion=n.toTimestamp()),e>s.highestListenSequenceNumber&&(s.highestListenSequenceNumber=e),this.hr(t,s)))}addTargetData(t,e){return this.Pr(t,e).next(()=>this.lr(t).next(n=>(n.targetCount+=1,this.Tr(e,n),this.hr(t,n))))}updateTargetData(t,e){return this.Pr(t,e)}removeTargetData(t,e){return this.removeMatchingKeysForTargetId(t,e.targetId).next(()=>Ia(t).delete(e.targetId)).next(()=>this.lr(t)).next(e=>($(e.targetCount>0,8065),e.targetCount-=1,this.hr(t,e)))}removeTargets(t,e,n){let s=0;const r=[];return Ia(t).ee((i,o)=>{const a=yo(o);a.sequenceNumber<=e&&null===n.get(a.targetId)&&(s++,r.push(this.removeTargetData(t,a)))}).next(()=>zt.waitFor(r)).next(()=>s)}forEachTarget(t,e){return Ia(t).ee((t,n)=>{const s=yo(n);e(s)})}lr(t){return ba(t).get(qe).next(t=>($(null!==t,2888),t))}hr(t,e){return ba(t).put(qe,e)}Pr(t,e){return Ia(t).put(vo(this.serializer,e))}Tr(t,e){let n=!1;return t.targetId>e.highestTargetId&&(e.highestTargetId=t.targetId,n=!0),t.sequenceNumber>e.highestListenSequenceNumber&&(e.highestListenSequenceNumber=t.sequenceNumber,n=!0),n}getTargetCount(t){return this.lr(t).next(t=>t.targetCount)}getTargetData(t,e){const n=Ws(e),s=IDBKeyRange.bound([n,Number.NEGATIVE_INFINITY],[n,Number.POSITIVE_INFINITY]);let r=null;return Ia(t).ee({range:s,index:Oe},(t,n,s)=>{const i=yo(n);Js(e,i.target)&&(r=i,s.done())}).next(()=>r)}addMatchingKeys(t,e,n){const s=[],r=Ta(t);return e.forEach(e=>{const i=ce(e.path);s.push(r.put({targetId:n,path:i})),s.push(this.referenceDelegate.addReference(t,n,e))}),zt.waitFor(s)}removeMatchingKeys(t,e,n){const s=Ta(t);return zt.forEach(e,e=>{const r=ce(e.path);return zt.waitFor([s.delete([n,r]),this.referenceDelegate.removeReference(t,n,e)])})}removeMatchingKeysForTargetId(t,e){const n=Ta(t),s=IDBKeyRange.bound([e],[e+1],!1,!0);return n.delete(s)}getMatchingKeysForTargetId(t,e){const n=IDBKeyRange.bound([e],[e+1],!1,!0),s=Ta(t);let r=Ar();return s.ee({range:n,X:!0},(t,e,n)=>{const s=de(t[1]),i=new wt(s);r=r.add(i)}).next(()=>r)}containsKey(t,e){const n=ce(e.path),s=IDBKeyRange.bound([n],[ft(n)],!1,!0);let r=0;return Ta(t).ee({index:Fe,X:!0,range:s},([t,e],n,s)=>{0!==t&&(r++,s.done())}).next(()=>r>0)}At(t,e){return Ia(t).get(e).next(t=>t?yo(t):null)}}function Ia(t){return In(t,Me)}function ba(t){return In(t,Be)}function Ta(t){return In(t,Pe)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ea="LruGarbageCollector";function Sa([t,e],[n,s]){const r=at(t,n);return 0===r?at(e,s):r}class _a{constructor(t){this.Ir=t,this.buffer=new Cn(Sa),this.Er=0}dr(){return++this.Er}Ar(t){const e=[t,this.dr()];if(this.buffer.size<this.Ir)this.buffer=this.buffer.add(e);else{const t=this.buffer.last();Sa(e,t)<0&&(this.buffer=this.buffer.delete(t).add(e))}}get maxValue(){return this.buffer.last()[0]}}class xa{constructor(t,e,n){this.garbageCollector=t,this.asyncQueue=e,this.localStore=n,this.Rr=null}start(){-1!==this.garbageCollector.params.cacheSizeCollectionThreshold&&this.Vr(6e4)}stop(){this.Rr&&(this.Rr.cancel(),this.Rr=null)}get started(){return null!==this.Rr}Vr(t){q(Ea,`Garbage collection scheduled in ${t}ms`),this.Rr=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",t,async()=>{this.Rr=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(t){Yt(t)?q(Ea,"Ignoring IndexedDB error during garbage collection: ",t):await jt(t)}await this.Vr(3e5)})}}class Ca{constructor(t,e){this.mr=t,this.params=e}calculateTargetCount(t,e){return this.mr.gr(t).next(t=>Math.floor(e/100*t))}nthSequenceNumber(t,e){if(0===e)return zt.resolve(re.ce);const n=new _a(e);return this.mr.forEachTarget(t,t=>n.Ar(t.sequenceNumber)).next(()=>this.mr.pr(t,t=>n.Ar(t))).next(()=>n.maxValue)}removeTargets(t,e,n){return this.mr.removeTargets(t,e,n)}removeOrphanedDocuments(t,e){return this.mr.removeOrphanedDocuments(t,e)}collect(t,e){return-1===this.params.cacheSizeCollectionThreshold?(q("LruGarbageCollector","Garbage collection skipped; disabled"),zt.resolve(ua)):this.getCacheSize(t).next(n=>n<this.params.cacheSizeCollectionThreshold?(q("LruGarbageCollector",`Garbage collection skipped; Cache size ${n} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),ua):this.yr(t,e))}getCacheSize(t){return this.mr.getCacheSize(t)}yr(t,e){let n,s,r,i,a,u,c;const h=Date.now();return this.calculateTargetCount(t,this.params.percentileToCollect).next(e=>(e>this.params.maximumSequenceNumbersToCollect?(q("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${e}`),s=this.params.maximumSequenceNumbersToCollect):s=e,i=Date.now(),this.nthSequenceNumber(t,s))).next(s=>(n=s,a=Date.now(),this.removeTargets(t,n,e))).next(e=>(r=e,u=Date.now(),this.removeOrphanedDocuments(t,n))).next(t=>(c=Date.now(),U()<=o.DEBUG&&q("LruGarbageCollector",`LRU Garbage Collection\n\tCounted targets in ${i-h}ms\n\tDetermined least recently used ${s} in `+(a-i)+`ms\n\tRemoved ${r} targets in `+(u-a)+`ms\n\tRemoved ${t} documents in `+(c-u)+`ms\nTotal Duration: ${c-h}ms`),zt.resolve({didRun:!0,sequenceNumbersCollected:s,targetsRemoved:r,documentsRemoved:t})))}}function Aa(t,e){return new Ca(t,e)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Da{constructor(t,e){this.db=t,this.garbageCollector=Aa(this,e)}gr(t){const e=this.wr(t);return this.db.getTargetCache().getTargetCount(t).next(t=>e.next(e=>t+e))}wr(t){let e=0;return this.pr(t,t=>{e++}).next(()=>e)}forEachTarget(t,e){return this.db.getTargetCache().forEachTarget(t,e)}pr(t,e){return this.Sr(t,(t,n)=>e(n))}addReference(t,e,n){return Na(t,n)}removeReference(t,e,n){return Na(t,n)}removeTargets(t,e,n){return this.db.getTargetCache().removeTargets(t,e,n)}markPotentiallyOrphaned(t,e){return Na(t,e)}br(t,e){return function(t,e){let n=!1;return ya(t).te(s=>ma(t,s,e).next(t=>(t&&(n=!0),zt.resolve(!t)))).next(()=>n)}(t,e)}removeOrphanedDocuments(t,e){const n=this.db.getRemoteDocumentCache().newChangeBuffer(),s=[];let r=0;return this.Sr(t,(i,o)=>{if(o<=e){const e=this.br(t,i).next(e=>{if(!e)return r++,n.getEntry(t,i).next(()=>(n.removeEntry(i,kt.min()),Ta(t).delete([0,ce(i.path)])))});s.push(e)}}).next(()=>zt.waitFor(s)).next(()=>n.apply(t)).next(()=>r)}removeTarget(t,e){const n=e.withSequenceNumber(t.currentSequenceNumber);return this.db.getTargetCache().updateTargetData(t,n)}updateLimboDocument(t,e){return Na(t,e)}Sr(t,e){const n=Ta(t);let s,r=re.ce;return n.ee({index:Fe},([t,n],{path:i,sequenceNumber:o})=>{0===t?(r!==re.ce&&e(new wt(de(s)),r),r=o,s=i):r=re.ce}).next(()=>{r!==re.ce&&e(new wt(de(s)),r)})}getCacheSize(t){return this.db.getRemoteDocumentCache().getSize(t)}}function Na(t,e){return Ta(t).put((n=e,s=t.currentSequenceNumber,{targetId:0,path:ce(n.path),sequenceNumber:s}));var n,s}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ka{constructor(){this.changes=new yr(t=>t.toString(),(t,e)=>t.isEqual(e)),this.changesApplied=!1}addEntry(t){this.assertNotApplied(),this.changes.set(t.key,t)}removeEntry(t,e){this.assertNotApplied(),this.changes.set(t,Ss.newInvalidDocument(t).setReadTime(e))}getEntry(t,e){this.assertNotApplied();const n=this.changes.get(e);return void 0!==n?zt.resolve(n):this.getFromCache(t,e)}getEntries(t,e){return this.getAllFromCache(t,e)}apply(t){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(t)}assertNotApplied(){}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ra{constructor(t){this.serializer=t}setIndexManager(t){this.indexManager=t}addEntry(t,e,n){return Pa(t).put(n)}removeEntry(t,e,n){return Pa(t).delete(function(t,e){const n=t.path.toArray();return[n.slice(0,n.length-2),n[n.length-2],fo(e),n[n.length-1]]}(e,n))}updateMetadata(t,e){return this.getMetadata(t).next(n=>(n.byteSize+=e,this.Dr(t,n)))}getEntry(t,e){let n=Ss.newInvalidDocument(e);return Pa(t).ee({index:Ce,range:IDBKeyRange.only(La(e))},(t,s)=>{n=this.Cr(e,s)}).next(()=>n)}vr(t,e){let n={size:0,document:Ss.newInvalidDocument(e)};return Pa(t).ee({index:Ce,range:IDBKeyRange.only(La(e))},(t,s)=>{n={document:this.Cr(e,s),size:da(s)}}).next(()=>n)}getEntries(t,e){let n=wr();return this.Fr(t,e,(t,e)=>{const s=this.Cr(t,e);n=n.insert(t,s)}).next(()=>n)}Mr(t,e){let n=wr(),s=new Sn(wt.comparator);return this.Fr(t,e,(t,e)=>{const r=this.Cr(t,e);n=n.insert(t,r),s=s.insert(t,da(e))}).next(()=>({documents:n,Or:s}))}Fr(t,e,n){if(e.isEmpty())return zt.resolve();let s=new Cn(Ua);e.forEach(t=>s=s.add(t));const r=IDBKeyRange.bound(La(s.first()),La(s.last())),i=s.getIterator();let o=i.getNext();return Pa(t).ee({index:Ce,range:r},(t,e,s)=>{const r=wt.fromSegments([...e.prefixPath,e.collectionGroup,e.documentId]);for(;o&&Ua(o,r)<0;)n(o,null),o=i.getNext();o&&o.isEqual(r)&&(n(o,e),o=i.hasNext()?i.getNext():null),o?s.j(La(o)):s.done()}).next(()=>{for(;o;)n(o,null),o=i.hasNext()?i.getNext():null})}getDocumentsMatchingQuery(t,e,n,s,r){const i=e.path,o=[i.popLast().toArray(),i.lastSegment(),fo(n.readTime),n.documentKey.path.isEmpty()?"":n.documentKey.path.lastSegment()],a=[i.popLast().toArray(),i.lastSegment(),[Number.MAX_SAFE_INTEGER,Number.MAX_SAFE_INTEGER],""];return Pa(t).J(IDBKeyRange.bound(o,a,!0)).next(t=>{null==r||r.incrementDocumentReadCount(t.length);let n=wr();for(const r of t){const t=this.Cr(wt.fromSegments(r.prefixPath.concat(r.collectionGroup,r.documentId)),r);t.isFoundDocument()&&(mr(e,t)||s.has(t.key))&&(n=n.insert(t.key,t))}return n})}getAllFromCollectionGroup(t,e,n,s){let r=wr();const i=Fa(e,n),o=Fa(e,Ft.max());return Pa(t).ee({index:De,range:IDBKeyRange.bound(i,o,!0)},(t,e,n)=>{const i=this.Cr(wt.fromSegments(e.prefixPath.concat(e.collectionGroup,e.documentId)),e);r=r.insert(i.key,i),r.size===s&&n.done()}).next(()=>r)}newChangeBuffer(t){return new Oa(this,!!t&&t.trackRemovals)}getSize(t){return this.getMetadata(t).next(t=>t.byteSize)}getMetadata(t){return Va(t).get(Re).next(t=>($(!!t,20021),t))}Dr(t,e){return Va(t).put(Re,e)}Cr(t,e){if(e){const t=ho(this.serializer,e);if(!t.isNoDocument()||!t.version.isEqual(kt.min()))return t}return Ss.newInvalidDocument(t)}}function Ma(t){return new Ra(t)}class Oa extends ka{constructor(t,e){super(),this.Nr=t,this.trackRemovals=e,this.Br=new yr(t=>t.toString(),(t,e)=>t.isEqual(e))}applyChanges(t){const e=[];let n=0,s=new Cn((t,e)=>at(t.canonicalString(),e.canonicalString()));return this.changes.forEach((r,i)=>{const o=this.Br.get(r);if(e.push(this.Nr.removeEntry(t,r,o.readTime)),i.isValidDocument()){const a=lo(this.Nr.serializer,i);s=s.add(r.path.popLast());const u=da(a);n+=u-o.size,e.push(this.Nr.addEntry(t,r,a))}else if(n-=o.size,this.trackRemovals){const n=lo(this.Nr.serializer,i.convertToNoDocument(kt.min()));e.push(this.Nr.addEntry(t,r,n))}}),s.forEach(n=>{e.push(this.Nr.indexManager.addToCollectionParentIndex(t,n))}),e.push(this.Nr.updateMetadata(t,n)),zt.waitFor(e)}getFromCache(t,e){return this.Nr.vr(t,e).next(t=>(this.Br.set(e,{size:t.size,readTime:t.document.readTime}),t.document))}getAllFromCache(t,e){return this.Nr.Mr(t,e).next(({documents:t,Or:e})=>(e.forEach((e,n)=>{this.Br.set(e,{size:n,readTime:t.get(e).readTime})}),t))}}function Va(t){return In(t,ke)}function Pa(t){return In(t,_e)}function La(t){const e=t.path.toArray();return[e.slice(0,e.length-2),e[e.length-2],e[e.length-1]]}function Fa(t,e){const n=e.documentKey.path.toArray();return[t,fo(e.readTime),n.slice(0,n.length-2),n.length>0?n[n.length-1]:""]}function Ua(t,e){const n=t.path.toArray(),s=e.path.toArray();let r=0;for(let i=0;i<n.length-2&&i<s.length-2;++i)if(r=at(n[i],s[i]),r)return r;return r=at(n.length,s.length),r||(r=at(n[n.length-2],s[s.length-2]),r||at(n[n.length-1],s[s.length-1])
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */)}class qa{constructor(t,e){this.overlayedDocument=t,this.mutatedFields=e}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ba{constructor(t,e,n,s){this.remoteDocumentCache=t,this.mutationQueue=e,this.documentOverlayCache=n,this.indexManager=s}getDocument(t,e){let n=null;return this.documentOverlayCache.getOverlay(t,e).next(s=>(n=s,this.remoteDocumentCache.getEntry(t,e))).next(t=>(null!==n&&Jr(n.mutation,t,Nn.empty(),Nt.now()),t))}getDocuments(t,e){return this.remoteDocumentCache.getEntries(t,e).next(e=>this.getLocalViewOfDocuments(t,e,Ar()).next(()=>e))}getLocalViewOfDocuments(t,e,n=Ar()){const s=Er();return this.populateOverlays(t,s,e).next(()=>this.computeViews(t,e,s,n).next(t=>{let e=br();return t.forEach((t,n)=>{e=e.insert(t,n.overlayedDocument)}),e}))}getOverlayedDocuments(t,e){const n=Er();return this.populateOverlays(t,n,e).next(()=>this.computeViews(t,e,n,Ar()))}populateOverlays(t,e,n){const s=[];return n.forEach(t=>{e.has(t)||s.push(t)}),this.documentOverlayCache.getOverlays(t,s).next(t=>{t.forEach((t,n)=>{e.set(t,n)})})}computeViews(t,e,n,s){let r=wr();const i=_r(),o=_r();return e.forEach((t,e)=>{const o=n.get(e.key);s.has(e.key)&&(void 0===o||o.mutation instanceof ni)?r=r.insert(e.key,e):void 0!==o?(i.set(e.key,o.mutation.getFieldMask()),Jr(o.mutation,e,o.mutation.getFieldMask(),Nt.now())):i.set(e.key,Nn.empty())}),this.recalculateAndSaveOverlays(t,r).next(t=>(t.forEach((t,e)=>i.set(t,e)),e.forEach((t,e)=>o.set(t,new qa(e,i.get(t)??null))),o))}recalculateAndSaveOverlays(t,e){const n=_r();let s=new Sn((t,e)=>t-e),r=Ar();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(t,e).next(t=>{for(const r of t)r.keys().forEach(t=>{const i=e.get(t);if(null===i)return;let o=n.get(t)||Nn.empty();o=r.applyToLocalView(i,o),n.set(t,o);const a=(s.get(r.batchId)||Ar()).add(t);s=s.insert(r.batchId,a)})}).next(()=>{const i=[],o=s.getReverseIterator();for(;o.hasNext();){const s=o.getNext(),a=s.key,u=s.value,c=Sr();u.forEach(t=>{if(!r.has(t)){const s=Yr(e.get(t),n.get(t));null!==s&&c.set(t,s),r=r.add(t)}}),i.push(this.documentOverlayCache.saveOverlays(t,a,c))}return zt.waitFor(i)}).next(()=>n)}recalculateAndSaveOverlaysForDocumentKeys(t,e){return this.remoteDocumentCache.getEntries(t,e).next(e=>this.recalculateAndSaveOverlays(t,e))}getDocumentsMatchingQuery(t,e,n,s){return r=e,wt.isDocumentKey(r.path)&&null===r.collectionGroup&&0===r.filters.length?this.getDocumentsMatchingDocumentQuery(t,e.path):or(e)?this.getDocumentsMatchingCollectionGroupQuery(t,e,n,s):this.getDocumentsMatchingCollectionQuery(t,e,n,s);var r}getNextDocuments(t,e,n,s){return this.remoteDocumentCache.getAllFromCollectionGroup(t,e,n,s).next(r=>{const i=s-r.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(t,e,n.largestBatchId,s-r.size):zt.resolve(Er());let o=-1,a=r;return i.next(e=>zt.forEach(e,(e,n)=>(o<n.largestBatchId&&(o=n.largestBatchId),r.get(e)?zt.resolve():this.remoteDocumentCache.getEntry(t,e).next(t=>{a=a.insert(e,t)}))).next(()=>this.populateOverlays(t,e,r)).next(()=>this.computeViews(t,a,e,Ar())).next(t=>({batchId:o,changes:Tr(t)})))})}getDocumentsMatchingDocumentQuery(t,e){return this.getDocument(t,new wt(e)).next(t=>{let e=br();return t.isFoundDocument()&&(e=e.insert(t.key,t)),e})}getDocumentsMatchingCollectionGroupQuery(t,e,n,s){const r=e.collectionGroup;let i=br();return this.indexManager.getCollectionParents(t,r).next(o=>zt.forEach(o,o=>{const a=(u=e,c=o.child(r),new sr(c,null,u.explicitOrderBy.slice(),u.filters.slice(),u.limit,u.limitType,u.startAt,u.endAt));var u,c;return this.getDocumentsMatchingCollectionQuery(t,a,n,s).next(t=>{t.forEach((t,e)=>{i=i.insert(t,e)})})}).next(()=>i))}getDocumentsMatchingCollectionQuery(t,e,n,s){let r;return this.documentOverlayCache.getOverlaysForCollection(t,e.path,n.largestBatchId).next(i=>(r=i,this.remoteDocumentCache.getDocumentsMatchingQuery(t,e,n,r,s))).next(t=>{r.forEach((e,n)=>{const s=n.getKey();null===t.get(s)&&(t=t.insert(s,Ss.newInvalidDocument(s)))});let n=br();return t.forEach((t,s)=>{const i=r.get(t);void 0!==i&&Jr(i.mutation,s,Nn.empty(),Nt.now()),mr(e,s)&&(n=n.insert(t,s))}),n})}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ja{constructor(t){this.serializer=t,this.Lr=new Map,this.kr=new Map}getBundleMetadata(t,e){return zt.resolve(this.Lr.get(e))}saveBundleMetadata(t,e){return this.Lr.set(e.id,{id:(n=e).id,version:n.version,createTime:Li(n.createTime)}),zt.resolve();var n}getNamedQuery(t,e){return zt.resolve(this.kr.get(e))}saveNamedQuery(t,e){return this.kr.set(e.name,{name:(n=e).name,query:wo(n.bundledQuery),readTime:Li(n.readTime)}),zt.resolve();var n}}
/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class za{constructor(){this.overlays=new Sn(wt.comparator),this.qr=new Map}getOverlay(t,e){return zt.resolve(this.overlays.get(e))}getOverlays(t,e){const n=Er();return zt.forEach(e,e=>this.getOverlay(t,e).next(t=>{null!==t&&n.set(e,t)})).next(()=>n)}saveOverlays(t,e,n){return n.forEach((n,s)=>{this.St(t,e,s)}),zt.resolve()}removeOverlaysForBatchId(t,e,n){const s=this.qr.get(n);return void 0!==s&&(s.forEach(t=>this.overlays=this.overlays.remove(t)),this.qr.delete(n)),zt.resolve()}getOverlaysForCollection(t,e,n){const s=Er(),r=e.length+1,i=new wt(e.child("")),o=this.overlays.getIteratorFrom(i);for(;o.hasNext();){const t=o.getNext().value,i=t.getKey();if(!e.isPrefixOf(i.path))break;i.path.length===r&&t.largestBatchId>n&&s.set(t.getKey(),t)}return zt.resolve(s)}getOverlaysForCollectionGroup(t,e,n,s){let r=new Sn((t,e)=>t-e);const i=this.overlays.getIterator();for(;i.hasNext();){const t=i.getNext().value;if(t.getKey().getCollectionGroup()===e&&t.largestBatchId>n){let e=r.get(t.largestBatchId);null===e&&(e=Er(),r=r.insert(t.largestBatchId,e)),e.set(t.getKey(),t)}}const o=Er(),a=r.getIterator();for(;a.hasNext()&&(a.getNext().value.forEach((t,e)=>o.set(t,e)),!(o.size()>=s)););return zt.resolve(o)}St(t,e,n){const s=this.overlays.get(n.key);if(null!==s){const t=this.qr.get(s.largestBatchId).delete(n.key);this.qr.set(s.largestBatchId,t)}this.overlays=this.overlays.insert(n.key,new hi(e,n));let r=this.qr.get(e);void 0===r&&(r=Ar(),this.qr.set(e,r)),this.qr.set(e,r.add(n.key))}}
/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ka{constructor(){this.sessionToken=Rn.EMPTY_BYTE_STRING}getSessionToken(t){return zt.resolve(this.sessionToken)}setSessionToken(t,e){return this.sessionToken=e,zt.resolve()}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ga{constructor(){this.Qr=new Cn($a.$r),this.Ur=new Cn($a.Kr)}isEmpty(){return this.Qr.isEmpty()}addReference(t,e){const n=new $a(t,e);this.Qr=this.Qr.add(n),this.Ur=this.Ur.add(n)}Wr(t,e){t.forEach(t=>this.addReference(t,e))}removeReference(t,e){this.Gr(new $a(t,e))}zr(t,e){t.forEach(t=>this.removeReference(t,e))}jr(t){const e=new wt(new pt([])),n=new $a(e,t),s=new $a(e,t+1),r=[];return this.Ur.forEachInRange([n,s],t=>{this.Gr(t),r.push(t.key)}),r}Jr(){this.Qr.forEach(t=>this.Gr(t))}Gr(t){this.Qr=this.Qr.delete(t),this.Ur=this.Ur.delete(t)}Hr(t){const e=new wt(new pt([])),n=new $a(e,t),s=new $a(e,t+1);let r=Ar();return this.Ur.forEachInRange([n,s],t=>{r=r.add(t.key)}),r}containsKey(t){const e=new $a(t,0),n=this.Qr.firstAfterOrEqual(e);return null!==n&&t.isEqual(n.key)}}class $a{constructor(t,e){this.key=t,this.Yr=e}static $r(t,e){return wt.comparator(t.key,e.key)||at(t.Yr,e.Yr)}static Kr(t,e){return at(t.Yr,e.Yr)||wt.comparator(t.key,e.key)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qa{constructor(t,e){this.indexManager=t,this.referenceDelegate=e,this.mutationQueue=[],this.tr=1,this.Zr=new Cn($a.$r)}checkEmpty(t){return zt.resolve(0===this.mutationQueue.length)}addMutationBatch(t,e,n,s){const r=this.tr;this.tr++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const i=new ui(r,e,n,s);this.mutationQueue.push(i);for(const o of s)this.Zr=this.Zr.add(new $a(o.key,r)),this.indexManager.addToCollectionParentIndex(t,o.key.path.popLast());return zt.resolve(i)}lookupMutationBatch(t,e){return zt.resolve(this.Xr(e))}getNextMutationBatchAfterBatchId(t,e){const n=e+1,s=this.ei(n),r=s<0?0:s;return zt.resolve(this.mutationQueue.length>r?this.mutationQueue[r]:null)}getHighestUnacknowledgedBatchId(){return zt.resolve(0===this.mutationQueue.length?ie:this.tr-1)}getAllMutationBatches(t){return zt.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(t,e){const n=new $a(e,0),s=new $a(e,Number.POSITIVE_INFINITY),r=[];return this.Zr.forEachInRange([n,s],t=>{const e=this.Xr(t.Yr);r.push(e)}),zt.resolve(r)}getAllMutationBatchesAffectingDocumentKeys(t,e){let n=new Cn(at);return e.forEach(t=>{const e=new $a(t,0),s=new $a(t,Number.POSITIVE_INFINITY);this.Zr.forEachInRange([e,s],t=>{n=n.add(t.Yr)})}),zt.resolve(this.ti(n))}getAllMutationBatchesAffectingQuery(t,e){const n=e.path,s=n.length+1;let r=n;wt.isDocumentKey(r)||(r=r.child(""));const i=new $a(new wt(r),0);let o=new Cn(at);return this.Zr.forEachWhile(t=>{const e=t.key.path;return!!n.isPrefixOf(e)&&(e.length===s&&(o=o.add(t.Yr)),!0)},i),zt.resolve(this.ti(o))}ti(t){const e=[];return t.forEach(t=>{const n=this.Xr(t);null!==n&&e.push(n)}),e}removeMutationBatch(t,e){$(0===this.ni(e.batchId,"removed"),55003),this.mutationQueue.shift();let n=this.Zr;return zt.forEach(e.mutations,s=>{const r=new $a(s.key,e.batchId);return n=n.delete(r),this.referenceDelegate.markPotentiallyOrphaned(t,s.key)}).next(()=>{this.Zr=n})}ir(t){}containsKey(t,e){const n=new $a(e,0),s=this.Zr.firstAfterOrEqual(n);return zt.resolve(e.isEqual(s&&s.key))}performConsistencyCheck(t){return this.mutationQueue.length,zt.resolve()}ni(t,e){return this.ei(t)}ei(t){return 0===this.mutationQueue.length?0:t-this.mutationQueue[0].batchId}Xr(t){const e=this.ei(t);return e<0||e>=this.mutationQueue.length?null:this.mutationQueue[e]}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ha{constructor(t){this.ri=t,this.docs=new Sn(wt.comparator),this.size=0}setIndexManager(t){this.indexManager=t}addEntry(t,e){const n=e.key,s=this.docs.get(n),r=s?s.size:0,i=this.ri(e);return this.docs=this.docs.insert(n,{document:e.mutableCopy(),size:i}),this.size+=i-r,this.indexManager.addToCollectionParentIndex(t,n.path.popLast())}removeEntry(t){const e=this.docs.get(t);e&&(this.docs=this.docs.remove(t),this.size-=e.size)}getEntry(t,e){const n=this.docs.get(e);return zt.resolve(n?n.document.mutableCopy():Ss.newInvalidDocument(e))}getEntries(t,e){let n=wr();return e.forEach(t=>{const e=this.docs.get(t);n=n.insert(t,e?e.document.mutableCopy():Ss.newInvalidDocument(t))}),zt.resolve(n)}getDocumentsMatchingQuery(t,e,n,s){let r=wr();const i=e.path,o=new wt(i.child("__id-9223372036854775808__")),a=this.docs.getIteratorFrom(o);for(;a.hasNext();){const{key:t,value:{document:o}}=a.getNext();if(!i.isPrefixOf(t.path))break;t.path.length>i.length+1||Ut(Lt(o),n)<=0||(s.has(o.key)||mr(e,o))&&(r=r.insert(o.key,o.mutableCopy()))}return zt.resolve(r)}getAllFromCollectionGroup(t,e,n,s){K(9500)}ii(t,e){return zt.forEach(this.docs,t=>e(t))}newChangeBuffer(t){return new Xa(this)}getSize(t){return zt.resolve(this.size)}}class Xa extends ka{constructor(t){super(),this.Nr=t}applyChanges(t){const e=[];return this.changes.forEach((n,s)=>{s.isValidDocument()?e.push(this.Nr.addEntry(t,s)):this.Nr.removeEntry(n)}),zt.waitFor(e)}getFromCache(t,e){return this.Nr.getEntry(t,e)}getAllFromCache(t,e){return this.Nr.getEntries(t,e)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ya{constructor(t){this.persistence=t,this.si=new yr(t=>Ws(t),Js),this.lastRemoteSnapshotVersion=kt.min(),this.highestTargetId=0,this.oi=0,this._i=new Ga,this.targetCount=0,this.ai=va.ur()}forEachTarget(t,e){return this.si.forEach((t,n)=>e(n)),zt.resolve()}getLastRemoteSnapshotVersion(t){return zt.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(t){return zt.resolve(this.oi)}allocateTargetId(t){return this.highestTargetId=this.ai.next(),zt.resolve(this.highestTargetId)}setTargetsMetadata(t,e,n){return n&&(this.lastRemoteSnapshotVersion=n),e>this.oi&&(this.oi=e),zt.resolve()}Pr(t){this.si.set(t.target,t);const e=t.targetId;e>this.highestTargetId&&(this.ai=new va(e),this.highestTargetId=e),t.sequenceNumber>this.oi&&(this.oi=t.sequenceNumber)}addTargetData(t,e){return this.Pr(e),this.targetCount+=1,zt.resolve()}updateTargetData(t,e){return this.Pr(e),zt.resolve()}removeTargetData(t,e){return this.si.delete(e.target),this._i.jr(e.targetId),this.targetCount-=1,zt.resolve()}removeTargets(t,e,n){let s=0;const r=[];return this.si.forEach((i,o)=>{o.sequenceNumber<=e&&null===n.get(o.targetId)&&(this.si.delete(i),r.push(this.removeMatchingKeysForTargetId(t,o.targetId)),s++)}),zt.waitFor(r).next(()=>s)}getTargetCount(t){return zt.resolve(this.targetCount)}getTargetData(t,e){const n=this.si.get(e)||null;return zt.resolve(n)}addMatchingKeys(t,e,n){return this._i.Wr(e,n),zt.resolve()}removeMatchingKeys(t,e,n){this._i.zr(e,n);const s=this.persistence.referenceDelegate,r=[];return s&&e.forEach(e=>{r.push(s.markPotentiallyOrphaned(t,e))}),zt.waitFor(r)}removeMatchingKeysForTargetId(t,e){return this._i.jr(e),zt.resolve()}getMatchingKeysForTargetId(t,e){const n=this._i.Hr(e);return zt.resolve(n)}containsKey(t,e){return zt.resolve(this._i.containsKey(e))}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wa{constructor(t,e){this.ui={},this.overlays={},this.ci=new re(0),this.li=!1,this.li=!0,this.hi=new Ka,this.referenceDelegate=t(this),this.Pi=new Ya(this),this.indexManager=new Jo,this.remoteDocumentCache=new Ha(t=>this.referenceDelegate.Ti(t)),this.serializer=new co(e),this.Ii=new ja(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.li=!1,Promise.resolve()}get started(){return this.li}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(t){return this.indexManager}getDocumentOverlayCache(t){let e=this.overlays[t.toKey()];return e||(e=new za,this.overlays[t.toKey()]=e),e}getMutationQueue(t,e){let n=this.ui[t.toKey()];return n||(n=new Qa(e,this.referenceDelegate),this.ui[t.toKey()]=n),n}getGlobalsCache(){return this.hi}getTargetCache(){return this.Pi}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.Ii}runTransaction(t,e,n){q("MemoryPersistence","Starting transaction:",t);const s=new Ja(this.ci.next());return this.referenceDelegate.Ei(),n(s).next(t=>this.referenceDelegate.di(s).next(()=>t)).toPromise().then(t=>(s.raiseOnCommittedEvent(),t))}Ai(t,e){return zt.or(Object.values(this.ui).map(n=>()=>n.containsKey(t,e)))}}class Ja extends Bt{constructor(t){super(),this.currentSequenceNumber=t}}class Za{constructor(t){this.persistence=t,this.Ri=new Ga,this.Vi=null}static mi(t){return new Za(t)}get fi(){if(this.Vi)return this.Vi;throw K(60996)}addReference(t,e,n){return this.Ri.addReference(n,e),this.fi.delete(n.toString()),zt.resolve()}removeReference(t,e,n){return this.Ri.removeReference(n,e),this.fi.add(n.toString()),zt.resolve()}markPotentiallyOrphaned(t,e){return this.fi.add(e.toString()),zt.resolve()}removeTarget(t,e){this.Ri.jr(e.targetId).forEach(t=>this.fi.add(t.toString()));const n=this.persistence.getTargetCache();return n.getMatchingKeysForTargetId(t,e.targetId).next(t=>{t.forEach(t=>this.fi.add(t.toString()))}).next(()=>n.removeTargetData(t,e))}Ei(){this.Vi=new Set}di(t){const e=this.persistence.getRemoteDocumentCache().newChangeBuffer();return zt.forEach(this.fi,n=>{const s=wt.fromPath(n);return this.gi(t,s).next(t=>{t||e.removeEntry(s,kt.min())})}).next(()=>(this.Vi=null,e.apply(t)))}updateLimboDocument(t,e){return this.gi(t,e).next(t=>{t?this.fi.delete(e.toString()):this.fi.add(e.toString())})}Ti(t){return 0}gi(t,e){return zt.or([()=>zt.resolve(this.Ri.containsKey(e)),()=>this.persistence.getTargetCache().containsKey(t,e),()=>this.persistence.Ai(t,e)])}}class tu{constructor(t,e){this.persistence=t,this.pi=new yr(t=>ce(t.path),(t,e)=>t.isEqual(e)),this.garbageCollector=Aa(this,e)}static mi(t,e){return new tu(t,e)}Ei(){}di(t){return zt.resolve()}forEachTarget(t,e){return this.persistence.getTargetCache().forEachTarget(t,e)}gr(t){const e=this.wr(t);return this.persistence.getTargetCache().getTargetCount(t).next(t=>e.next(e=>t+e))}wr(t){let e=0;return this.pr(t,t=>{e++}).next(()=>e)}pr(t,e){return zt.forEach(this.pi,(n,s)=>this.br(t,n,s).next(t=>t?zt.resolve():e(s)))}removeTargets(t,e,n){return this.persistence.getTargetCache().removeTargets(t,e,n)}removeOrphanedDocuments(t,e){let n=0;const s=this.persistence.getRemoteDocumentCache(),r=s.newChangeBuffer();return s.ii(t,s=>this.br(t,s,e).next(t=>{t||(n++,r.removeEntry(s,kt.min()))})).next(()=>r.apply(t)).next(()=>n)}markPotentiallyOrphaned(t,e){return this.pi.set(e,t.currentSequenceNumber),zt.resolve()}removeTarget(t,e){const n=e.withSequenceNumber(t.currentSequenceNumber);return this.persistence.getTargetCache().updateTargetData(t,n)}addReference(t,e,n){return this.pi.set(n,t.currentSequenceNumber),zt.resolve()}removeReference(t,e,n){return this.pi.set(n,t.currentSequenceNumber),zt.resolve()}updateLimboDocument(t,e){return this.pi.set(e,t.currentSequenceNumber),zt.resolve()}Ti(t){let e=t.key.toString().length;return t.isFoundDocument()&&(e+=as(t.data.value)),e}br(t,e,n){return zt.or([()=>this.persistence.Ai(t,e),()=>this.persistence.getTargetCache().containsKey(t,e),()=>{const t=this.pi.get(e);return zt.resolve(void 0!==t&&t>n)}])}getCacheSize(t){return this.persistence.getRemoteDocumentCache().getSize(t)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class eu{constructor(t){this.serializer=t}k(t,e,n,s){const r=new Gt("createOrUpgrade",e);n<1&&s>=1&&(t.createObjectStore(me),function(t){t.createObjectStore(pe,{keyPath:"userId"});t.createObjectStore(ye,{keyPath:ve,autoIncrement:!0}).createIndex(we,Ie,{unique:!0}),t.createObjectStore(Se)}(t),nu(t),function(t){t.createObjectStore(fe)}(t));let i=zt.resolve();return n<3&&s>=3&&(0!==n&&(function(t){t.deleteObjectStore(Pe),t.deleteObjectStore(Me),t.deleteObjectStore(Be)}(t),nu(t)),i=i.next(()=>function(t){const e=t.store(Be),n={highestTargetId:0,highestListenSequenceNumber:0,lastRemoteSnapshotVersion:kt.min().toTimestamp(),targetCount:0};return e.put(qe,n)}(r))),n<4&&s>=4&&(0!==n&&(i=i.next(()=>function(t,e){return e.store(ye).J().next(n=>{t.deleteObjectStore(ye),t.createObjectStore(ye,{keyPath:ve,autoIncrement:!0}).createIndex(we,Ie,{unique:!0});const s=e.store(ye),r=n.map(t=>s.put(t));return zt.waitFor(r)})}(t,r))),i=i.next(()=>{!function(t){t.createObjectStore(Ke,{keyPath:"clientId"})}(t)})),n<5&&s>=5&&(i=i.next(()=>this.yi(r))),n<6&&s>=6&&(i=i.next(()=>(function(t){t.createObjectStore(ke)}(t),this.wi(r)))),n<7&&s>=7&&(i=i.next(()=>this.Si(r))),n<8&&s>=8&&(i=i.next(()=>this.bi(t,r))),n<9&&s>=9&&(i=i.next(()=>{!function(t){t.objectStoreNames.contains("remoteDocumentChanges")&&t.deleteObjectStore("remoteDocumentChanges")}(t)})),n<10&&s>=10&&(i=i.next(()=>this.Di(r))),n<11&&s>=11&&(i=i.next(()=>{!function(t){t.createObjectStore(Ge,{keyPath:"bundleId"})}(t),function(t){t.createObjectStore($e,{keyPath:"name"})}(t)})),n<12&&s>=12&&(i=i.next(()=>{!function(t){const e=t.createObjectStore(sn,{keyPath:rn});e.createIndex(on,an,{unique:!1}),e.createIndex(un,cn,{unique:!1})}(t)})),n<13&&s>=13&&(i=i.next(()=>function(t){const e=t.createObjectStore(_e,{keyPath:xe});e.createIndex(Ce,Ae),e.createIndex(De,Ne)}(t)).next(()=>this.Ci(t,r)).next(()=>t.deleteObjectStore(fe))),n<14&&s>=14&&(i=i.next(()=>this.Fi(t,r))),n<15&&s>=15&&(i=i.next(()=>function(t){t.createObjectStore(Qe,{keyPath:"indexId",autoIncrement:!0}).createIndex(He,"collectionGroup",{unique:!1});t.createObjectStore(Xe,{keyPath:Ye}).createIndex(We,Je,{unique:!1});t.createObjectStore(Ze,{keyPath:tn}).createIndex(en,nn,{unique:!1})}(t))),n<16&&s>=16&&(i=i.next(()=>{e.objectStore(Xe).clear()}).next(()=>{e.objectStore(Ze).clear()})),n<17&&s>=17&&(i=i.next(()=>{!function(t){t.createObjectStore(hn,{keyPath:"name"})}(t)})),n<18&&s>=18&&b()&&(i=i.next(()=>{e.objectStore(Xe).clear()}).next(()=>{e.objectStore(Ze).clear()})),i}wi(t){let e=0;return t.store(fe).ee((t,n)=>{e+=da(n)}).next(()=>{const n={byteSize:e};return t.store(ke).put(Re,n)})}yi(t){const e=t.store(pe),n=t.store(ye);return e.J().next(e=>zt.forEach(e,e=>{const s=IDBKeyRange.bound([e.userId,ie],[e.userId,e.lastAcknowledgedBatchId]);return n.J(we,s).next(n=>zt.forEach(n,n=>{$(n.userId===e.userId,18650,"Cannot process batch from unexpected user",{batchId:n.batchId});const s=po(this.serializer,n);return la(t,e.userId,s).next(()=>{})}))}))}Si(t){const e=t.store(Pe),n=t.store(fe);return t.store(Be).get(qe).next(t=>{const s=[];return n.ee((n,r)=>{const i=new pt(n),o=[0,ce(i)];s.push(e.get(o).next(n=>{return n?zt.resolve():(s=i,e.put({targetId:0,path:ce(s),sequenceNumber:t.highestListenSequenceNumber}));var s}))}).next(()=>zt.waitFor(s))})}bi(t,e){t.createObjectStore(je,{keyPath:ze});const n=e.store(je),s=new Zo,r=t=>{if(s.add(t)){const e=t.lastSegment(),s=t.popLast();return n.put({collectionId:e,parent:ce(s)})}};return e.store(fe).ee({X:!0},(t,e)=>{const n=new pt(t);return r(n.popLast())}).next(()=>e.store(Se).ee({X:!0},([t,e,n],s)=>{const i=de(e);return r(i.popLast())}))}Di(t){const e=t.store(Me);return e.ee((t,n)=>{const s=yo(n),r=vo(this.serializer,s);return e.put(r)})}Ci(t,e){const n=e.store(fe),s=[];return n.ee((t,n)=>{const r=e.store(_e),i=(a=n,a.document?new wt(pt.fromString(a.document.name).popFirst(5)):a.noDocument?wt.fromSegments(a.noDocument.path):a.unknownDocument?wt.fromSegments(a.unknownDocument.path):K(36783)).path.toArray(),o={prefixPath:i.slice(0,i.length-2),collectionGroup:i[i.length-2],documentId:i[i.length-1],readTime:n.readTime||[0,0],unknownDocument:n.unknownDocument,noDocument:n.noDocument,document:n.document,hasCommittedMutations:!!n.hasCommittedMutations};var a;s.push(r.put(o))}).next(()=>zt.waitFor(s))}Fi(t,e){const n=e.store(ye),s=Ma(this.serializer),r=new Wa(Za.mi,this.serializer.yt);return n.J().next(t=>{const n=new Map;return t.forEach(t=>{let e=n.get(t.userId)??Ar();po(this.serializer,t).keys().forEach(t=>e=e.add(t)),n.set(t.userId,e)}),zt.forEach(n,(t,n)=>{const i=new P(n),o=xo.wt(this.serializer,i),a=r.getIndexManager(i),u=fa.wt(i,this.serializer,a,r.referenceDelegate);return new Ba(s,u,o,a).recalculateAndSaveOverlaysForDocumentKeys(new wn(e,re.ce),t).next()})})}}function nu(t){t.createObjectStore(Pe,{keyPath:Le}).createIndex(Fe,Ue,{unique:!0}),t.createObjectStore(Me,{keyPath:"targetId"}).createIndex(Oe,Ve,{unique:!0}),t.createObjectStore(Be)}const su="IndexedDbPersistence",ru=18e5,iu=5e3,ou="Failed to obtain exclusive access to the persistence layer. To allow shared access, multi-tab synchronization has to be enabled in all tabs. If you are using `experimentalForceOwningTab:true`, make sure that only one tab has persistence enabled at any given time.";class au{constructor(t,e,n,s,r,i,o,a,u,c,h=18){if(this.allowTabSynchronization=t,this.persistenceKey=e,this.clientId=n,this.Mi=r,this.window=i,this.document=o,this.xi=u,this.Oi=c,this.Ni=h,this.ci=null,this.li=!1,this.isPrimary=!1,this.networkEnabled=!0,this.Bi=null,this.inForeground=!1,this.Li=null,this.ki=null,this.qi=Number.NEGATIVE_INFINITY,this.Qi=t=>Promise.resolve(),!au.v())throw new X(H.UNIMPLEMENTED,"This platform is either missing IndexedDB or is known to have an incomplete implementation. Offline persistence has been disabled.");this.referenceDelegate=new Da(this,s),this.$i=e+"main",this.serializer=new co(a),this.Ui=new $t(this.$i,this.Ni,new eu(this.serializer)),this.hi=new Ao,this.Pi=new wa(this.referenceDelegate,this.serializer),this.remoteDocumentCache=Ma(this.serializer),this.Ii=new Eo,this.window&&this.window.localStorage?this.Ki=this.window.localStorage:(this.Ki=null,!1===c&&B(su,"LocalStorage is unavailable. As a result, persistence may not work reliably. In particular enablePersistence() could fail immediately after refreshing the page."))}start(){return this.Wi().then(()=>{if(!this.isPrimary&&!this.allowTabSynchronization)throw new X(H.FAILED_PRECONDITION,ou);return this.Gi(),this.zi(),this.ji(),this.runTransaction("getHighestListenSequenceNumber","readonly",t=>this.Pi.getHighestSequenceNumber(t))}).then(t=>{this.ci=new re(t,this.xi)}).then(()=>{this.li=!0}).catch(t=>(this.Ui&&this.Ui.close(),Promise.reject(t)))}Ji(t){return this.Qi=async e=>{if(this.started)return t(e)},t(this.isPrimary)}setDatabaseDeletedListener(t){this.Ui.$(async e=>{null===e.newVersion&&await t()})}setNetworkEnabled(t){this.networkEnabled!==t&&(this.networkEnabled=t,this.Mi.enqueueAndForget(async()=>{this.started&&await this.Wi()}))}Wi(){return this.runTransaction("updateClientMetadataAndTryBecomePrimary","readwrite",t=>cu(t).put({clientId:this.clientId,updateTimeMs:Date.now(),networkEnabled:this.networkEnabled,inForeground:this.inForeground}).next(()=>{if(this.isPrimary)return this.Hi(t).next(t=>{t||(this.isPrimary=!1,this.Mi.enqueueRetryable(()=>this.Qi(!1)))})}).next(()=>this.Yi(t)).next(e=>this.isPrimary&&!e?this.Zi(t).next(()=>!1):!!e&&this.Xi(t).next(()=>!0))).catch(t=>{if(Yt(t))return q(su,"Failed to extend owner lease: ",t),this.isPrimary;if(!this.allowTabSynchronization)throw t;return q(su,"Releasing owner lease after error during lease refresh",t),!1}).then(t=>{this.isPrimary!==t&&this.Mi.enqueueRetryable(()=>this.Qi(t)),this.isPrimary=t})}Hi(t){return uu(t).get(ge).next(t=>zt.resolve(this.es(t)))}ts(t){return cu(t).delete(this.clientId)}async ns(){if(this.isPrimary&&!this.rs(this.qi,ru)){this.qi=Date.now();const t=await this.runTransaction("maybeGarbageCollectMultiClientState","readwrite-primary",t=>{const e=In(t,Ke);return e.J().next(t=>{const n=this.ss(t,ru),s=t.filter(t=>-1===n.indexOf(t));return zt.forEach(s,t=>e.delete(t.clientId)).next(()=>s)})}).catch(()=>[]);if(this.Ki)for(const e of t)this.Ki.removeItem(this._s(e.clientId))}}ji(){this.ki=this.Mi.enqueueAfterDelay("client_metadata_refresh",4e3,()=>this.Wi().then(()=>this.ns()).then(()=>this.ji()))}es(t){return!!t&&t.ownerId===this.clientId}Yi(t){return this.Oi?zt.resolve(!0):uu(t).get(ge).next(e=>{if(null!==e&&this.rs(e.leaseTimestampMs,iu)&&!this.us(e.ownerId)){if(this.es(e)&&this.networkEnabled)return!0;if(!this.es(e)){if(!e.allowTabSynchronization)throw new X(H.FAILED_PRECONDITION,ou);return!1}}return!(!this.networkEnabled||!this.inForeground)||cu(t).J().next(t=>void 0===this.ss(t,iu).find(t=>{if(this.clientId!==t.clientId){const e=!this.networkEnabled&&t.networkEnabled,n=!this.inForeground&&t.inForeground,s=this.networkEnabled===t.networkEnabled;if(e||n&&s)return!0}return!1}))}).next(t=>(this.isPrimary!==t&&q(su,`Client ${t?"is":"is not"} eligible for a primary lease.`),t))}async shutdown(){this.li=!1,this.cs(),this.ki&&(this.ki.cancel(),this.ki=null),this.ls(),this.hs(),await this.Ui.runTransaction("shutdown","readwrite",[me,Ke],t=>{const e=new wn(t,re.ce);return this.Zi(e).next(()=>this.ts(e))}),this.Ui.close(),this.Ps()}ss(t,e){return t.filter(t=>this.rs(t.updateTimeMs,e)&&!this.us(t.clientId))}Ts(){return this.runTransaction("getActiveClients","readonly",t=>cu(t).J().next(t=>this.ss(t,ru).map(t=>t.clientId)))}get started(){return this.li}getGlobalsCache(){return this.hi}getMutationQueue(t,e){return fa.wt(t,this.serializer,e,this.referenceDelegate)}getTargetCache(){return this.Pi}getRemoteDocumentCache(){return this.remoteDocumentCache}getIndexManager(t){return new na(t,this.serializer.yt.databaseId)}getDocumentOverlayCache(t){return xo.wt(this.serializer,t)}getBundleCache(){return this.Ii}runTransaction(t,e,n){q(su,"Starting transaction:",t);const s="readonly"===e?"readonly":"readwrite",r=18===(i=this.Ni)?vn:17===i?yn:16===i?pn:15===i?gn:14===i?mn:13===i?fn:12===i?dn:11===i?ln:void K(60245);var i;let o;return this.Ui.runTransaction(t,s,r,s=>(o=new wn(s,this.ci?this.ci.next():re.ce),"readwrite-primary"===e?this.Hi(o).next(t=>!!t||this.Yi(o)).next(e=>{if(!e)throw B(`Failed to obtain primary lease for action '${t}'.`),this.isPrimary=!1,this.Mi.enqueueRetryable(()=>this.Qi(!1)),new X(H.FAILED_PRECONDITION,qt);return n(o)}).next(t=>this.Xi(o).next(()=>t)):this.Is(o).next(()=>n(o)))).then(t=>(o.raiseOnCommittedEvent(),t))}Is(t){return uu(t).get(ge).next(t=>{if(null!==t&&this.rs(t.leaseTimestampMs,iu)&&!this.us(t.ownerId)&&!this.es(t)&&!(this.Oi||this.allowTabSynchronization&&t.allowTabSynchronization))throw new X(H.FAILED_PRECONDITION,ou)})}Xi(t){const e={ownerId:this.clientId,allowTabSynchronization:this.allowTabSynchronization,leaseTimestampMs:Date.now()};return uu(t).put(ge,e)}static v(){return $t.v()}Zi(t){const e=uu(t);return e.get(ge).next(t=>this.es(t)?(q(su,"Releasing primary lease."),e.delete(ge)):zt.resolve())}rs(t,e){const n=Date.now();return!(t<n-e||t>n&&(B(`Detected an update time that is in the future: ${t} > ${n}`),1))}Gi(){null!==this.document&&"function"==typeof this.document.addEventListener&&(this.Li=()=>{this.Mi.enqueueAndForget(()=>(this.inForeground="visible"===this.document.visibilityState,this.Wi()))},this.document.addEventListener("visibilitychange",this.Li),this.inForeground="visible"===this.document.visibilityState)}ls(){this.Li&&(this.document.removeEventListener("visibilitychange",this.Li),this.Li=null)}zi(){var t;"function"==typeof(null==(t=this.window)?void 0:t.addEventListener)&&(this.Bi=()=>{this.cs();const t=/(?:Version|Mobile)\/1[456]/;p()&&(navigator.appVersion.match(t)||navigator.userAgent.match(t))&&this.Mi.enterRestrictedMode(!0),this.Mi.enqueueAndForget(()=>this.shutdown())},this.window.addEventListener("pagehide",this.Bi))}hs(){this.Bi&&(this.window.removeEventListener("pagehide",this.Bi),this.Bi=null)}us(t){var e;try{const n=null!==(null==(e=this.Ki)?void 0:e.getItem(this._s(t)));return q(su,`Client '${t}' ${n?"is":"is not"} zombied in LocalStorage`),n}catch(n){return B(su,"Failed to get zombied client id.",n),!1}}cs(){if(this.Ki)try{this.Ki.setItem(this._s(this.clientId),String(Date.now()))}catch(t){B("Failed to set zombie client id.",t)}}Ps(){if(this.Ki)try{this.Ki.removeItem(this._s(this.clientId))}catch(t){}}_s(t){return`firestore_zombie_${this.persistenceKey}_${t}`}}function uu(t){return In(t,me)}function cu(t){return In(t,Ke)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hu{constructor(t,e,n,s){this.targetId=t,this.fromCache=e,this.Es=n,this.ds=s}static As(t,e){let n=Ar(),s=Ar();for(const r of e.docChanges)switch(r.type){case 0:n=n.add(r.doc.key);break;case 1:s=s.add(r.doc.key)}return new hu(t,e.fromCache,n,s)}}
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lu{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(t){this._documentReadCount+=t}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class du{constructor(){this.Rs=!1,this.Vs=!1,this.fs=100,this.gs=p()?8:Qt(y())>0?6:4}initialize(t,e){this.ps=t,this.indexManager=e,this.Rs=!0}getDocumentsMatchingQuery(t,e,n,s){const r={result:null};return this.ys(t,e).next(t=>{r.result=t}).next(()=>{if(!r.result)return this.ws(t,e,s,n).next(t=>{r.result=t})}).next(()=>{if(r.result)return;const n=new lu;return this.Ss(t,e,n).next(s=>{if(r.result=s,this.Vs)return this.bs(t,e,n,s.size)})}).next(()=>r.result)}bs(t,e,n,s){return n.documentReadCount<this.fs?(U()<=o.DEBUG&&q("QueryEngine","SDK will not create cache indexes for query:",fr(e),"since it only creates cache indexes for collection contains","more than or equal to",this.fs,"documents"),zt.resolve()):(U()<=o.DEBUG&&q("QueryEngine","Query:",fr(e),"scans",n.documentReadCount,"local documents and returns",s,"documents as results."),n.documentReadCount>this.gs*s?(U()<=o.DEBUG&&q("QueryEngine","The SDK decides to create cache indexes for query:",fr(e),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(t,ur(e))):zt.resolve())}ys(t,e){if(ir(e))return zt.resolve(null);let n=ur(e);return this.indexManager.getIndexType(t,n).next(s=>0===s?null:(null!==e.limit&&1===s&&(e=hr(e,null,"F"),n=ur(e)),this.indexManager.getDocumentsMatchingTarget(t,n).next(s=>{const r=Ar(...s);return this.ps.getDocuments(t,r).next(s=>this.indexManager.getMinOffset(t,n).next(n=>{const i=this.Ds(e,s);return this.Cs(e,i,r,n.readTime)?this.ys(t,hr(e,null,"F")):this.vs(t,i,e,n)}))})))}ws(t,e,n,s){return ir(e)||s.isEqual(kt.min())?zt.resolve(null):this.ps.getDocuments(t,n).next(r=>{const i=this.Ds(e,r);return this.Cs(e,i,n,s)?zt.resolve(null):(U()<=o.DEBUG&&q("QueryEngine","Re-using previous result from %s to execute query: %s",s.toString(),fr(e)),this.vs(t,i,e,function(t,e){const n=t.toTimestamp().seconds,s=t.toTimestamp().nanoseconds+1,r=kt.fromTimestamp(1e9===s?new Nt(n+1,0):new Nt(n,s));return new Ft(r,wt.empty(),e)}(s,-1)).next(t=>t))})}Ds(t,e){let n=new Cn(gr(t));return e.forEach((e,s)=>{mr(t,s)&&(n=n.add(s))}),n}Cs(t,e,n,s){if(null===t.limit)return!1;if(n.size!==e.size)return!0;const r="F"===t.limitType?e.last():e.first();return!!r&&(r.hasPendingWrites||r.version.compareTo(s)>0)}Ss(t,e,n){return U()<=o.DEBUG&&q("QueryEngine","Using full collection scan to execute query:",fr(e)),this.ps.getDocumentsMatchingQuery(t,e,Ft.min(),n)}vs(t,e,n,s){return this.ps.getDocumentsMatchingQuery(t,n,s).next(t=>(e.forEach(e=>{t=t.insert(e.key,e)}),t))}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fu="LocalStore";class mu{constructor(t,e,n,s){this.persistence=t,this.Fs=e,this.serializer=s,this.Ms=new Sn(at),this.xs=new yr(t=>Ws(t),Js),this.Os=new Map,this.Ns=t.getRemoteDocumentCache(),this.Pi=t.getTargetCache(),this.Ii=t.getBundleCache(),this.Bs(n)}Bs(t){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(t),this.indexManager=this.persistence.getIndexManager(t),this.mutationQueue=this.persistence.getMutationQueue(t,this.indexManager),this.localDocuments=new Ba(this.Ns,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.Ns.setIndexManager(this.indexManager),this.Fs.initialize(this.localDocuments,this.indexManager)}collectGarbage(t){return this.persistence.runTransaction("Collect garbage","readwrite-primary",e=>t.collect(e,this.Ms))}}function gu(t,e,n,s){return new mu(t,e,n,s)}async function pu(t,e){const n=Q(t);return await n.persistence.runTransaction("Handle user change","readonly",t=>{let s;return n.mutationQueue.getAllMutationBatches(t).next(r=>(s=r,n.Bs(e),n.mutationQueue.getAllMutationBatches(t))).next(e=>{const r=[],i=[];let o=Ar();for(const t of s){r.push(t.batchId);for(const e of t.mutations)o=o.add(e.key)}for(const t of e){i.push(t.batchId);for(const e of t.mutations)o=o.add(e.key)}return n.localDocuments.getDocuments(t,o).next(t=>({Ls:t,removedBatchIds:r,addedBatchIds:i}))})})}function yu(t){const e=Q(t);return e.persistence.runTransaction("Get last remote snapshot version","readonly",t=>e.Pi.getLastRemoteSnapshotVersion(t))}function vu(t,e){const n=Q(t),s=e.snapshotVersion;let r=n.Ms;return n.persistence.runTransaction("Apply remote event","readwrite-primary",t=>{const i=n.Ns.newChangeBuffer({trackRemovals:!0});r=n.Ms;const o=[];e.targetChanges.forEach((i,a)=>{const u=r.get(a);if(!u)return;o.push(n.Pi.removeMatchingKeys(t,i.removedDocuments,a).next(()=>n.Pi.addMatchingKeys(t,i.addedDocuments,a)));let c=u.withSequenceNumber(t.currentSequenceNumber);null!==e.targetMismatches.get(a)?c=c.withResumeToken(Rn.EMPTY_BYTE_STRING,kt.min()).withLastLimboFreeSnapshotVersion(kt.min()):i.resumeToken.approximateByteSize()>0&&(c=c.withResumeToken(i.resumeToken,s)),r=r.insert(a,c),function(t,e,n){if(0===t.resumeToken.approximateByteSize())return!0;if(e.snapshotVersion.toMicroseconds()-t.snapshotVersion.toMicroseconds()>=3e8)return!0;return n.addedDocuments.size+n.modifiedDocuments.size+n.removedDocuments.size>0}(u,c,i)&&o.push(n.Pi.updateTargetData(t,c))});let a=wr(),u=Ar();if(e.documentUpdates.forEach(s=>{e.resolvedLimboDocuments.has(s)&&o.push(n.persistence.referenceDelegate.updateLimboDocument(t,s))}),o.push(function(t,e,n){let s=Ar(),r=Ar();return n.forEach(t=>s=s.add(t)),e.getEntries(t,s).next(t=>{let s=wr();return n.forEach((n,i)=>{const o=t.get(n);i.isFoundDocument()!==o.isFoundDocument()&&(r=r.add(n)),i.isNoDocument()&&i.version.isEqual(kt.min())?(e.removeEntry(n,i.readTime),s=s.insert(n,i)):!o.isValidDocument()||i.version.compareTo(o.version)>0||0===i.version.compareTo(o.version)&&o.hasPendingWrites?(e.addEntry(i),s=s.insert(n,i)):q(fu,"Ignoring outdated watch update for ",n,". Current version:",o.version," Watch version:",i.version)}),{ks:s,qs:r}})}(t,i,e.documentUpdates).next(t=>{a=t.ks,u=t.qs})),!s.isEqual(kt.min())){const e=n.Pi.getLastRemoteSnapshotVersion(t).next(e=>n.Pi.setTargetsMetadata(t,t.currentSequenceNumber,s));o.push(e)}return zt.waitFor(o).next(()=>i.apply(t)).next(()=>n.localDocuments.getLocalViewOfDocuments(t,a,u)).next(()=>a)}).then(t=>(n.Ms=r,t))}function wu(t,e){const n=Q(t);return n.persistence.runTransaction("Get next mutation batch","readonly",t=>(void 0===e&&(e=ie),n.mutationQueue.getNextMutationBatchAfterBatchId(t,e)))}async function Iu(t,e,n){const s=Q(t),r=s.Ms.get(e),i=n?"readwrite":"readwrite-primary";try{n||await s.persistence.runTransaction("Release target",i,t=>s.persistence.referenceDelegate.removeTarget(t,r))}catch(o){if(!Yt(o))throw o;q(fu,`Failed to update sequence numbers for target ${e}: ${o}`)}s.Ms=s.Ms.remove(e),s.xs.delete(r.target)}function bu(t,e,n){const s=Q(t);let r=kt.min(),i=Ar();return s.persistence.runTransaction("Execute query","readwrite",t=>function(t,e,n){const s=Q(t),r=s.xs.get(n);return void 0!==r?zt.resolve(s.Ms.get(r)):s.Pi.getTargetData(e,n)}(s,t,ur(e)).next(e=>{if(e)return r=e.lastLimboFreeSnapshotVersion,s.Pi.getMatchingKeysForTargetId(t,e.targetId).next(t=>{i=t})}).next(()=>s.Fs.getDocumentsMatchingQuery(t,e,n?r:kt.min(),n?i:Ar())).next(t=>(function(t,e,n){let s=t.Os.get(e)||kt.min();n.forEach((t,e)=>{e.readTime.compareTo(s)>0&&(s=e.readTime)}),t.Os.set(e,s)}(s,function(t){return t.collectionGroup||(t.path.length%2==1?t.path.lastSegment():t.path.get(t.path.length-2))}(e),t),{documents:t,Qs:i})))}class Tu{constructor(){this.activeTargetIds=Dr}zs(t){this.activeTargetIds=this.activeTargetIds.add(t)}js(t){this.activeTargetIds=this.activeTargetIds.delete(t)}Gs(){const t={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(t)}}class Eu{constructor(){this.Mo=new Tu,this.xo={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(t){}updateMutationState(t,e,n){}addLocalQueryTarget(t,e=!0){return e&&this.Mo.zs(t),this.xo[t]||"not-current"}updateQueryState(t,e,n){this.xo[t]=e}removeLocalQueryTarget(t){this.Mo.js(t)}isLocalQueryTarget(t){return this.Mo.activeTargetIds.has(t)}clearQueryState(t){delete this.xo[t]}getAllActiveQueryTargets(){return this.Mo.activeTargetIds}isActiveQueryTarget(t){return this.Mo.activeTargetIds.has(t)}start(){return this.Mo=new Tu,Promise.resolve()}handleUserChange(t,e,n){}setOnlineState(t){}shutdown(){}writeSequenceNumber(t){}notifyBundleLoaded(t){}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Su{Oo(t){}shutdown(){}}
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _u="ConnectivityMonitor";class xu{constructor(){this.No=()=>this.Bo(),this.Lo=()=>this.ko(),this.qo=[],this.Qo()}Oo(t){this.qo.push(t)}shutdown(){window.removeEventListener("online",this.No),window.removeEventListener("offline",this.Lo)}Qo(){window.addEventListener("online",this.No),window.addEventListener("offline",this.Lo)}Bo(){q(_u,"Network connectivity changed: AVAILABLE");for(const t of this.qo)t(0)}ko(){q(_u,"Network connectivity changed: UNAVAILABLE");for(const t of this.qo)t(1)}static v(){return"undefined"!=typeof window&&void 0!==window.addEventListener&&void 0!==window.removeEventListener}}
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Cu=null;function Au(){return null===Cu?Cu=268435456+Math.round(2147483648*Math.random()):Cu++,"0x"+Cu.toString(16)
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */}const Du="RestConnection",Nu={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery"};class ku{get $o(){return!1}constructor(t){this.databaseInfo=t,this.databaseId=t.databaseId;const e=t.ssl?"https":"http",n=encodeURIComponent(this.databaseId.projectId),s=encodeURIComponent(this.databaseId.database);this.Uo=e+"://"+t.host,this.Ko=`projects/${n}/databases/${s}`,this.Wo=this.databaseId.database===Gn?`project_id=${n}`:`project_id=${n}&database_id=${s}`}Go(t,e,n,s,r){const i=Au(),o=this.zo(t,e.toUriEncodedString());q(Du,`Sending RPC '${t}' ${i}:`,o,n);const a={"google-cloud-resource-prefix":this.Ko,"x-goog-request-params":this.Wo};this.jo(a,s,r);const{host:u}=new URL(o),c=h(u);return this.Jo(t,o,a,n,c).then(e=>(q(Du,`Received RPC '${t}' ${i}: `,e),e),e=>{throw j(Du,`RPC '${t}' ${i} failed with error: `,e,"url: ",o,"request:",n),e})}Ho(t,e,n,s,r,i){return this.Go(t,e,n,s,r)}jo(t,e,n){t["X-Goog-Api-Client"]="gl-js/ fire/"+L,t["Content-Type"]="text/plain",this.databaseInfo.appId&&(t["X-Firebase-GMPID"]=this.databaseInfo.appId),e&&e.headers.forEach((e,n)=>t[n]=e),n&&n.headers.forEach((e,n)=>t[n]=e)}zo(t,e){const n=Nu[t];return`${this.Uo}/v1/${e}:${n}`}terminate(){}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ru{constructor(t){this.Yo=t.Yo,this.Zo=t.Zo}Xo(t){this.e_=t}t_(t){this.n_=t}r_(t){this.i_=t}onMessage(t){this.s_=t}close(){this.Zo()}send(t){this.Yo(t)}o_(){this.e_()}__(){this.n_()}a_(t){this.i_(t)}u_(t){this.s_(t)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Mu="WebChannelConnection";class Ou extends ku{constructor(t){super(t),this.c_=[],this.forceLongPolling=t.forceLongPolling,this.autoDetectLongPolling=t.autoDetectLongPolling,this.useFetchStreams=t.useFetchStreams,this.longPollingOptions=t.longPollingOptions}Jo(t,e,n,s,r){const i=Au();return new Promise((r,o)=>{const a=new _;a.setWithCredentials(!0),a.listenOnce(C.COMPLETE,()=>{try{switch(a.getLastErrorCode()){case A.NO_ERROR:const e=a.getResponseJson();q(Mu,`XHR for RPC '${t}' ${i} received:`,JSON.stringify(e)),r(e);break;case A.TIMEOUT:q(Mu,`RPC '${t}' ${i} timed out`),o(new X(H.DEADLINE_EXCEEDED,"Request time out"));break;case A.HTTP_ERROR:const n=a.getStatus();if(q(Mu,`RPC '${t}' ${i} failed with status:`,n,"response text:",a.getResponseText()),n>0){let t=a.getResponseJson();Array.isArray(t)&&(t=t[0]);const e=null==t?void 0:t.error;if(e&&e.status&&e.message){const t=function(t){const e=t.toLowerCase().replace(/_/g,"-");return Object.values(H).indexOf(e)>=0?e:H.UNKNOWN}(e.status);o(new X(t,e.message))}else o(new X(H.UNKNOWN,"Server responded with status "+a.getStatus()))}else o(new X(H.UNAVAILABLE,"Connection failed."));break;default:K(9055,{l_:t,streamId:i,h_:a.getLastErrorCode(),P_:a.getLastError()})}}finally{q(Mu,`RPC '${t}' ${i} completed.`)}});const u=JSON.stringify(s);q(Mu,`RPC '${t}' ${i} sending request:`,s),a.send(e,"POST",u,n,15)})}T_(t,e,n){const s=Au(),r=[this.Uo,"/","google.firestore.v1.Firestore","/",t,"/channel"],i=R(),o=k(),a={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},u=this.longPollingOptions.timeoutSeconds;void 0!==u&&(a.longPollingTimeout=Math.round(1e3*u)),this.useFetchStreams&&(a.useFetchStreams=!0),this.jo(a.initMessageHeaders,e,n),a.encodeInitMessageHeaders=!0;const c=r.join("");q(Mu,`Creating RPC '${t}' stream ${s}: ${c}`,a);const h=i.createWebChannel(c,a);this.I_(h);let l=!1,d=!1;const f=new Ru({Yo:e=>{d?q(Mu,`Not sending because RPC '${t}' stream ${s} is closed:`,e):(l||(q(Mu,`Opening RPC '${t}' stream ${s} transport.`),h.open(),l=!0),q(Mu,`RPC '${t}' stream ${s} sending:`,e),h.send(e))},Zo:()=>h.close()}),m=(t,e,n)=>{t.listen(e,t=>{try{n(t)}catch(e){setTimeout(()=>{throw e},0)}})};return m(h,x.EventType.OPEN,()=>{d||(q(Mu,`RPC '${t}' stream ${s} transport opened.`),f.o_())}),m(h,x.EventType.CLOSE,()=>{d||(d=!0,q(Mu,`RPC '${t}' stream ${s} transport closed`),f.a_(),this.E_(h))}),m(h,x.EventType.ERROR,e=>{d||(d=!0,j(Mu,`RPC '${t}' stream ${s} transport errored. Name:`,e.name,"Message:",e.message),f.a_(new X(H.UNAVAILABLE,"The operation could not be completed")))}),m(h,x.EventType.MESSAGE,e=>{var n;if(!d){const r=e.data[0];$(!!r,16349);const i=r,o=(null==i?void 0:i.error)||(null==(n=i[0])?void 0:n.error);if(o){q(Mu,`RPC '${t}' stream ${s} received error:`,o);const e=o.status;let n=function(t){const e=di[t];if(void 0!==e)return mi(e)}(e),r=o.message;void 0===n&&(n=H.INTERNAL,r="Unknown error status: "+e+" with message "+o.message),d=!0,f.a_(new X(n,r)),h.close()}else q(Mu,`RPC '${t}' stream ${s} received:`,r),f.u_(r)}}),m(o,N.STAT_EVENT,e=>{e.stat===D.PROXY?q(Mu,`RPC '${t}' stream ${s} detected buffering proxy`):e.stat===D.NOPROXY&&q(Mu,`RPC '${t}' stream ${s} detected no buffering proxy`)}),setTimeout(()=>{f.__()},0),f}terminate(){this.c_.forEach(t=>t.close()),this.c_=[]}I_(t){this.c_.push(t)}E_(t){this.c_=this.c_.filter(e=>e===t)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Vu(){return"undefined"!=typeof document?document:null}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Pu(t){return new Ri(t,!0)}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lu{constructor(t,e,n=1e3,s=1.5,r=6e4){this.Mi=t,this.timerId=e,this.d_=n,this.A_=s,this.R_=r,this.V_=0,this.m_=null,this.f_=Date.now(),this.reset()}reset(){this.V_=0}g_(){this.V_=this.R_}p_(t){this.cancel();const e=Math.floor(this.V_+this.y_()),n=Math.max(0,Date.now()-this.f_),s=Math.max(0,e-n);s>0&&q("ExponentialBackoff",`Backing off for ${s} ms (base delay: ${this.V_} ms, delay with jitter: ${e} ms, last attempt: ${n} ms ago)`),this.m_=this.Mi.enqueueAfterDelay(this.timerId,s,()=>(this.f_=Date.now(),t())),this.V_*=this.A_,this.V_<this.d_&&(this.V_=this.d_),this.V_>this.R_&&(this.V_=this.R_)}w_(){null!==this.m_&&(this.m_.skipDelay(),this.m_=null)}cancel(){null!==this.m_&&(this.m_.cancel(),this.m_=null)}y_(){return(Math.random()-.5)*this.V_}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fu="PersistentStream";class Uu{constructor(t,e,n,s,r,i,o,a){this.Mi=t,this.S_=n,this.b_=s,this.connection=r,this.authCredentialsProvider=i,this.appCheckCredentialsProvider=o,this.listener=a,this.state=0,this.D_=0,this.C_=null,this.v_=null,this.stream=null,this.F_=0,this.M_=new Lu(t,e)}x_(){return 1===this.state||5===this.state||this.O_()}O_(){return 2===this.state||3===this.state}start(){this.F_=0,4!==this.state?this.auth():this.N_()}async stop(){this.x_()&&await this.close(0)}B_(){this.state=0,this.M_.reset()}L_(){this.O_()&&null===this.C_&&(this.C_=this.Mi.enqueueAfterDelay(this.S_,6e4,()=>this.k_()))}q_(t){this.Q_(),this.stream.send(t)}async k_(){if(this.O_())return this.close(0)}Q_(){this.C_&&(this.C_.cancel(),this.C_=null)}U_(){this.v_&&(this.v_.cancel(),this.v_=null)}async close(t,e){this.Q_(),this.U_(),this.M_.cancel(),this.D_++,4!==t?this.M_.reset():e&&e.code===H.RESOURCE_EXHAUSTED?(B(e.toString()),B("Using maximum backoff delay to prevent overloading the backend."),this.M_.g_()):e&&e.code===H.UNAUTHENTICATED&&3!==this.state&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),null!==this.stream&&(this.K_(),this.stream.close(),this.stream=null),this.state=t,await this.listener.r_(e)}K_(){}auth(){this.state=1;const t=this.W_(this.D_),e=this.D_;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([t,n])=>{this.D_===e&&this.G_(t,n)},e=>{t(()=>{const t=new X(H.UNKNOWN,"Fetching auth token failed: "+e.message);return this.z_(t)})})}G_(t,e){const n=this.W_(this.D_);this.stream=this.j_(t,e),this.stream.Xo(()=>{n(()=>this.listener.Xo())}),this.stream.t_(()=>{n(()=>(this.state=2,this.v_=this.Mi.enqueueAfterDelay(this.b_,1e4,()=>(this.O_()&&(this.state=3),Promise.resolve())),this.listener.t_()))}),this.stream.r_(t=>{n(()=>this.z_(t))}),this.stream.onMessage(t=>{n(()=>1==++this.F_?this.J_(t):this.onNext(t))})}N_(){this.state=5,this.M_.p_(async()=>{this.state=0,this.start()})}z_(t){return q(Fu,`close with error: ${t}`),this.stream=null,this.close(4,t)}W_(t){return e=>{this.Mi.enqueueAndForget(()=>this.D_===t?e():(q(Fu,"stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class qu extends Uu{constructor(t,e,n,s,r,i){super(t,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",e,n,s,i),this.serializer=r}j_(t,e){return this.connection.T_("Listen",t,e)}J_(t){return this.onNext(t)}onNext(t){this.M_.reset();const e=function(t,e){let n;if("targetChange"in e){e.targetChange;const r="NO_CHANGE"===(s=e.targetChange.targetChangeType||"NO_CHANGE")?0:"ADD"===s?1:"REMOVE"===s?2:"CURRENT"===s?3:"RESET"===s?4:K(39313,{state:s}),i=e.targetChange.targetIds||[],o=function(t,e){return t.useProto3Json?($(void 0===e||"string"==typeof e,58123),Rn.fromBase64String(e||"")):($(void 0===e||e instanceof Buffer||e instanceof Uint8Array,16193),Rn.fromUint8Array(e||new Uint8Array))}(t,e.targetChange.resumeToken),a=e.targetChange.cause,u=a&&function(t){const e=void 0===t.code?H.UNKNOWN:mi(t.code);return new X(e,t.message||"")}(a);n=new Si(r,i,o,u||null)}else if("documentChange"in e){e.documentChange;const s=e.documentChange;s.document,s.document.name,s.document.updateTime;const r=ji(t,s.document.name),i=Li(s.document.updateTime),o=s.document.createTime?Li(s.document.createTime):kt.min(),a=new Ts({mapValue:{fields:s.document.fields}}),u=Ss.newFoundDocument(r,i,o,a),c=s.targetIds||[],h=s.removedTargetIds||[];n=new Ti(c,h,u.key,u)}else if("documentDelete"in e){e.documentDelete;const s=e.documentDelete;s.document;const r=ji(t,s.document),i=s.readTime?Li(s.readTime):kt.min(),o=Ss.newNoDocument(r,i),a=s.removedTargetIds||[];n=new Ti([],a,o.key,o)}else if("documentRemove"in e){e.documentRemove;const s=e.documentRemove;s.document;const r=ji(t,s.document),i=s.removedTargetIds||[];n=new Ti([],i,r,null)}else{if(!("filter"in e))return K(11601,{Rt:e});{e.filter;const t=e.filter;t.targetId;const{count:s=0,unchangedNames:r}=t,i=new li(s,r),o=t.targetId;n=new Ei(o,i)}}var s;return n}(this.serializer,t),n=function(t){if(!("targetChange"in t))return kt.min();const e=t.targetChange;return e.targetIds&&e.targetIds.length?kt.min():e.readTime?Li(e.readTime):kt.min()}(t);return this.listener.H_(e,n)}Y_(t){const e={};e.database=Gi(this.serializer),e.addTarget=function(t,e){let n;const s=e.target;if(n=Zs(s)?{documents:Yi(t,s)}:{query:Wi(t,s).ft},n.targetId=e.targetId,e.resumeToken.approximateByteSize()>0){n.resumeToken=Vi(t,e.resumeToken);const s=Mi(t,e.expectedCount);null!==s&&(n.expectedCount=s)}else if(e.snapshotVersion.compareTo(kt.min())>0){n.readTime=Oi(t,e.snapshotVersion.toTimestamp());const s=Mi(t,e.expectedCount);null!==s&&(n.expectedCount=s)}return n}(this.serializer,t);const n=function(t,e){const n=function(t){switch(t){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return K(28987,{purpose:t})}}(e.purpose);return null==n?null:{"goog-listen-tags":n}}(this.serializer,t);n&&(e.labels=n),this.q_(e)}Z_(t){const e={};e.database=Gi(this.serializer),e.removeTarget=t,this.q_(e)}}class Bu extends Uu{constructor(t,e,n,s,r,i){super(t,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",e,n,s,i),this.serializer=r}get X_(){return this.F_>0}start(){this.lastStreamToken=void 0,super.start()}K_(){this.X_&&this.ea([])}j_(t,e){return this.connection.T_("Write",t,e)}J_(t){return $(!!t.streamToken,31322),this.lastStreamToken=t.streamToken,$(!t.writeResults||0===t.writeResults.length,55816),this.listener.ta()}onNext(t){$(!!t.streamToken,12678),this.lastStreamToken=t.streamToken,this.M_.reset();const e=function(t,e){return t&&t.length>0?($(void 0!==e,14353),t.map(t=>function(t,e){let n=t.updateTime?Li(t.updateTime):Li(e);return n.isEqual(kt.min())&&(n=Li(e)),new $r(n,t.transformResults||[])}(t,e))):[]}(t.writeResults,t.commitTime),n=Li(t.commitTime);return this.listener.na(n,e)}ra(){const t={};t.database=Gi(this.serializer),this.q_(t)}ea(t){const e={streamToken:this.lastStreamToken,writes:t.map(t=>Hi(this.serializer,t))};this.q_(e)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ju{}class zu extends ju{constructor(t,e,n,s){super(),this.authCredentials=t,this.appCheckCredentials=e,this.connection=n,this.serializer=s,this.ia=!1}sa(){if(this.ia)throw new X(H.FAILED_PRECONDITION,"The client has already been terminated.")}Go(t,e,n,s){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([r,i])=>this.connection.Go(t,Ui(e,n),s,r,i)).catch(t=>{throw"FirebaseError"===t.name?(t.code===H.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),t):new X(H.UNKNOWN,t.toString())})}Ho(t,e,n,s,r){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([i,o])=>this.connection.Ho(t,Ui(e,n),s,i,o,r)).catch(t=>{throw"FirebaseError"===t.name?(t.code===H.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),t):new X(H.UNKNOWN,t.toString())})}terminate(){this.ia=!0,this.connection.terminate()}}class Ku{constructor(t,e){this.asyncQueue=t,this.onlineStateHandler=e,this.state="Unknown",this.oa=0,this._a=null,this.aa=!0}ua(){0===this.oa&&(this.ca("Unknown"),this._a=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this._a=null,this.la("Backend didn't respond within 10 seconds."),this.ca("Offline"),Promise.resolve())))}ha(t){"Online"===this.state?this.ca("Unknown"):(this.oa++,this.oa>=1&&(this.Pa(),this.la(`Connection failed 1 times. Most recent error: ${t.toString()}`),this.ca("Offline")))}set(t){this.Pa(),this.oa=0,"Online"===t&&(this.aa=!1),this.ca(t)}ca(t){t!==this.state&&(this.state=t,this.onlineStateHandler(t))}la(t){const e=`Could not reach Cloud Firestore backend. ${t}\nThis typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.aa?(B(e),this.aa=!1):q("OnlineStateTracker",e)}Pa(){null!==this._a&&(this._a.cancel(),this._a=null)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Gu="RemoteStore";class $u{constructor(t,e,n,s,r){this.localStore=t,this.datastore=e,this.asyncQueue=n,this.remoteSyncer={},this.Ta=[],this.Ia=new Map,this.Ea=new Set,this.da=[],this.Aa=r,this.Aa.Oo(t=>{n.enqueueAndForget(async()=>{ec(this)&&(q(Gu,"Restarting streams for network reachability change."),await async function(t){const e=Q(t);e.Ea.add(4),await Hu(e),e.Ra.set("Unknown"),e.Ea.delete(4),await Qu(e)}(this))})}),this.Ra=new Ku(n,s)}}async function Qu(t){if(ec(t))for(const e of t.da)await e(!0)}async function Hu(t){for(const e of t.da)await e(!1)}function Xu(t,e){const n=Q(t);n.Ia.has(e.targetId)||(n.Ia.set(e.targetId,e),tc(n)?Zu(n):wc(n).O_()&&Wu(n,e))}function Yu(t,e){const n=Q(t),s=wc(n);n.Ia.delete(e),s.O_()&&Ju(n,e),0===n.Ia.size&&(s.O_()?s.L_():ec(n)&&n.Ra.set("Unknown"))}function Wu(t,e){if(t.Va.Ue(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(kt.min())>0){const n=t.remoteSyncer.getRemoteKeysForTarget(e.targetId).size;e=e.withExpectedCount(n)}wc(t).Y_(e)}function Ju(t,e){t.Va.Ue(e),wc(t).Z_(e)}function Zu(t){t.Va=new xi({getRemoteKeysForTarget:e=>t.remoteSyncer.getRemoteKeysForTarget(e),At:e=>t.Ia.get(e)||null,ht:()=>t.datastore.serializer.databaseId}),wc(t).start(),t.Ra.ua()}function tc(t){return ec(t)&&!wc(t).x_()&&t.Ia.size>0}function ec(t){return 0===Q(t).Ea.size}function nc(t){t.Va=void 0}async function sc(t){t.Ra.set("Online")}async function rc(t){t.Ia.forEach((e,n)=>{Wu(t,e)})}async function ic(t,e){nc(t),tc(t)?(t.Ra.ha(e),Zu(t)):t.Ra.set("Unknown")}async function oc(t,e,n){if(t.Ra.set("Online"),e instanceof Si&&2===e.state&&e.cause)try{await async function(t,e){const n=e.cause;for(const s of e.targetIds)t.Ia.has(s)&&(await t.remoteSyncer.rejectListen(s,n),t.Ia.delete(s),t.Va.removeTarget(s))}(t,e)}catch(s){q(Gu,"Failed to remove targets %s: %s ",e.targetIds.join(","),s),await ac(t,s)}else if(e instanceof Ti?t.Va.Ze(e):e instanceof Ei?t.Va.st(e):t.Va.tt(e),!n.isEqual(kt.min()))try{const e=await yu(t.localStore);n.compareTo(e)>=0&&await function(t,e){const n=t.Va.Tt(e);return n.targetChanges.forEach((n,s)=>{if(n.resumeToken.approximateByteSize()>0){const r=t.Ia.get(s);r&&t.Ia.set(s,r.withResumeToken(n.resumeToken,e))}}),n.targetMismatches.forEach((e,n)=>{const s=t.Ia.get(e);if(!s)return;t.Ia.set(e,s.withResumeToken(Rn.EMPTY_BYTE_STRING,s.snapshotVersion)),Ju(t,e);const r=new uo(s.target,e,n,s.sequenceNumber);Wu(t,r)}),t.remoteSyncer.applyRemoteEvent(n)}(t,n)}catch(r){q(Gu,"Failed to raise snapshot:",r),await ac(t,r)}}async function ac(t,e,n){if(!Yt(e))throw e;t.Ea.add(1),await Hu(t),t.Ra.set("Offline"),n||(n=()=>yu(t.localStore)),t.asyncQueue.enqueueRetryable(async()=>{q(Gu,"Retrying IndexedDB access"),await n(),t.Ea.delete(1),await Qu(t)})}function uc(t,e){return e().catch(n=>ac(t,n,e))}async function cc(t){const e=Q(t),n=Ic(e);let s=e.Ta.length>0?e.Ta[e.Ta.length-1].batchId:ie;for(;hc(e);)try{const t=await wu(e.localStore,s);if(null===t){0===e.Ta.length&&n.L_();break}s=t.batchId,lc(e,t)}catch(r){await ac(e,r)}dc(e)&&fc(e)}function hc(t){return ec(t)&&t.Ta.length<10}function lc(t,e){t.Ta.push(e);const n=Ic(t);n.O_()&&n.X_&&n.ea(e.mutations)}function dc(t){return ec(t)&&!Ic(t).x_()&&t.Ta.length>0}function fc(t){Ic(t).start()}async function mc(t){Ic(t).ra()}async function gc(t){const e=Ic(t);for(const n of t.Ta)e.ea(n.mutations)}async function pc(t,e,n){const s=t.Ta.shift(),r=ci.from(s,e,n);await uc(t,()=>t.remoteSyncer.applySuccessfulWrite(r)),await cc(t)}async function yc(t,e){e&&Ic(t).X_&&await async function(t,e){if(function(t){switch(t){case H.OK:return K(64938);case H.CANCELLED:case H.UNKNOWN:case H.DEADLINE_EXCEEDED:case H.RESOURCE_EXHAUSTED:case H.INTERNAL:case H.UNAVAILABLE:case H.UNAUTHENTICATED:return!1;case H.INVALID_ARGUMENT:case H.NOT_FOUND:case H.ALREADY_EXISTS:case H.PERMISSION_DENIED:case H.FAILED_PRECONDITION:case H.ABORTED:case H.OUT_OF_RANGE:case H.UNIMPLEMENTED:case H.DATA_LOSS:return!0;default:return K(15467,{code:t})}}(n=e.code)&&n!==H.ABORTED){const n=t.Ta.shift();Ic(t).B_(),await uc(t,()=>t.remoteSyncer.rejectFailedWrite(n.batchId,e)),await cc(t)}var n}(t,e),dc(t)&&fc(t)}async function vc(t,e){const n=Q(t);n.asyncQueue.verifyOperationInProgress(),q(Gu,"RemoteStore received new credentials");const s=ec(n);n.Ea.add(3),await Hu(n),s&&n.Ra.set("Unknown"),await n.remoteSyncer.handleCredentialChange(e),n.Ea.delete(3),await Qu(n)}function wc(t){return t.ma||(t.ma=function(t,e,n){const s=Q(t);return s.sa(),new qu(e,s.connection,s.authCredentials,s.appCheckCredentials,s.serializer,n)}(t.datastore,t.asyncQueue,{Xo:sc.bind(null,t),t_:rc.bind(null,t),r_:ic.bind(null,t),H_:oc.bind(null,t)}),t.da.push(async e=>{e?(t.ma.B_(),tc(t)?Zu(t):t.Ra.set("Unknown")):(await t.ma.stop(),nc(t))})),t.ma}function Ic(t){return t.fa||(t.fa=function(t,e,n){const s=Q(t);return s.sa(),new Bu(e,s.connection,s.authCredentials,s.appCheckCredentials,s.serializer,n)}(t.datastore,t.asyncQueue,{Xo:()=>Promise.resolve(),t_:mc.bind(null,t),r_:yc.bind(null,t),ta:gc.bind(null,t),na:pc.bind(null,t)}),t.da.push(async e=>{e?(t.fa.B_(),await cc(t)):(await t.fa.stop(),t.Ta.length>0&&(q(Gu,`Stopping write stream with ${t.Ta.length} pending writes`),t.Ta=[]))})),t.fa
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */}class bc{constructor(t,e,n,s,r){this.asyncQueue=t,this.timerId=e,this.targetTimeMs=n,this.op=s,this.removalCallback=r,this.deferred=new Y,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(t=>{})}get promise(){return this.deferred.promise}static createAndSchedule(t,e,n,s,r){const i=Date.now()+n,o=new bc(t,e,i,s,r);return o.start(n),o}start(t){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),t)}skipDelay(){return this.handleDelayElapsed()}cancel(t){null!==this.timerHandle&&(this.clearTimeout(),this.deferred.reject(new X(H.CANCELLED,"Operation cancelled"+(t?": "+t:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>null!==this.timerHandle?(this.clearTimeout(),this.op().then(t=>this.deferred.resolve(t))):Promise.resolve())}clearTimeout(){null!==this.timerHandle&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function Tc(t,e){if(B("AsyncQueue",`${e}: ${t}`),Yt(t))return new X(H.UNAVAILABLE,`${e}: ${t}`);throw t}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ec{static emptySet(t){return new Ec(t.comparator)}constructor(t){this.comparator=t?(e,n)=>t(e,n)||wt.comparator(e.key,n.key):(t,e)=>wt.comparator(t.key,e.key),this.keyedMap=br(),this.sortedSet=new Sn(this.comparator)}has(t){return null!=this.keyedMap.get(t)}get(t){return this.keyedMap.get(t)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(t){const e=this.keyedMap.get(t);return e?this.sortedSet.indexOf(e):-1}get size(){return this.sortedSet.size}forEach(t){this.sortedSet.inorderTraversal((e,n)=>(t(e),!1))}add(t){const e=this.delete(t.key);return e.copy(e.keyedMap.insert(t.key,t),e.sortedSet.insert(t,null))}delete(t){const e=this.get(t);return e?this.copy(this.keyedMap.remove(t),this.sortedSet.remove(e)):this}isEqual(t){if(!(t instanceof Ec))return!1;if(this.size!==t.size)return!1;const e=this.sortedSet.getIterator(),n=t.sortedSet.getIterator();for(;e.hasNext();){const t=e.getNext().key,s=n.getNext().key;if(!t.isEqual(s))return!1}return!0}toString(){const t=[];return this.forEach(e=>{t.push(e.toString())}),0===t.length?"DocumentSet ()":"DocumentSet (\n  "+t.join("  \n")+"\n)"}copy(t,e){const n=new Ec;return n.comparator=this.comparator,n.keyedMap=t,n.sortedSet=e,n}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sc{constructor(){this.ga=new Sn(wt.comparator)}track(t){const e=t.doc.key,n=this.ga.get(e);n?0!==t.type&&3===n.type?this.ga=this.ga.insert(e,t):3===t.type&&1!==n.type?this.ga=this.ga.insert(e,{type:n.type,doc:t.doc}):2===t.type&&2===n.type?this.ga=this.ga.insert(e,{type:2,doc:t.doc}):2===t.type&&0===n.type?this.ga=this.ga.insert(e,{type:0,doc:t.doc}):1===t.type&&0===n.type?this.ga=this.ga.remove(e):1===t.type&&2===n.type?this.ga=this.ga.insert(e,{type:1,doc:n.doc}):0===t.type&&1===n.type?this.ga=this.ga.insert(e,{type:2,doc:t.doc}):K(63341,{Rt:t,pa:n}):this.ga=this.ga.insert(e,t)}ya(){const t=[];return this.ga.inorderTraversal((e,n)=>{t.push(n)}),t}}class _c{constructor(t,e,n,s,r,i,o,a,u){this.query=t,this.docs=e,this.oldDocs=n,this.docChanges=s,this.mutatedKeys=r,this.fromCache=i,this.syncStateChanged=o,this.excludesMetadataChanges=a,this.hasCachedResults=u}static fromInitialDocuments(t,e,n,s,r){const i=[];return e.forEach(t=>{i.push({type:0,doc:t})}),new _c(t,e,Ec.emptySet(e),i,n,s,!0,!1,r)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(t){if(!(this.fromCache===t.fromCache&&this.hasCachedResults===t.hasCachedResults&&this.syncStateChanged===t.syncStateChanged&&this.mutatedKeys.isEqual(t.mutatedKeys)&&lr(this.query,t.query)&&this.docs.isEqual(t.docs)&&this.oldDocs.isEqual(t.oldDocs)))return!1;const e=this.docChanges,n=t.docChanges;if(e.length!==n.length)return!1;for(let s=0;s<e.length;s++)if(e[s].type!==n[s].type||!e[s].doc.isEqual(n[s].doc))return!1;return!0}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xc{constructor(){this.wa=void 0,this.Sa=[]}ba(){return this.Sa.some(t=>t.Da())}}class Cc{constructor(){this.queries=Ac(),this.onlineState="Unknown",this.Ca=new Set}terminate(){!function(t,e){const n=Q(t),s=n.queries;n.queries=Ac(),s.forEach((t,n)=>{for(const s of n.Sa)s.onError(e)})}(this,new X(H.ABORTED,"Firestore shutting down"))}}function Ac(){return new yr(t=>dr(t),lr)}async function Dc(t,e){const n=Q(t);let s=3;const r=e.query;let i=n.queries.get(r);i?!i.ba()&&e.Da()&&(s=2):(i=new xc,s=e.Da()?0:1);try{switch(s){case 0:i.wa=await n.onListen(r,!0);break;case 1:i.wa=await n.onListen(r,!1);break;case 2:await n.onFirstRemoteStoreListen(r)}}catch(o){const t=Tc(o,`Initialization of query '${fr(e.query)}' failed`);return void e.onError(t)}n.queries.set(r,i),i.Sa.push(e),e.va(n.onlineState),i.wa&&e.Fa(i.wa)&&Mc(n)}async function Nc(t,e){const n=Q(t),s=e.query;let r=3;const i=n.queries.get(s);if(i){const t=i.Sa.indexOf(e);t>=0&&(i.Sa.splice(t,1),0===i.Sa.length?r=e.Da()?0:1:!i.ba()&&e.Da()&&(r=2))}switch(r){case 0:return n.queries.delete(s),n.onUnlisten(s,!0);case 1:return n.queries.delete(s),n.onUnlisten(s,!1);case 2:return n.onLastRemoteStoreUnlisten(s);default:return}}function kc(t,e){const n=Q(t);let s=!1;for(const r of e){const t=r.query,e=n.queries.get(t);if(e){for(const t of e.Sa)t.Fa(r)&&(s=!0);e.wa=r}}s&&Mc(n)}function Rc(t,e,n){const s=Q(t),r=s.queries.get(e);if(r)for(const i of r.Sa)i.onError(n);s.queries.delete(e)}function Mc(t){t.Ca.forEach(t=>{t.next()})}var Oc,Vc;(Vc=Oc||(Oc={})).Ma="default",Vc.Cache="cache";class Pc{constructor(t,e,n){this.query=t,this.xa=e,this.Oa=!1,this.Na=null,this.onlineState="Unknown",this.options=n||{}}Fa(t){if(!this.options.includeMetadataChanges){const e=[];for(const n of t.docChanges)3!==n.type&&e.push(n);t=new _c(t.query,t.docs,t.oldDocs,e,t.mutatedKeys,t.fromCache,t.syncStateChanged,!0,t.hasCachedResults)}let e=!1;return this.Oa?this.Ba(t)&&(this.xa.next(t),e=!0):this.La(t,this.onlineState)&&(this.ka(t),e=!0),this.Na=t,e}onError(t){this.xa.error(t)}va(t){this.onlineState=t;let e=!1;return this.Na&&!this.Oa&&this.La(this.Na,t)&&(this.ka(this.Na),e=!0),e}La(t,e){if(!t.fromCache)return!0;if(!this.Da())return!0;const n="Offline"!==e;return(!this.options.qa||!n)&&(!t.docs.isEmpty()||t.hasCachedResults||"Offline"===e)}Ba(t){if(t.docChanges.length>0)return!0;const e=this.Na&&this.Na.hasPendingWrites!==t.hasPendingWrites;return!(!t.syncStateChanged&&!e)&&!0===this.options.includeMetadataChanges}ka(t){t=_c.fromInitialDocuments(t.query,t.docs,t.mutatedKeys,t.fromCache,t.hasCachedResults),this.Oa=!0,this.xa.next(t)}Da(){return this.options.source!==Oc.Cache}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lc{constructor(t){this.key=t}}class Fc{constructor(t){this.key=t}}class Uc{constructor(t,e){this.query=t,this.Ya=e,this.Za=null,this.hasCachedResults=!1,this.current=!1,this.Xa=Ar(),this.mutatedKeys=Ar(),this.eu=gr(t),this.tu=new Ec(this.eu)}get nu(){return this.Ya}ru(t,e){const n=e?e.iu:new Sc,s=e?e.tu:this.tu;let r=e?e.mutatedKeys:this.mutatedKeys,i=s,o=!1;const a="F"===this.query.limitType&&s.size===this.query.limit?s.last():null,u="L"===this.query.limitType&&s.size===this.query.limit?s.first():null;if(t.inorderTraversal((t,e)=>{const c=s.get(t),h=mr(this.query,e)?e:null,l=!!c&&this.mutatedKeys.has(c.key),d=!!h&&(h.hasLocalMutations||this.mutatedKeys.has(h.key)&&h.hasCommittedMutations);let f=!1;c&&h?c.data.isEqual(h.data)?l!==d&&(n.track({type:3,doc:h}),f=!0):this.su(c,h)||(n.track({type:2,doc:h}),f=!0,(a&&this.eu(h,a)>0||u&&this.eu(h,u)<0)&&(o=!0)):!c&&h?(n.track({type:0,doc:h}),f=!0):c&&!h&&(n.track({type:1,doc:c}),f=!0,(a||u)&&(o=!0)),f&&(h?(i=i.add(h),r=d?r.add(t):r.delete(t)):(i=i.delete(t),r=r.delete(t)))}),null!==this.query.limit)for(;i.size>this.query.limit;){const t="F"===this.query.limitType?i.last():i.first();i=i.delete(t.key),r=r.delete(t.key),n.track({type:1,doc:t})}return{tu:i,iu:n,Cs:o,mutatedKeys:r}}su(t,e){return t.hasLocalMutations&&e.hasCommittedMutations&&!e.hasLocalMutations}applyChanges(t,e,n,s){const r=this.tu;this.tu=t.tu,this.mutatedKeys=t.mutatedKeys;const i=t.iu.ya();i.sort((t,e)=>function(t,e){const n=t=>{switch(t){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return K(20277,{Rt:t})}};return n(t)-n(e)}(t.type,e.type)||this.eu(t.doc,e.doc)),this.ou(n),s=s??!1;const o=e&&!s?this._u():[],a=0===this.Xa.size&&this.current&&!s?1:0,u=a!==this.Za;return this.Za=a,0!==i.length||u?{snapshot:new _c(this.query,t.tu,r,i,t.mutatedKeys,0===a,u,!1,!!n&&n.resumeToken.approximateByteSize()>0),au:o}:{au:o}}va(t){return this.current&&"Offline"===t?(this.current=!1,this.applyChanges({tu:this.tu,iu:new Sc,mutatedKeys:this.mutatedKeys,Cs:!1},!1)):{au:[]}}uu(t){return!this.Ya.has(t)&&!!this.tu.has(t)&&!this.tu.get(t).hasLocalMutations}ou(t){t&&(t.addedDocuments.forEach(t=>this.Ya=this.Ya.add(t)),t.modifiedDocuments.forEach(t=>{}),t.removedDocuments.forEach(t=>this.Ya=this.Ya.delete(t)),this.current=t.current)}_u(){if(!this.current)return[];const t=this.Xa;this.Xa=Ar(),this.tu.forEach(t=>{this.uu(t.key)&&(this.Xa=this.Xa.add(t.key))});const e=[];return t.forEach(t=>{this.Xa.has(t)||e.push(new Fc(t))}),this.Xa.forEach(n=>{t.has(n)||e.push(new Lc(n))}),e}cu(t){this.Ya=t.Qs,this.Xa=Ar();const e=this.ru(t.documents);return this.applyChanges(e,!0)}lu(){return _c.fromInitialDocuments(this.query,this.tu,this.mutatedKeys,0===this.Za,this.hasCachedResults)}}const qc="SyncEngine";class Bc{constructor(t,e,n){this.query=t,this.targetId=e,this.view=n}}class jc{constructor(t){this.key=t,this.hu=!1}}class zc{constructor(t,e,n,s,r,i){this.localStore=t,this.remoteStore=e,this.eventManager=n,this.sharedClientState=s,this.currentUser=r,this.maxConcurrentLimboResolutions=i,this.Pu={},this.Tu=new yr(t=>dr(t),lr),this.Iu=new Map,this.Eu=new Set,this.du=new Sn(wt.comparator),this.Au=new Map,this.Ru=new Ga,this.Vu={},this.mu=new Map,this.fu=va.cr(),this.onlineState="Unknown",this.gu=void 0}get isPrimaryClient(){return!0===this.gu}}async function Kc(t,e,n=!0){const s=hh(t);let r;const i=s.Tu.get(e);return i?(s.sharedClientState.addLocalQueryTarget(i.targetId),r=i.view.lu()):r=await $c(s,e,n,!0),r}async function Gc(t,e){const n=hh(t);await $c(n,e,!0,!1)}async function $c(t,e,n,s){const r=await function(t,e){const n=Q(t);return n.persistence.runTransaction("Allocate target","readwrite",t=>{let s;return n.Pi.getTargetData(t,e).next(r=>r?(s=r,zt.resolve(s)):n.Pi.allocateTargetId(t).next(r=>(s=new uo(e,r,"TargetPurposeListen",t.currentSequenceNumber),n.Pi.addTargetData(t,s).next(()=>s))))}).then(t=>{const s=n.Ms.get(t.targetId);return(null===s||t.snapshotVersion.compareTo(s.snapshotVersion)>0)&&(n.Ms=n.Ms.insert(t.targetId,t),n.xs.set(e,t.targetId)),t})}(t.localStore,ur(e)),i=r.targetId,o=t.sharedClientState.addLocalQueryTarget(i,n);let a;return s&&(a=await async function(t,e,n,s,r){t.pu=(e,n,s)=>async function(t,e,n,s){let r=e.view.ru(n);r.Cs&&(r=await bu(t.localStore,e.query,!1).then(({documents:t})=>e.view.ru(t,r)));const i=s&&s.targetChanges.get(e.targetId),o=s&&null!=s.targetMismatches.get(e.targetId),a=e.view.applyChanges(r,t.isPrimaryClient,i,o);return rh(t,e.targetId,a.au),a.snapshot}(t,e,n,s);const i=await bu(t.localStore,e,!0),o=new Uc(e,i.Qs),a=o.ru(i.documents),u=bi.createSynthesizedTargetChangeForCurrentChange(n,s&&"Offline"!==t.onlineState,r),c=o.applyChanges(a,t.isPrimaryClient,u);rh(t,n,c.au);const h=new Bc(e,n,o);return t.Tu.set(e,h),t.Iu.has(n)?t.Iu.get(n).push(e):t.Iu.set(n,[e]),c.snapshot}(t,e,i,"current"===o,r.resumeToken)),t.isPrimaryClient&&n&&Xu(t.remoteStore,r),a}async function Qc(t,e,n){const s=Q(t),r=s.Tu.get(e),i=s.Iu.get(r.targetId);if(i.length>1)return s.Iu.set(r.targetId,i.filter(t=>!lr(t,e))),void s.Tu.delete(e);s.isPrimaryClient?(s.sharedClientState.removeLocalQueryTarget(r.targetId),s.sharedClientState.isActiveQueryTarget(r.targetId)||await Iu(s.localStore,r.targetId,!1).then(()=>{s.sharedClientState.clearQueryState(r.targetId),n&&Yu(s.remoteStore,r.targetId),nh(s,r.targetId)}).catch(jt)):(nh(s,r.targetId),await Iu(s.localStore,r.targetId,!0))}async function Hc(t,e){const n=Q(t),s=n.Tu.get(e),r=n.Iu.get(s.targetId);n.isPrimaryClient&&1===r.length&&(n.sharedClientState.removeLocalQueryTarget(s.targetId),Yu(n.remoteStore,s.targetId))}async function Xc(t,e){const n=Q(t);try{const t=await vu(n.localStore,e);e.targetChanges.forEach((t,e)=>{const s=n.Au.get(e);s&&($(t.addedDocuments.size+t.modifiedDocuments.size+t.removedDocuments.size<=1,22616),t.addedDocuments.size>0?s.hu=!0:t.modifiedDocuments.size>0?$(s.hu,14607):t.removedDocuments.size>0&&($(s.hu,42227),s.hu=!1))}),await ah(n,t,e)}catch(s){await jt(s)}}function Yc(t,e,n){const s=Q(t);if(s.isPrimaryClient&&0===n||!s.isPrimaryClient&&1===n){const t=[];s.Tu.forEach((n,s)=>{const r=s.view.va(e);r.snapshot&&t.push(r.snapshot)}),function(t,e){const n=Q(t);n.onlineState=e;let s=!1;n.queries.forEach((t,n)=>{for(const r of n.Sa)r.va(e)&&(s=!0)}),s&&Mc(n)}(s.eventManager,e),t.length&&s.Pu.H_(t),s.onlineState=e,s.isPrimaryClient&&s.sharedClientState.setOnlineState(e)}}async function Wc(t,e,n){const s=Q(t);s.sharedClientState.updateQueryState(e,"rejected",n);const r=s.Au.get(e),i=r&&r.key;if(i){let t=new Sn(wt.comparator);t=t.insert(i,Ss.newNoDocument(i,kt.min()));const n=Ar().add(i),r=new Ii(kt.min(),new Map,new Sn(at),t,n);await Xc(s,r),s.du=s.du.remove(i),s.Au.delete(e),oh(s)}else await Iu(s.localStore,e,!1).then(()=>nh(s,e,n)).catch(jt)}async function Jc(t,e){const n=Q(t),s=e.batch.batchId;try{const t=await function(t,e){const n=Q(t);return n.persistence.runTransaction("Acknowledge batch","readwrite-primary",t=>{const s=e.batch.keys(),r=n.Ns.newChangeBuffer({trackRemovals:!0});return function(t,e,n,s){const r=n.batch,i=r.keys();let o=zt.resolve();return i.forEach(t=>{o=o.next(()=>s.getEntry(e,t)).next(e=>{const i=n.docVersions.get(t);$(null!==i,48541),e.version.compareTo(i)<0&&(r.applyToRemoteDocument(e,n),e.isValidDocument()&&(e.setReadTime(n.commitVersion),s.addEntry(e)))})}),o.next(()=>t.mutationQueue.removeMutationBatch(e,r))}(n,t,e,r).next(()=>r.apply(t)).next(()=>n.mutationQueue.performConsistencyCheck(t)).next(()=>n.documentOverlayCache.removeOverlaysForBatchId(t,s,e.batch.batchId)).next(()=>n.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(t,function(t){let e=Ar();for(let n=0;n<t.mutationResults.length;++n)t.mutationResults[n].transformResults.length>0&&(e=e.add(t.batch.mutations[n].key));return e}(e))).next(()=>n.localDocuments.getDocuments(t,s))})}(n.localStore,e);eh(n,s,null),th(n,s),n.sharedClientState.updateMutationState(s,"acknowledged"),await ah(n,t)}catch(r){await jt(r)}}async function Zc(t,e,n){const s=Q(t);try{const t=await function(t,e){const n=Q(t);return n.persistence.runTransaction("Reject batch","readwrite-primary",t=>{let s;return n.mutationQueue.lookupMutationBatch(t,e).next(e=>($(null!==e,37113),s=e.keys(),n.mutationQueue.removeMutationBatch(t,e))).next(()=>n.mutationQueue.performConsistencyCheck(t)).next(()=>n.documentOverlayCache.removeOverlaysForBatchId(t,s,e)).next(()=>n.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(t,s)).next(()=>n.localDocuments.getDocuments(t,s))})}(s.localStore,e);eh(s,e,n),th(s,e),s.sharedClientState.updateMutationState(e,"rejected",n),await ah(s,t)}catch(r){await jt(r)}}function th(t,e){(t.mu.get(e)||[]).forEach(t=>{t.resolve()}),t.mu.delete(e)}function eh(t,e,n){const s=Q(t);let r=s.Vu[s.currentUser.toKey()];if(r){const t=r.get(e);t&&(n?t.reject(n):t.resolve(),r=r.remove(e)),s.Vu[s.currentUser.toKey()]=r}}function nh(t,e,n=null){t.sharedClientState.removeLocalQueryTarget(e);for(const s of t.Iu.get(e))t.Tu.delete(s),n&&t.Pu.yu(s,n);t.Iu.delete(e),t.isPrimaryClient&&t.Ru.jr(e).forEach(e=>{t.Ru.containsKey(e)||sh(t,e)})}function sh(t,e){t.Eu.delete(e.path.canonicalString());const n=t.du.get(e);null!==n&&(Yu(t.remoteStore,n),t.du=t.du.remove(e),t.Au.delete(n),oh(t))}function rh(t,e,n){for(const s of n)s instanceof Lc?(t.Ru.addReference(s.key,e),ih(t,s)):s instanceof Fc?(q(qc,"Document no longer in limbo: "+s.key),t.Ru.removeReference(s.key,e),t.Ru.containsKey(s.key)||sh(t,s.key)):K(19791,{wu:s})}function ih(t,e){const n=e.key,s=n.path.canonicalString();t.du.get(n)||t.Eu.has(s)||(q(qc,"New document in limbo: "+n),t.Eu.add(s),oh(t))}function oh(t){for(;t.Eu.size>0&&t.du.size<t.maxConcurrentLimboResolutions;){const e=t.Eu.values().next().value;t.Eu.delete(e);const n=new wt(pt.fromString(e)),s=t.fu.next();t.Au.set(s,new jc(n)),t.du=t.du.insert(n,s),Xu(t.remoteStore,new uo(ur(rr(n.path)),s,"TargetPurposeLimboResolution",re.ce))}}async function ah(t,e,n){const s=Q(t),r=[],i=[],o=[];s.Tu.isEmpty()||(s.Tu.forEach((t,a)=>{o.push(s.pu(a,e,n).then(t=>{var e;if((t||n)&&s.isPrimaryClient){const r=t?!t.fromCache:null==(e=null==n?void 0:n.targetChanges.get(a.targetId))?void 0:e.current;s.sharedClientState.updateQueryState(a.targetId,r?"current":"not-current")}if(t){r.push(t);const e=hu.As(a.targetId,t);i.push(e)}}))}),await Promise.all(o),s.Pu.H_(r),await async function(t,e){const n=Q(t);try{await n.persistence.runTransaction("notifyLocalViewChanges","readwrite",t=>zt.forEach(e,e=>zt.forEach(e.Es,s=>n.persistence.referenceDelegate.addReference(t,e.targetId,s)).next(()=>zt.forEach(e.ds,s=>n.persistence.referenceDelegate.removeReference(t,e.targetId,s)))))}catch(s){if(!Yt(s))throw s;q(fu,"Failed to update sequence numbers: "+s)}for(const r of e){const t=r.targetId;if(!r.fromCache){const e=n.Ms.get(t),s=e.snapshotVersion,r=e.withLastLimboFreeSnapshotVersion(s);n.Ms=n.Ms.insert(t,r)}}}(s.localStore,i))}async function uh(t,e){const n=Q(t);if(!n.currentUser.isEqual(e)){q(qc,"User change. New user:",e.toKey());const t=await pu(n.localStore,e);n.currentUser=e,r="'waitForPendingWrites' promise is rejected due to a user change.",(s=n).mu.forEach(t=>{t.forEach(t=>{t.reject(new X(H.CANCELLED,r))})}),s.mu.clear(),n.sharedClientState.handleUserChange(e,t.removedBatchIds,t.addedBatchIds),await ah(n,t.Ls)}var s,r}function ch(t,e){const n=Q(t),s=n.Au.get(e);if(s&&s.hu)return Ar().add(s.key);{let t=Ar();const s=n.Iu.get(e);if(!s)return t;for(const e of s){const s=n.Tu.get(e);t=t.unionWith(s.view.nu)}return t}}function hh(t){const e=Q(t);return e.remoteStore.remoteSyncer.applyRemoteEvent=Xc.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=ch.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=Wc.bind(null,e),e.Pu.H_=kc.bind(null,e.eventManager),e.Pu.yu=Rc.bind(null,e.eventManager),e}function lh(t){const e=Q(t);return e.remoteStore.remoteSyncer.applySuccessfulWrite=Jc.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=Zc.bind(null,e),e}class dh{constructor(){this.kind="memory",this.synchronizeTabs=!1}async initialize(t){this.serializer=Pu(t.databaseInfo.databaseId),this.sharedClientState=this.Du(t),this.persistence=this.Cu(t),await this.persistence.start(),this.localStore=this.vu(t),this.gcScheduler=this.Fu(t,this.localStore),this.indexBackfillerScheduler=this.Mu(t,this.localStore)}Fu(t,e){return null}Mu(t,e){return null}vu(t){return gu(this.persistence,new du,t.initialUser,this.serializer)}Cu(t){return new Wa(Za.mi,this.serializer)}Du(t){return new Eu}async terminate(){var t,e;null==(t=this.gcScheduler)||t.stop(),null==(e=this.indexBackfillerScheduler)||e.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}dh.provider={build:()=>new dh};class fh extends dh{constructor(t){super(),this.cacheSizeBytes=t}Fu(t,e){$(this.persistence.referenceDelegate instanceof tu,46915);const n=this.persistence.referenceDelegate.garbageCollector;return new xa(n,t.asyncQueue,e)}Cu(t){const e=void 0!==this.cacheSizeBytes?ha.withCacheSize(this.cacheSizeBytes):ha.DEFAULT;return new Wa(t=>tu.mi(t,e),this.serializer)}}class mh extends dh{constructor(t,e,n){super(),this.xu=t,this.cacheSizeBytes=e,this.forceOwnership=n,this.kind="persistent",this.synchronizeTabs=!1}async initialize(t){await super.initialize(t),await this.xu.initialize(this,t),await lh(this.xu.syncEngine),await cc(this.xu.remoteStore),await this.persistence.Ji(()=>(this.gcScheduler&&!this.gcScheduler.started&&this.gcScheduler.start(),this.indexBackfillerScheduler&&!this.indexBackfillerScheduler.started&&this.indexBackfillerScheduler.start(),Promise.resolve()))}vu(t){return gu(this.persistence,new du,t.initialUser,this.serializer)}Fu(t,e){const n=this.persistence.referenceDelegate.garbageCollector;return new xa(n,t.asyncQueue,e)}Mu(t,e){const n=new se(e,this.persistence);return new ne(t.asyncQueue,n)}Cu(t){const e=function(t,e){let n=t.projectId;return t.isDefaultDatabase||(n+="."+t.database),"firestore/"+e+"/"+n+"/"}(t.databaseInfo.databaseId,t.databaseInfo.persistenceKey),n=void 0!==this.cacheSizeBytes?ha.withCacheSize(this.cacheSizeBytes):ha.DEFAULT;return new au(this.synchronizeTabs,e,t.clientId,n,t.asyncQueue,"undefined"!=typeof window?window:null,Vu(),this.serializer,this.sharedClientState,!!this.forceOwnership)}Du(t){return new Eu}}class gh{async initialize(t,e){this.localStore||(this.localStore=t.localStore,this.sharedClientState=t.sharedClientState,this.datastore=this.createDatastore(e),this.remoteStore=this.createRemoteStore(e),this.eventManager=this.createEventManager(e),this.syncEngine=this.createSyncEngine(e,!t.synchronizeTabs),this.sharedClientState.onlineStateHandler=t=>Yc(this.syncEngine,t,1),this.remoteStore.remoteSyncer.handleCredentialChange=uh.bind(null,this.syncEngine),await async function(t,e){const n=Q(t);e?(n.Ea.delete(2),await Qu(n)):e||(n.Ea.add(2),await Hu(n),n.Ra.set("Unknown"))}(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(t){return new Cc}createDatastore(t){const e=Pu(t.databaseInfo.databaseId),n=(s=t.databaseInfo,new Ou(s));var s;return function(t,e,n,s){return new zu(t,e,n,s)}(t.authCredentials,t.appCheckCredentials,n,e)}createRemoteStore(t){return e=this.localStore,n=this.datastore,s=t.asyncQueue,r=t=>Yc(this.syncEngine,t,0),i=xu.v()?new xu:new Su,new $u(e,n,s,r,i);var e,n,s,r,i}createSyncEngine(t,e){return function(t,e,n,s,r,i,o){const a=new zc(t,e,n,s,r,i);return o&&(a.gu=!0),a}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,t.initialUser,t.maxConcurrentLimboResolutions,e)}async terminate(){var t,e;await async function(t){const e=Q(t);q(Gu,"RemoteStore shutting down."),e.Ea.add(5),await Hu(e),e.Aa.shutdown(),e.Ra.set("Unknown")}(this.remoteStore),null==(t=this.datastore)||t.terminate(),null==(e=this.eventManager)||e.terminate()}}gh.provider={build:()=>new gh};
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ph{constructor(t){this.observer=t,this.muted=!1}next(t){this.muted||this.observer.next&&this.Ou(this.observer.next,t)}error(t){this.muted||(this.observer.error?this.Ou(this.observer.error,t):B("Uncaught Error in snapshot listener:",t.toString()))}Nu(){this.muted=!0}Ou(t,e){setTimeout(()=>{this.muted||t(e)},0)}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yh="FirestoreClient";class vh{constructor(t,e,n,s,r){this.authCredentials=t,this.appCheckCredentials=e,this.asyncQueue=n,this.databaseInfo=s,this.user=P.UNAUTHENTICATED,this.clientId=ot.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this._uninitializedComponentsProvider=r,this.authCredentials.start(n,async t=>{q(yh,"Received user=",t.uid),await this.authCredentialListener(t),this.user=t}),this.appCheckCredentials.start(n,t=>(q(yh,"Received new app check token=",t),this.appCheckCredentialListener(t,this.user)))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this.databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(t){this.authCredentialListener=t}setAppCheckTokenChangeListener(t){this.appCheckCredentialListener=t}terminate(){this.asyncQueue.enterRestrictedMode();const t=new Y;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),t.resolve()}catch(e){const n=Tc(e,"Failed to shutdown persistence");t.reject(n)}}),t.promise}}async function wh(t,e){t.asyncQueue.verifyOperationInProgress(),q(yh,"Initializing OfflineComponentProvider");const n=t.configuration;await e.initialize(n);let s=n.initialUser;t.setCredentialChangeListener(async t=>{s.isEqual(t)||(await pu(e.localStore,t),s=t)}),e.persistence.setDatabaseDeletedListener(()=>t.terminate()),t._offlineComponents=e}async function Ih(t,e){t.asyncQueue.verifyOperationInProgress();const n=await async function(t){if(!t._offlineComponents)if(t._uninitializedComponentsProvider){q(yh,"Using user provided OfflineComponentProvider");try{await wh(t,t._uninitializedComponentsProvider._offline)}catch(e){const r=e;if(!("FirebaseError"===(n=r).name?n.code===H.FAILED_PRECONDITION||n.code===H.UNIMPLEMENTED:!("undefined"!=typeof DOMException&&n instanceof DOMException)||22===n.code||20===n.code||11===n.code))throw r;j("Error using user provided cache. Falling back to memory cache: "+r),await wh(t,new dh)}}else q(yh,"Using default OfflineComponentProvider"),await wh(t,new fh(void 0));var n;return t._offlineComponents}(t);q(yh,"Initializing OnlineComponentProvider"),await e.initialize(n,t.configuration),t.setCredentialChangeListener(t=>vc(e.remoteStore,t)),t.setAppCheckTokenChangeListener((t,n)=>vc(e.remoteStore,n)),t._onlineComponents=e}async function bh(t){return t._onlineComponents||(t._uninitializedComponentsProvider?(q(yh,"Using user provided OnlineComponentProvider"),await Ih(t,t._uninitializedComponentsProvider._online)):(q(yh,"Using default OnlineComponentProvider"),await Ih(t,new gh))),t._onlineComponents}async function Th(t){const e=await bh(t),n=e.eventManager;return n.onListen=Kc.bind(null,e.syncEngine),n.onUnlisten=Qc.bind(null,e.syncEngine),n.onFirstRemoteStoreListen=Gc.bind(null,e.syncEngine),n.onLastRemoteStoreUnlisten=Hc.bind(null,e.syncEngine),n}
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Eh(t){const e={};return void 0!==t.timeoutSeconds&&(e.timeoutSeconds=t.timeoutSeconds),e
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */}const Sh=new Map,_h="firestore.googleapis.com",xh=!0;
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ch{constructor(t){if(void 0===t.host){if(void 0!==t.ssl)throw new X(H.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host=_h,this.ssl=xh}else this.host=t.host,this.ssl=t.ssl??xh;if(this.isUsingEmulator=void 0!==t.emulatorOptions,this.credentials=t.credentials,this.ignoreUndefinedProperties=!!t.ignoreUndefinedProperties,this.localCache=t.localCache,void 0===t.cacheSizeBytes)this.cacheSizeBytes=ca;else{if(-1!==t.cacheSizeBytes&&t.cacheSizeBytes<1048576)throw new X(H.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=t.cacheSizeBytes}(function(t,e,n,s){if(!0===e&&!0===s)throw new X(H.INVALID_ARGUMENT,`${t} and ${n} cannot be used together.`)})("experimentalForceLongPolling",t.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",t.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!t.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:void 0===t.experimentalAutoDetectLongPolling?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!t.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=Eh(t.experimentalLongPollingOptions??{}),function(t){if(void 0!==t.timeoutSeconds){if(isNaN(t.timeoutSeconds))throw new X(H.INVALID_ARGUMENT,`invalid long polling timeout: ${t.timeoutSeconds} (must not be NaN)`);if(t.timeoutSeconds<5)throw new X(H.INVALID_ARGUMENT,`invalid long polling timeout: ${t.timeoutSeconds} (minimum allowed value is 5)`);if(t.timeoutSeconds>30)throw new X(H.INVALID_ARGUMENT,`invalid long polling timeout: ${t.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!t.useFetchStreams}isEqual(t){return this.host===t.host&&this.ssl===t.ssl&&this.credentials===t.credentials&&this.cacheSizeBytes===t.cacheSizeBytes&&this.experimentalForceLongPolling===t.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===t.experimentalAutoDetectLongPolling&&(e=this.experimentalLongPollingOptions,n=t.experimentalLongPollingOptions,e.timeoutSeconds===n.timeoutSeconds)&&this.ignoreUndefinedProperties===t.ignoreUndefinedProperties&&this.useFetchStreams===t.useFetchStreams;var e,n}}class Ah{constructor(t,e,n,s){this._authCredentials=t,this._appCheckCredentials=e,this._databaseId=n,this._app=s,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new Ch({}),this._settingsFrozen=!1,this._emulatorOptions={},this._terminateTask="notTerminated"}get app(){if(!this._app)throw new X(H.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return"notTerminated"!==this._terminateTask}_setSettings(t){if(this._settingsFrozen)throw new X(H.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new Ch(t),this._emulatorOptions=t.emulatorOptions||{},void 0!==t.credentials&&(this._authCredentials=function(t){if(!t)return new J;switch(t.type){case"firstParty":return new nt(t.sessionIndex||"0",t.iamToken||null,t.authTokenFactory||null);case"provider":return t.client;default:throw new X(H.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(t.credentials))}_getSettings(){return this._settings}_getEmulatorOptions(){return this._emulatorOptions}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return"notTerminated"===this._terminateTask&&(this._terminateTask=this._terminate()),this._terminateTask}async _restart(){"notTerminated"===this._terminateTask?await this._terminate():this._terminateTask="notTerminated"}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(t){const e=Sh.get(t);e&&(q("ComponentProvider","Removing Datastore"),Sh.delete(t),e.terminate())}(this),Promise.resolve()}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dh{constructor(t,e,n){this.converter=e,this._query=n,this.type="query",this.firestore=t}withConverter(t){return new Dh(this.firestore,t,this._query)}}class Nh{constructor(t,e,n){this.converter=e,this._key=n,this.type="document",this.firestore=t}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new kh(this.firestore,this.converter,this._key.path.popLast())}withConverter(t){return new Nh(this.firestore,t,this._key)}toJSON(){return{type:Nh._jsonSchemaVersion,referencePath:this._key.toString()}}static fromJSON(t,e,n){if(Ct(e,Nh._jsonSchema))return new Nh(t,n||null,new wt(pt.fromString(e.referencePath)))}}Nh._jsonSchemaVersion="firestore/documentReference/1.0",Nh._jsonSchema={type:xt("string",Nh._jsonSchemaVersion),referencePath:xt("string")};class kh extends Dh{constructor(t,e,n){super(t,e,rr(n)),this._path=n,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const t=this._path.popLast();return t.isEmpty()?null:new Nh(this.firestore,null,new wt(t))}withConverter(t){return new kh(this.firestore,t,this._path)}}function Rh(t,e,...n){if(t=g(t),It("collection","path",e),t instanceof Ah){const s=pt.fromString(e,...n);return Tt(s),new kh(t,null,s)}{if(!(t instanceof Nh||t instanceof kh))throw new X(H.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const s=t._path.child(pt.fromString(e,...n));return Tt(s),new kh(t.firestore,null,s)}}function Mh(t,e,...n){if(t=g(t),1===arguments.length&&(e=ot.newId()),It("doc","path",e),t instanceof Ah){const s=pt.fromString(e,...n);return bt(s),new Nh(t,null,new wt(s))}{if(!(t instanceof Nh||t instanceof kh))throw new X(H.INVALID_ARGUMENT,"Expected first argument to doc() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const s=t._path.child(pt.fromString(e,...n));return bt(s),new Nh(t.firestore,t instanceof kh?t.converter:null,new wt(s))}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Oh="AsyncQueue";class Vh{constructor(t=Promise.resolve()){this.Xu=[],this.ec=!1,this.tc=[],this.nc=null,this.rc=!1,this.sc=!1,this.oc=[],this.M_=new Lu(this,"async_queue_retry"),this._c=()=>{const t=Vu();t&&q(Oh,"Visibility state changed to "+t.visibilityState),this.M_.w_()},this.ac=t;const e=Vu();e&&"function"==typeof e.addEventListener&&e.addEventListener("visibilitychange",this._c)}get isShuttingDown(){return this.ec}enqueueAndForget(t){this.enqueue(t)}enqueueAndForgetEvenWhileRestricted(t){this.uc(),this.cc(t)}enterRestrictedMode(t){if(!this.ec){this.ec=!0,this.sc=t||!1;const e=Vu();e&&"function"==typeof e.removeEventListener&&e.removeEventListener("visibilitychange",this._c)}}enqueue(t){if(this.uc(),this.ec)return new Promise(()=>{});const e=new Y;return this.cc(()=>this.ec&&this.sc?Promise.resolve():(t().then(e.resolve,e.reject),e.promise)).then(()=>e.promise)}enqueueRetryable(t){this.enqueueAndForget(()=>(this.Xu.push(t),this.lc()))}async lc(){if(0!==this.Xu.length){try{await this.Xu[0](),this.Xu.shift(),this.M_.reset()}catch(t){if(!Yt(t))throw t;q(Oh,"Operation failed with retryable error: "+t)}this.Xu.length>0&&this.M_.p_(()=>this.lc())}}cc(t){const e=this.ac.then(()=>(this.rc=!0,t().catch(t=>{throw this.nc=t,this.rc=!1,B("INTERNAL UNHANDLED ERROR: ",Ph(t)),t}).then(t=>(this.rc=!1,t))));return this.ac=e,e}enqueueAfterDelay(t,e,n){this.uc(),this.oc.indexOf(t)>-1&&(e=0);const s=bc.createAndSchedule(this,t,e,n,t=>this.hc(t));return this.tc.push(s),s}uc(){this.nc&&K(47125,{Pc:Ph(this.nc)})}verifyOperationInProgress(){}async Tc(){let t;do{t=this.ac,await t}while(t!==this.ac)}Ic(t){for(const e of this.tc)if(e.timerId===t)return!0;return!1}Ec(t){return this.Tc().then(()=>{this.tc.sort((t,e)=>t.targetTimeMs-e.targetTimeMs);for(const e of this.tc)if(e.skipDelay(),"all"!==t&&e.timerId===t)break;return this.Tc()})}dc(t){this.oc.push(t)}hc(t){const e=this.tc.indexOf(t);this.tc.splice(e,1)}}function Ph(t){let e=t.message||"";return t.stack&&(e=t.stack.includes(t.message)?t.stack:t.message+"\n"+t.stack),e}class Lh extends Ah{constructor(t,e,n,s){super(t,e,n,s),this.type="firestore",this._queue=new Vh,this._persistenceKey=(null==s?void 0:s.name)||"[DEFAULT]"}async _terminate(){if(this._firestoreClient){const t=this._firestoreClient.terminate();this._queue=new Vh(t),this._firestoreClient=void 0,await t}}}function Fh(t,e){const n="object"==typeof t?t:a(),s="string"==typeof t?t:Gn,r=u(n,"firestore").getImmediate({identifier:s});if(!r._initialized){const t=c("firestore");t&&function(t,e,n,s={}){var r;t=_t(t,Ah);const i=h(e),o=t._getSettings(),a={...o,emulatorOptions:t._getEmulatorOptions()},u=`${e}:${n}`;i&&(l(`https://${u}`),d("Firestore",!0)),o.host!==_h&&o.host!==u&&j("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");const c={...o,host:u,ssl:i,emulatorOptions:s};if(!f(c,a)&&(t._setSettings(c),s.mockUserToken)){let e,n;if("string"==typeof s.mockUserToken)e=s.mockUserToken,n=P.MOCK_USER;else{e=m(s.mockUserToken,null==(r=t._app)?void 0:r.options.projectId);const i=s.mockUserToken.sub||s.mockUserToken.user_id;if(!i)throw new X(H.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");n=new P(i)}t._authCredentials=new Z(new W(e,n))}}(r,...t)}return r}function Uh(t){if(t._terminated)throw new X(H.FAILED_PRECONDITION,"The client has already been terminated.");return t._firestoreClient||qh(t),t._firestoreClient}function qh(t){var e,n,s;const r=t._freezeSettings(),i=(o=t._databaseId,a=(null==(e=t._app)?void 0:e.options.appId)||"",u=t._persistenceKey,new Kn(o,a,u,(c=r).host,c.ssl,c.experimentalForceLongPolling,c.experimentalAutoDetectLongPolling,Eh(c.experimentalLongPollingOptions),c.useFetchStreams,c.isUsingEmulator));var o,a,u,c;t._componentsProvider||(null==(n=r.localCache)?void 0:n._offlineComponentProvider)&&(null==(s=r.localCache)?void 0:s._onlineComponentProvider)&&(t._componentsProvider={_offline:r.localCache._offlineComponentProvider,_online:r.localCache._onlineComponentProvider}),t._firestoreClient=new vh(t._authCredentials,t._appCheckCredentials,t._queue,i,t._componentsProvider&&function(t){const e=null==t?void 0:t._online.build();return{_offline:null==t?void 0:t._offline.build(e),_online:e}}(t._componentsProvider))}function Bh(t,e){j("enableIndexedDbPersistence() will be deprecated in the future, you can use `FirestoreSettings.cache` instead.");const n=t._freezeSettings();return function(t,e,n){if((t=_t(t,Lh))._firestoreClient||t._terminated)throw new X(H.FAILED_PRECONDITION,"Firestore has already been started and persistence can no longer be enabled. You can only enable persistence before calling any other methods on a Firestore object.");if(t._componentsProvider||t._getSettings().localCache)throw new X(H.FAILED_PRECONDITION,"SDK cache is already specified.");t._componentsProvider={_online:e,_offline:n},qh(t)}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(t,gh.provider,{build:t=>new mh(t,n.cacheSizeBytes,null==e?void 0:e.forceOwnership)}),Promise.resolve()}class jh{constructor(t){this._byteString=t}static fromBase64String(t){try{return new jh(Rn.fromBase64String(t))}catch(e){throw new X(H.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+e)}}static fromUint8Array(t){return new jh(Rn.fromUint8Array(t))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(t){return this._byteString.isEqual(t._byteString)}toJSON(){return{type:jh._jsonSchemaVersion,bytes:this.toBase64()}}static fromJSON(t){if(Ct(t,jh._jsonSchema))return jh.fromBase64String(t.bytes)}}jh._jsonSchemaVersion="firestore/bytes/1.0",jh._jsonSchema={type:xt("string",jh._jsonSchemaVersion),bytes:xt("string")};
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zh{constructor(...t){for(let e=0;e<t.length;++e)if(0===t[e].length)throw new X(H.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new vt(t)}isEqual(t){return this._internalPath.isEqual(t._internalPath)}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kh{constructor(t){this._methodName=t}}
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gh{constructor(t,e){if(!isFinite(t)||t<-90||t>90)throw new X(H.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+t);if(!isFinite(e)||e<-180||e>180)throw new X(H.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+e);this._lat=t,this._long=e}get latitude(){return this._lat}get longitude(){return this._long}isEqual(t){return this._lat===t._lat&&this._long===t._long}_compareTo(t){return at(this._lat,t._lat)||at(this._long,t._long)}toJSON(){return{latitude:this._lat,longitude:this._long,type:Gh._jsonSchemaVersion}}static fromJSON(t){if(Ct(t,Gh._jsonSchema))return new Gh(t.latitude,t.longitude)}}Gh._jsonSchemaVersion="firestore/geoPoint/1.0",Gh._jsonSchema={type:xt("string",Gh._jsonSchemaVersion),latitude:xt("number"),longitude:xt("number")};
/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $h{constructor(t){this._values=(t||[]).map(t=>t)}toArray(){return this._values.map(t=>t)}isEqual(t){return function(t,e){if(t.length!==e.length)return!1;for(let n=0;n<t.length;++n)if(t[n]!==e[n])return!1;return!0}(this._values,t._values)}toJSON(){return{type:$h._jsonSchemaVersion,vectorValues:this._values}}static fromJSON(t){if(Ct(t,$h._jsonSchema)){if(Array.isArray(t.vectorValues)&&t.vectorValues.every(t=>"number"==typeof t))return new $h(t.vectorValues);throw new X(H.INVALID_ARGUMENT,"Expected 'vectorValues' field to be a number array")}}}$h._jsonSchemaVersion="firestore/vectorValue/1.0",$h._jsonSchema={type:xt("string",$h._jsonSchemaVersion),vectorValues:xt("object")};
/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qh=/^__.*__$/;class Hh{constructor(t,e,n){this.data=t,this.fieldMask=e,this.fieldTransforms=n}toMutation(t,e){return null!==this.fieldMask?new ni(t,this.data,this.fieldMask,e,this.fieldTransforms):new ei(t,this.data,e,this.fieldTransforms)}}function Xh(t){switch(t){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw K(40011,{Ac:t})}}class Yh{constructor(t,e,n,s,r,i){this.settings=t,this.databaseId=e,this.serializer=n,this.ignoreUndefinedProperties=s,void 0===r&&this.Rc(),this.fieldTransforms=r||[],this.fieldMask=i||[]}get path(){return this.settings.path}get Ac(){return this.settings.Ac}Vc(t){return new Yh({...this.settings,...t},this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}mc(t){var e;const n=null==(e=this.path)?void 0:e.child(t),s=this.Vc({path:n,fc:!1});return s.gc(t),s}yc(t){var e;const n=null==(e=this.path)?void 0:e.child(t),s=this.Vc({path:n,fc:!1});return s.Rc(),s}wc(t){return this.Vc({path:void 0,fc:!0})}Sc(t){return al(t,this.settings.methodName,this.settings.bc||!1,this.path,this.settings.Dc)}contains(t){return void 0!==this.fieldMask.find(e=>t.isPrefixOf(e))||void 0!==this.fieldTransforms.find(e=>t.isPrefixOf(e.field))}Rc(){if(this.path)for(let t=0;t<this.path.length;t++)this.gc(this.path.get(t))}gc(t){if(0===t.length)throw this.Sc("Document fields must not be empty");if(Xh(this.Ac)&&Qh.test(t))throw this.Sc('Document fields cannot begin and end with "__"')}}class Wh{constructor(t,e,n){this.databaseId=t,this.ignoreUndefinedProperties=e,this.serializer=n||Pu(t)}Cc(t,e,n,s=!1){return new Yh({Ac:t,methodName:e,Dc:n,path:vt.emptyPath(),fc:!1,bc:s},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function Jh(t){const e=t._freezeSettings(),n=Pu(t._databaseId);return new Wh(t._databaseId,!!e.ignoreUndefinedProperties,n)}function Zh(t,e,n,s,r,i={}){const o=t.Cc(i.merge||i.mergeFields?2:0,e,n,r);sl("Data must be an object, but it was:",o,s);const a=el(s,o);let u,c;if(i.merge)u=new Nn(o.fieldMask),c=o.fieldTransforms;else if(i.mergeFields){const t=[];for(const s of i.mergeFields){const r=rl(e,s,n);if(!o.contains(r))throw new X(H.INVALID_ARGUMENT,`Field '${r}' is specified in your field mask but missing from your input data.`);ul(t,r)||t.push(r)}u=new Nn(t),c=o.fieldTransforms.filter(t=>u.covers(t.field))}else u=null,c=o.fieldTransforms;return new Hh(new Ts(a),u,c)}function tl(t,e){if(nl(t=g(t)))return sl("Unsupported field value:",e,t),el(t,e);if(t instanceof Kh)return function(t,e){if(!Xh(e.Ac))throw e.Sc(`${t._methodName}() can only be used with update() and set()`);if(!e.path)throw e.Sc(`${t._methodName}() is not currently supported inside arrays`);const n=t._toFieldTransform(e);n&&e.fieldTransforms.push(n)}(t,e),null;if(void 0===t&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),t instanceof Array){if(e.settings.fc&&4!==e.Ac)throw e.Sc("Nested arrays are not supported");return function(t,e){const n=[];let s=0;for(const r of t){let t=tl(r,e.wc(s));null==t&&(t={nullValue:"NULL_VALUE"}),n.push(t),s++}return{arrayValue:{values:n}}}(t,e)}return function(t,e){if(null===(t=g(t)))return{nullValue:"NULL_VALUE"};if("number"==typeof t)return Rr(e.serializer,t);if("boolean"==typeof t)return{booleanValue:t};if("string"==typeof t)return{stringValue:t};if(t instanceof Date){const n=Nt.fromDate(t);return{timestampValue:Oi(e.serializer,n)}}if(t instanceof Nt){const n=new Nt(t.seconds,1e3*Math.floor(t.nanoseconds/1e3));return{timestampValue:Oi(e.serializer,n)}}if(t instanceof Gh)return{geoPointValue:{latitude:t.latitude,longitude:t.longitude}};if(t instanceof jh)return{bytesValue:Vi(e.serializer,t._byteString)};if(t instanceof Nh){const n=e.databaseId,s=t.firestore._databaseId;if(!s.isEqual(n))throw e.Sc(`Document reference is for database ${s.projectId}/${s.database} but should be for database ${n.projectId}/${n.database}`);return{referenceValue:Fi(t.firestore._databaseId||e.databaseId,t._key.path)}}if(t instanceof $h)return n=t,s=e,{mapValue:{fields:{[Qn]:{stringValue:Yn},[Wn]:{arrayValue:{values:n.toArray().map(t=>{if("number"!=typeof t)throw s.Sc("VectorValues must only contain numeric values.");return Nr(s.serializer,t)})}}}}};var n,s;throw e.Sc(`Unsupported field value: ${St(t)}`)}(t,e)}function el(t,e){const n={};return En(t)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):Tn(t,(t,s)=>{const r=tl(s,e.mc(t));null!=r&&(n[t]=r)}),{mapValue:{fields:n}}}function nl(t){return!("object"!=typeof t||null===t||t instanceof Array||t instanceof Date||t instanceof Nt||t instanceof Gh||t instanceof jh||t instanceof Nh||t instanceof Kh||t instanceof $h)}function sl(t,e,n){if(!nl(n)||!Et(n)){const s=St(n);throw"an object"===s?e.Sc(t+" a custom object"):e.Sc(t+" "+s)}}function rl(t,e,n){if((e=g(e))instanceof zh)return e._internalPath;if("string"==typeof e)return ol(t,e);throw al("Field path arguments must be of type string or ",t,!1,void 0,n)}const il=new RegExp("[~\\*/\\[\\]]");function ol(t,e,n){if(e.search(il)>=0)throw al(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,t,!1,void 0,n);try{return new zh(...e.split("."))._internalPath}catch(s){throw al(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,t,!1,void 0,n)}}function al(t,e,n,s,r){const i=s&&!s.isEmpty(),o=void 0!==r;let a=`Function ${e}() called with invalid data`;n&&(a+=" (via `toFirestore()`)"),a+=". ";let u="";return(i||o)&&(u+=" (found",i&&(u+=` in field ${s}`),o&&(u+=` in document ${r}`),u+=")"),new X(H.INVALID_ARGUMENT,a+t+u)}function ul(t,e){return t.some(t=>t.isEqual(e))}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cl{constructor(t,e,n,s,r){this._firestore=t,this._userDataWriter=e,this._key=n,this._document=s,this._converter=r}get id(){return this._key.path.lastSegment()}get ref(){return new Nh(this._firestore,this._converter,this._key)}exists(){return null!==this._document}data(){if(this._document){if(this._converter){const t=new hl(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(t)}return this._userDataWriter.convertValue(this._document.data.value)}}get(t){if(this._document){const e=this._document.data.field(ll("DocumentSnapshot.get",t));if(null!==e)return this._userDataWriter.convertValue(e)}}}class hl extends cl{data(){return super.data()}}function ll(t,e){return"string"==typeof e?ol(t,e):e instanceof zh?e._internalPath:e._delegate._internalPath}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dl{}class fl extends dl{}function ml(t,e,...n){let s=[];e instanceof dl&&s.push(e),s=s.concat(n),function(t){const e=t.filter(t=>t instanceof pl).length,n=t.filter(t=>t instanceof gl).length;if(e>1||e>0&&n>0)throw new X(H.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")}(s);for(const r of s)t=r._apply(t);return t}class gl extends fl{constructor(t,e,n){super(),this._field=t,this._op=e,this._value=n,this.type="where"}static _create(t,e,n){return new gl(t,e,n)}_apply(t){const e=this._parse(t);return bl(t._query,e),new Dh(t.firestore,t.converter,cr(t._query,e))}_parse(t){const e=Jh(t.firestore),n=function(t,e,n,s,r,i,o){let a;if(r.isKeyField()){if("array-contains"===i||"array-contains-any"===i)throw new X(H.INVALID_ARGUMENT,`Invalid Query. You can't perform '${i}' queries on documentId().`);if("in"===i||"not-in"===i){Il(o,i);const e=[];for(const n of o)e.push(wl(s,t,n));a={arrayValue:{values:e}}}else a=wl(s,t,o)}else"in"!==i&&"not-in"!==i&&"array-contains-any"!==i||Il(o,i),a=function(t,e,n,s=!1){return tl(n,t.Cc(s?4:3,e))}(n,e,o,"in"===i||"not-in"===i);return ks.create(r,i,a)}(t._query,"where",e,t.firestore._databaseId,this._field,this._op,this._value);return n}}class pl extends dl{constructor(t,e){super(),this.type=t,this._queryConstraints=e}static _create(t,e){return new pl(t,e)}_parse(t){const e=this._queryConstraints.map(e=>e._parse(t)).filter(t=>t.getFilters().length>0);return 1===e.length?e[0]:Rs.create(e,this._getOperator())}_apply(t){const e=this._parse(t);return 0===e.getFilters().length?t:(function(t,e){let n=t;const s=e.getFlattenedFilters();for(const r of s)bl(n,r),n=cr(n,r)}(t._query,e),new Dh(t.firestore,t.converter,cr(t._query,e)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return"and"===this.type?"and":"or"}}class yl extends fl{constructor(t,e){super(),this._field=t,this._direction=e,this.type="orderBy"}static _create(t,e){return new yl(t,e)}_apply(t){const e=function(t,e,n){if(null!==t.startAt)throw new X(H.INVALID_ARGUMENT,"Invalid query. You must not call startAt() or startAfter() before calling orderBy().");if(null!==t.endAt)throw new X(H.INVALID_ARGUMENT,"Invalid query. You must not call endAt() or endBefore() before calling orderBy().");return new As(e,n)}(t._query,this._field,this._direction);return new Dh(t.firestore,t.converter,function(t,e){const n=t.explicitOrderBy.concat([e]);return new sr(t.path,t.collectionGroup,n,t.filters.slice(),t.limit,t.limitType,t.startAt,t.endAt)}(t._query,e))}}function vl(t,e="asc"){const n=e,s=ll("orderBy",t);return yl._create(s,n)}function wl(t,e,n){if("string"==typeof(n=g(n))){if(""===n)throw new X(H.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!or(e)&&-1!==n.indexOf("/"))throw new X(H.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${n}' contains a '/' character.`);const s=e.path.child(pt.fromString(n));if(!wt.isDocumentKey(s))throw new X(H.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${s}' is not because it has an odd number of segments (${s.length}).`);return us(t,new wt(s))}if(n instanceof Nh)return us(t,n._key);throw new X(H.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${St(n)}.`)}function Il(t,e){if(!Array.isArray(t)||0===t.length)throw new X(H.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${e.toString()}' filters.`)}function bl(t,e){const n=function(t,e){for(const n of t)for(const t of n.getFlattenedFilters())if(e.indexOf(t.op)>=0)return t.op;return null}(t.filters,function(t){switch(t){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}}(e.op));if(null!==n)throw n===e.op?new X(H.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${e.op.toString()}' filter.`):new X(H.INVALID_ARGUMENT,`Invalid query. You cannot use '${e.op.toString()}' filters with '${n.toString()}' filters.`)}class Tl{convertValue(t,e="none"){switch(Zn(t)){case 0:return null;case 1:return t.booleanValue;case 2:return Vn(t.integerValue||t.doubleValue);case 3:return this.convertTimestamp(t.timestampValue);case 4:return this.convertServerTimestamp(t,e);case 5:return t.stringValue;case 6:return this.convertBytes(Pn(t.bytesValue));case 7:return this.convertReference(t.referenceValue);case 8:return this.convertGeoPoint(t.geoPointValue);case 9:return this.convertArray(t.arrayValue,e);case 11:return this.convertObject(t.mapValue,e);case 10:return this.convertVectorValue(t.mapValue);default:throw K(62114,{value:t})}}convertObject(t,e){return this.convertObjectMap(t.fields,e)}convertObjectMap(t,e="none"){const n={};return Tn(t,(t,s)=>{n[t]=this.convertValue(s,e)}),n}convertVectorValue(t){var e,n,s;const r=null==(s=null==(n=null==(e=t.fields)?void 0:e[Wn].arrayValue)?void 0:n.values)?void 0:s.map(t=>Vn(t.doubleValue));return new $h(r)}convertGeoPoint(t){return new Gh(Vn(t.latitude),Vn(t.longitude))}convertArray(t,e){return(t.values||[]).map(t=>this.convertValue(t,e))}convertServerTimestamp(t,e){switch(e){case"previous":const n=jn(t);return null==n?null:this.convertValue(n,e);case"estimate":return this.convertTimestamp(zn(t));default:return null}}convertTimestamp(t){const e=On(t);return new Nt(e.seconds,e.nanos)}convertDocumentKey(t,e){const n=pt.fromString(t);$(ao(n),9688,{name:t});const s=new $n(n.get(1),n.get(3)),r=new wt(n.popFirst(5));return s.isEqual(e)||B(`Document ${r} contains a document reference within a different database (${s.projectId}/${s.database}) which is not supported. It will be treated as a reference in the current database (${e.projectId}/${e.database}) instead.`),r}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class El{constructor(t,e){this.hasPendingWrites=t,this.fromCache=e}isEqual(t){return this.hasPendingWrites===t.hasPendingWrites&&this.fromCache===t.fromCache}}class Sl extends cl{constructor(t,e,n,s,r,i){super(t,e,n,s,i),this._firestore=t,this._firestoreImpl=t,this.metadata=r}exists(){return super.exists()}data(t={}){if(this._document){if(this._converter){const e=new _l(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(e,t)}return this._userDataWriter.convertValue(this._document.data.value,t.serverTimestamps)}}get(t,e={}){if(this._document){const n=this._document.data.field(ll("DocumentSnapshot.get",t));if(null!==n)return this._userDataWriter.convertValue(n,e.serverTimestamps)}}toJSON(){if(this.metadata.hasPendingWrites)throw new X(H.FAILED_PRECONDITION,"DocumentSnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const t=this._document,e={};return e.type=Sl._jsonSchemaVersion,e.bundle="",e.bundleSource="DocumentSnapshot",e.bundleName=this._key.toString(),t&&t.isValidDocument()&&t.isFoundDocument()?(this._userDataWriter.convertObjectMap(t.data.value.mapValue.fields,"previous"),e.bundle=(this._firestore,this.ref.path,"NOT SUPPORTED"),e):e}}Sl._jsonSchemaVersion="firestore/documentSnapshot/1.0",Sl._jsonSchema={type:xt("string",Sl._jsonSchemaVersion),bundleSource:xt("string","DocumentSnapshot"),bundleName:xt("string"),bundle:xt("string")};class _l extends Sl{data(t={}){return super.data(t)}}class xl{constructor(t,e,n,s){this._firestore=t,this._userDataWriter=e,this._snapshot=s,this.metadata=new El(s.hasPendingWrites,s.fromCache),this.query=n}get docs(){const t=[];return this.forEach(e=>t.push(e)),t}get size(){return this._snapshot.docs.size}get empty(){return 0===this.size}forEach(t,e){this._snapshot.docs.forEach(n=>{t.call(e,new _l(this._firestore,this._userDataWriter,n.key,n,new El(this._snapshot.mutatedKeys.has(n.key),this._snapshot.fromCache),this.query.converter))})}docChanges(t={}){const e=!!t.includeMetadataChanges;if(e&&this._snapshot.excludesMetadataChanges)throw new X(H.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===e||(this._cachedChanges=function(t,e){if(t._snapshot.oldDocs.isEmpty()){let e=0;return t._snapshot.docChanges.map(n=>{const s=new _l(t._firestore,t._userDataWriter,n.doc.key,n.doc,new El(t._snapshot.mutatedKeys.has(n.doc.key),t._snapshot.fromCache),t.query.converter);return n.doc,{type:"added",doc:s,oldIndex:-1,newIndex:e++}})}{let n=t._snapshot.oldDocs;return t._snapshot.docChanges.filter(t=>e||3!==t.type).map(e=>{const s=new _l(t._firestore,t._userDataWriter,e.doc.key,e.doc,new El(t._snapshot.mutatedKeys.has(e.doc.key),t._snapshot.fromCache),t.query.converter);let r=-1,i=-1;return 0!==e.type&&(r=n.indexOf(e.doc.key),n=n.delete(e.doc.key)),1!==e.type&&(n=n.add(e.doc),i=n.indexOf(e.doc.key)),{type:Cl(e.type),doc:s,oldIndex:r,newIndex:i}})}}(this,e),this._cachedChangesIncludeMetadataChanges=e),this._cachedChanges}toJSON(){if(this.metadata.hasPendingWrites)throw new X(H.FAILED_PRECONDITION,"QuerySnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const t={};t.type=xl._jsonSchemaVersion,t.bundleSource="QuerySnapshot",t.bundleName=ot.newId(),this._firestore._databaseId.database,this._firestore._databaseId.projectId;const e=[],n=[],s=[];return this.docs.forEach(t=>{null!==t._document&&(e.push(t._document),n.push(this._userDataWriter.convertObjectMap(t._document.data.value.mapValue.fields,"previous")),s.push(t.ref.path))}),t.bundle=(this._firestore,this.query._query,t.bundleName,"NOT SUPPORTED"),t}}function Cl(t){switch(t){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return K(61501,{type:t})}}
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Al(t){t=_t(t,Nh);const e=_t(t.firestore,Lh);return function(t,e,n={}){const s=new Y;return t.asyncQueue.enqueueAndForget(async()=>function(t,e,n,s,r){const i=new ph({next:a=>{i.Nu(),e.enqueueAndForget(()=>Nc(t,o));const u=a.docs.has(n);!u&&a.fromCache?r.reject(new X(H.UNAVAILABLE,"Failed to get document because the client is offline.")):u&&a.fromCache&&s&&"server"===s.source?r.reject(new X(H.UNAVAILABLE,'Failed to get document from server. (However, this document does exist in the local cache. Run again without setting source to "server" to retrieve the cached document.)')):r.resolve(a)},error:t=>r.reject(t)}),o=new Pc(rr(n.path),i,{includeMetadataChanges:!0,qa:!0});return Dc(t,o)}(await Th(t),t.asyncQueue,e,n,s)),s.promise}(Uh(e),t._key).then(n=>function(t,e,n){const s=n.docs.get(e._key),r=new Dl(t);return new Sl(t,r,e._key,s,new El(n.hasPendingWrites,n.fromCache),e.converter)}(e,t,n))}xl._jsonSchemaVersion="firestore/querySnapshot/1.0",xl._jsonSchema={type:xt("string",xl._jsonSchemaVersion),bundleSource:xt("string","QuerySnapshot"),bundleName:xt("string"),bundle:xt("string")};class Dl extends Tl{constructor(t){super(),this.firestore=t}convertBytes(t){return new jh(t)}convertReference(t){const e=this.convertDocumentKey(t,this.firestore._databaseId);return new Nh(this.firestore,null,e)}}function Nl(t){t=_t(t,Dh);const e=_t(t.firestore,Lh),n=Uh(e),s=new Dl(e);return function(t){if("L"===t.limitType&&0===t.explicitOrderBy.length)throw new X(H.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}(t._query),function(t,e,n={}){const s=new Y;return t.asyncQueue.enqueueAndForget(async()=>function(t,e,n,s,r){const i=new ph({next:n=>{i.Nu(),e.enqueueAndForget(()=>Nc(t,o)),n.fromCache&&"server"===s.source?r.reject(new X(H.UNAVAILABLE,'Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to "server" to retrieve the cached documents.)')):r.resolve(n)},error:t=>r.reject(t)}),o=new Pc(n,i,{includeMetadataChanges:!0,qa:!0});return Dc(t,o)}(await Th(t),t.asyncQueue,e,n,s)),s.promise}(n,t._query).then(n=>new xl(e,s,t,n))}function kl(t,e,n){t=_t(t,Nh);const s=_t(t.firestore,Lh),r=function(t,e){let n;return n=t?t.toFirestore(e):e,n}(t.converter,e);return function(t,e){return function(t,e){const n=new Y;return t.asyncQueue.enqueueAndForget(async()=>async function(e,n,s){const r=lh(e);try{const t=await function(t,e){const n=Q(t),s=Nt.now(),r=e.reduce((t,e)=>t.add(e.key),Ar());let i,o;return n.persistence.runTransaction("Locally write mutations","readwrite",t=>{let a=wr(),u=Ar();return n.Ns.getEntries(t,r).next(t=>{a=t,a.forEach((t,e)=>{e.isValidDocument()||(u=u.add(t))})}).next(()=>n.localDocuments.getOverlayedDocuments(t,a)).next(r=>{i=r;const o=[];for(const t of e){const e=Zr(t,i.get(t.key).overlayedDocument);null!=e&&o.push(new ni(t.key,e,Es(e.value.mapValue),Qr.exists(!0)))}return n.mutationQueue.addMutationBatch(t,s,o,e)}).next(e=>{o=e;const s=e.applyToLocalDocumentSet(i,u);return n.documentOverlayCache.saveOverlays(t,e.batchId,s)})}).then(()=>({batchId:o.batchId,changes:Tr(i)}))}(r.localStore,n);r.sharedClientState.addPendingMutation(t.batchId),function(t,e,n){let s=t.Vu[t.currentUser.toKey()];s||(s=new Sn(at)),s=s.insert(e,n),t.Vu[t.currentUser.toKey()]=s}(r,t.batchId,s),await ah(r,t.changes),await cc(r.remoteStore)}catch(t){const n=Tc(t,"Failed to persist write");s.reject(n)}}(await function(t){return bh(t).then(t=>t.syncEngine)}(t),e,n)),n.promise}(Uh(t),e)}(s,[Zh(Jh(s),"setDoc",t._key,r,null!==t.converter,n).toMutation(t._key,Qr.none())])}!function(t,r=!0){L=v,e(new n("firestore",(t,{instanceIdentifier:e,options:n})=>{const s=t.getProvider("app").getImmediate(),i=new Lh(new tt(t.getProvider("auth-internal")),new rt(s,t.getProvider("app-check-internal")),function(t,e){if(!Object.prototype.hasOwnProperty.apply(t.options,["projectId"]))throw new X(H.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new $n(t.options.projectId,e)}(s,e),s);return n={useFetchStreams:r,...n},i._setSettings(n),i},"PUBLIC").setMultipleInstances(!0)),s(O,V,t),s(O,V,"esm2020")}();export{Al as a,Nl as b,Rh as c,Mh as d,Bh as e,Fh as g,vl as o,ml as q,kl as s};
